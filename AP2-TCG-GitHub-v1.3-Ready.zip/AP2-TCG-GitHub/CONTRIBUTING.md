# Mitwirkung am Projekt

Änderungen müssen das bestehende Regelwerk und die schriftliche FISI-AP2 berücksichtigen.

1. Änderungen in den Quelldateien im Repository-Stamm durchführen. Dateien unter `web/` und `android-studio/app/src/main/assets/` nicht separat bearbeiten.
2. Neue oder veränderte Spielregeln durch Tests in `tests.cjs` absichern.
3. AP2-Fragen mit eindeutigem Operator, Lösung und fachlicher Erklärung ergänzen. Keine Prüfungsaufgaben oder Musterlösungen unberechtigt übernehmen.
4. `npm run check` ausführen und Änderungen an generierten Dateien mit einchecken.
5. Pull Request mit Funktionsbeschreibung, Testnachweis und bekannten Einschränkungen einreichen.

Karten sollten eine nachvollziehbare technische Wirkung haben. RAID, Backup, DNS, Routing, VLAN, STP und Firewallregeln dürfen fachlich nicht vermischt werden.

Projektphase, Dokumentation und Fachgespräch der betrieblichen Prüfung sind kein Bestandteil dieses Spiels. Der Fokus liegt auf der schriftlichen AP2.
