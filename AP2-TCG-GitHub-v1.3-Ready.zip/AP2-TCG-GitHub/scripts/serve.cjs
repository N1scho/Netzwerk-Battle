'use strict';
// Kleiner lokaler Webserver ohne Abhängigkeiten; nur für die Entwicklung.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../web');
const port = Number(process.env.PORT || 8080);
const types = {'.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.json': 'application/json', '.webmanifest': 'application/manifest+json'};
http.createServer((req, res) => {
  let urlPath;
  try { urlPath = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
  catch { res.writeHead(400).end('Ungültige Anfrage'); return; }
  const requested = path.resolve(root, '.' + urlPath);
  if (requested !== root && !requested.startsWith(root + path.sep)) { res.writeHead(403).end('Verboten'); return; }
  let full = requested;
  try { if (fs.statSync(full).isDirectory()) full = path.join(full, 'index.html'); }
  catch { res.writeHead(404).end('Nicht gefunden'); return; }
  fs.readFile(full, (err, body) => {
    if (err) { res.writeHead(404).end('Nicht gefunden'); return; }
    res.writeHead(200, {'Content-Type': types[path.extname(full)] || 'application/octet-stream', 'Cache-Control': 'no-cache'});
    res.end(body);
  });
}).listen(port, '127.0.0.1', () => console.log(`AP2 TCG: http://127.0.0.1:${port}`));
