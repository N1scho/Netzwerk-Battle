'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const {execFileSync} = require('node:child_process');
const root = path.resolve(__dirname, '..');
const src = ['index.html', 'styles.css', 'engine.js', 'trivia.js', 'topics.js', 'packs.js', 'app.js'];
const destinations = ['web', 'android-studio/app/src/main/assets'];
const hash = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const exists = p => assert(fs.existsSync(path.join(root, p)), `Fehlende Datei: ${p}`);
for (const file of src) {
  exists(file);
  if (file.endsWith('.js')) execFileSync(process.execPath, ['--check', path.join(root, file)]);
  for (const dest of destinations) {
    exists(`${dest}/${file}`);
    assert.equal(hash(path.join(root, file)), hash(path.join(root, dest, file)), `Nicht synchron: ${dest}/${file}`);
  }
}
for (const file of [
  'AP2-TCG-v13-Offline.html', 'web/sw.js', 'web/manifest.webmanifest',
  'web/icons/icon-192.png', 'web/icons/icon-512.png',
  'android-studio/app/build.gradle',
  '.github/workflows/ci.yml', '.github/workflows/pages.yml', '.github/workflows/android-apk.yml'
]) exists(file);
const offline = fs.readFileSync(path.join(root, 'AP2-TCG-v13-Offline.html'), 'utf8');
assert(!/<script\s+src=/i.test(offline), 'Offline HTML darf keine externen Skripte enthalten');
assert(!/<link\s+rel="stylesheet"/i.test(offline), 'Offline HTML darf keine externe CSS benötigen');
for (const text of ['AP2 TCG', 'engine.js', 'app.js']) {
  if (text === 'engine.js' || text === 'app.js') continue; // Inhalte sind inline.
  assert(offline.includes(text));
}
const sw = fs.readFileSync(path.join(root, 'web/sw.js'), 'utf8');
const match = sw.match(/const CACHE = 'ap2-tcg-([a-f0-9]{16})';/);
assert(match, 'Service Worker ohne versionierten Cache');
console.log('Verify OK: Quelldateien, Browser und Android-Assets identisch; Offline-Build und PWA geprüft.');
