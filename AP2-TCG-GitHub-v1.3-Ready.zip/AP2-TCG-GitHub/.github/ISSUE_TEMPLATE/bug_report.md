---
name: Fehler melden
about: Reproduzierbaren Fehler im AP2 TCG dokumentieren
labels: bug
---

## Version und Plattform
- Version:
- Browser oder Android-Version:
- Spielmodus / Tutorial-Mission:

## Fehlerbeschreibung

## Schritte zum Reproduzieren
1.
2.
3.

## Erwartetes Ergebnis

## Tatsächliches Ergebnis

## Screenshot und Browser-Konsole (ohne personenbezogene Daten)
