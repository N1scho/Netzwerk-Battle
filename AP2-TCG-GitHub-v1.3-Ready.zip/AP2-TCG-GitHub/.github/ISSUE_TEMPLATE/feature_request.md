---
name: Funktion vorschlagen
about: Neue Karten, Lernfunktionen oder Spielmechaniken
labels: enhancement
---

## Ausgangslage

## Gewünschte Funktion

## Fachlicher AP2-Bezug

## Regeländerung und erwartete Auswirkungen

## Prüfkriterien
