## Änderung

## Fachlicher Bezug zur schriftlichen FISI-AP2

## Tests
- [ ] `npm run check` erfolgreich
- [ ] Tutorial- und Kartenfragen geprüft, falls betroffen
- [ ] Kein fremder oder persönlicher Datenbestand hochgeladen
- [ ] Android-/Web-Assets mit `npm run build` synchronisiert

## Bekannte Einschränkungen
