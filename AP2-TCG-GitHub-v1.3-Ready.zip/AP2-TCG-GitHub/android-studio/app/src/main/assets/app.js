(function(){
  'use strict';
  const E=window.AP2ENGINE;
  const app=document.querySelector('#app');
  let blockedTarget=null, game=null, selected=null, inspecting=null, progress=loadProgress(), toast=null, modal=null, aiTimer=null, handoff=false, screen='home', quizFeedback='', deckDraft=null, chosenPreset='ausgeglichen', guideError='', guideTipOpen=false, guideSuccess='';
  const TRIVIA=window.AP2TRIVIA||{};
  const TOPICS=Array.isArray(window.AP2TOPICS)?window.AP2TOPICS:[];
  const TOPICS_KEY='ap2tcg.packRotation.v10', QUESTIONS_KEY='ap2tcg.quizSequence.v09';
  const PACKS=Array.isArray(window.AP2PACKS)?window.AP2PACKS:[];
  const CORE_ID='netzwerk', ADDON_IDS=PACKS.filter(p=>p.type==='addon').map(p=>p.id);
  const DEFAULT_NETWORK_SHARE=70; // 70 % Netzwerk, 30 % aktivierte Add-ons
  const topicsById=new Map(TOPICS.map(t=>[t.id,t]));
  const packById=new Map(PACKS.map(p=>[p.id,p]));
  const DIFFICULTIES={basic:'Basis',normal:'Standard',hard:'Prüfungsnah'};
  const SETTINGS_KEY='ap2tcg.settings.v07', COLLECTION_KEY='ap2tcg.collection.v07';
  function safeRead(key,fallback){try{const v=JSON.parse(localStorage.getItem(key)||'null');return v??fallback;}catch{return fallback;}}
  function safeSave(key,value){try{localStorage.setItem(key,JSON.stringify(value));}catch{}}
  function loadSettings(){const saved=safeRead(SETTINGS_KEY,{});return {trivia:['basic','normal','hard'].includes(saved.trivia)?saved.trivia:'normal',bot:['easy','normal','hard'].includes(saved.bot)?saved.bot:'normal',addonPacks:Array.isArray(saved.addonPacks)?ADDON_IDS.filter(id=>saved.addonPacks.includes(id)):[],networkShare:Number.isInteger(saved.networkShare)&&saved.networkShare>=0&&saved.networkShare<=100&&saved.networkShare%5===0?saved.networkShare:DEFAULT_NETWORK_SHARE};}
  let settings=loadSettings(), quizTurn=null, quizSequence=loadQuizSequence(), collection=loadCollection();
  let topicRotation=loadPackRotation();
  deckDraft=loadDeck();
  function loadCollection(){const saved=safeRead(COLLECTION_KEY,null), initial=Object.fromEntries(E.BASIC_IDS.map(id=>[id,4]));if(!saved||typeof saved!=='object')return {credits:0,owned:initial,answers:0,matches:0,wins:0};
    const owned={...initial};for(const id of Object.keys(E.CARDS))if(!E.BASIC_IDS.includes(id))owned[id]=Math.min(4,Math.max(0,Number.isInteger(saved.owned?.[id])?saved.owned[id]:0));
    return {credits:Math.min(999999,Math.max(0,Number(saved.credits)||0)),owned,answers:Math.max(0,Number(saved.answers)||0),matches:Math.max(0,Number(saved.matches)||0),wins:Math.max(0,Number(saved.wins)||0)};}
  function storeCollection(){safeSave(COLLECTION_KEY,collection);}
  function ownedCount(id){return collection.owned[id]||0;}
  function deckOwned(deck){return E.validateDeck(deck)&&Object.entries(deck).every(([id,n])=>n<=ownedCount(id));}
  const MISSION_REWARDS={2:'vuln',3:'patch',4:'isolate',5:'raid',6:'backupplan',7:'exploit',8:'backup',10:'disk'};
  function awardMission(id){
    if(progress.includes(id))return;
    progress.push(id);saveProgress();rewardPoints(6);
    const card=MISSION_REWARDS[id];
    if(card && ownedCount(card)<4){collection.owned[card]=ownedCount(card)+1;storeCollection();}
  }
  function cardCost(id){const c=E.CARDS[id];return c.cost>=3?15:c.cost===2?12:9;}
  function rewardPoints(n){collection.credits+=n;storeCollection();}
  // Das Grundspiel ist immer aktiv. Die Fragen-Packs können beliebig kombiniert werden.
  // Anteil frei einstellbar, Standard 70/30. Falsche/abgebrochene Antworten
  // ändern die Rotation nicht. Bei deaktivierten Add-ons gilt immer 100/0.
  function loadQuizSequence(){const saved=safeRead(QUESTIONS_KEY,{});return saved&&typeof saved==='object'&&!Array.isArray(saved)?saved:{};}
  function shuffleIds(ids){const a=[...ids];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
  function topicsOfPack(packId){return TOPICS.filter(t=>t.packId===packId).map(t=>t.id);}
  function packRotationValid(saved,ids){return saved&&Array.isArray(saved.order)&&saved.order.length===ids.length&&new Set(saved.order).size===ids.length&&ids.every(id=>saved.order.includes(id))&&Number.isInteger(saved.index)&&saved.index>=0&&saved.index<ids.length;}
  function loadPackRotation(){
    const saved=safeRead(TOPICS_KEY,null),old=safeRead('ap2tcg.topics.v09',null),packs={};
    for(const pk of PACKS){
      const ids=topicsOfPack(pk.id), prior=saved?.packs?.[pk.id];
      if(packRotationValid(prior,ids)){packs[pk.id]={order:prior.order,index:prior.index,completed:Math.max(0,Number(prior.completed)||0)};continue;}
      // Der alte Gesamtfortschritt wird beim ersten Öffnen nach Packs verteilt.
      const done=Array.isArray(old?.order)?[...new Set(old.order.slice(0,Math.max(0,old.index||0)).filter(id=>ids.includes(id)))]:[];
      const todo=shuffleIds(ids.filter(id=>!done.includes(id)));
      packs[pk.id]={order:[...done,...todo],index:done.length===ids.length?0:done.length,completed:0};
      if(done.length===ids.length)packs[pk.id].order=shuffleIds(ids);
    }
    const step=Math.max(0,Number(saved?.step)||0);
    const rotation={step,ratioStartStep:Number.isInteger(saved?.ratioStartStep)&&saved.ratioStartStep>=0&&saved.ratioStartStep<=step?saved.ratioStartStep:0,addonCursor:Math.max(0,Number(saved?.addonCursor)||0),packs};
    safeSave(TOPICS_KEY,rotation);return rotation;
  }
  function activePackIds(){return [CORE_ID,...settings.addonPacks];}
  function effectiveNetworkShare(){return settings.addonPacks.length?settings.networkShare:100;}
  // Digitaler Verteiler: Bei p=70 sind in je 20 erfolgreichen Kartenfragen
  // genau 14 Netzwerkfragen enthalten. Funktioniert mit 0..100 in 5er-Schritten.
  function isNetworkQuestionStep(step=topicRotation.step){
    const position=Math.max(0,step-topicRotation.ratioStartStep),p=effectiveNetworkShare();
    return Math.ceil((position+1)*p/100)>Math.ceil(position*p/100);
  }
  function nextPackId(){
    if(isNetworkQuestionStep())return CORE_ID;
    return settings.addonPacks[topicRotation.addonCursor%settings.addonPacks.length];
  }
  function resetShareCycle(){
    topicRotation.ratioStartStep=topicRotation.step;
    safeSave(TOPICS_KEY,topicRotation);
  }
  function currentPackProgress(packId){const p=topicRotation.packs[packId];return {done:p?.index||0,total:p?.order.length||0,round:(p?.completed||0)+1};}
  function advanceTopic(topicId){
    const t=topicsById.get(topicId),pk=t?.packId;if(!pk||pk!==nextPackId())return;
    const rotation=topicRotation.packs[pk];if(rotation?.order[rotation.index]!==topicId)return;
    rotation.index++;
    if(rotation.index>=rotation.order.length){rotation.order=shuffleIds(rotation.order);rotation.index=0;rotation.completed++;}
    topicRotation.step++;
    if(pk!==CORE_ID)topicRotation.addonCursor++;
    safeSave(TOPICS_KEY,topicRotation);
  }
  function reshuffleQuestion(q,key){
    // Shuffling answer order does not advance progress. A question is consumed
    // only after the player answers correctly and the card is authorized.
    const options=q.options.map((name,i)=>({name,correct:i===q.answer}));
    for(let i=options.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[options[i],options[j]]=[options[j],options[i]];}
    return {...q,sequenceKey:key,options:options.map(o=>o.name),answer:options.findIndex(o=>o.correct)};
  }
  function questionFor(cardId,forcedTopicId=null,attempt=0,forceCard=false){
    // Tutorials teach the actual card before exposing mixed AP2 question packs.
    if(!forceCard&&TOPICS.length){
      const pk=nextPackId(),rotation=topicRotation.packs[pk];
      const topic=forcedTopicId?topicsById.get(forcedTopicId):topicsById.get(rotation?.order[rotation.index]);
      if(!topic)throw new Error('Fragenpaket oder Themengebiet fehlt.');
      const list=topic.questions[settings.trivia];
      if(!Array.isArray(list)||!list.length)throw new Error('Keine AP2-Frage für '+topic.name+' ('+settings.trivia+')');
      const key=topic.id+':'+settings.trivia;
      const picked=list[((quizSequence[key]||0)+attempt)%list.length];
      return {...reshuffleQuestion(picked,key),topicId:topic.id,topic:topic.name,area:topic.area,packId:topic.packId,packTitle:packById.get(topic.packId)?.title||'Netzwerktechnik',subgroup:topic.subgroup};
    }
    const list=TRIVIA[cardId]||[];if(!list.length)throw new Error('Keine Fachfrage für '+cardId);
    const key=cardId+':'+settings.trivia;
    const choices=settings.trivia==='basic'?[0,1]:settings.trivia==='normal'?[1,0,2]:[2,1];
    const index=choices[((quizSequence[key]||0)+attempt)%choices.length];
    return {...reshuffleQuestion(list[index],key),topicId:null,topic:'Kartenwissen',area:'Kartenthema',packId:CORE_ID,packTitle:'Kartenwissen',subgroup:E.CARDS[cardId]?.name||cardId};
  }
  function commitQuestion(q){
    if(typeof q.sequenceKey!=='string')return;
    quizSequence[q.sequenceKey]=(Number.isInteger(quizSequence[q.sequenceKey])?quizSequence[q.sequenceKey]:0)+1;
    safeSave(QUESTIONS_KEY,quizSequence);
  }
  // The first-try bonus is tied to the card type and player for the current
  // match. Canceling a failed question must not reset the penalty.
  function quizMistakeKey(player,cardId){return String(player)+':'+cardId;}
  function markQuizMistake(player,cardId){
    if(!game)return;
    if(!game.quizMistakes || typeof game.quizMistakes!=='object')game.quizMistakes={};
    game.quizMistakes[quizMistakeKey(player,cardId)]=true;
  }
  function hasQuizMistake(player,cardId){return Boolean(game?.quizMistakes?.[quizMistakeKey(player,cardId)]);}
  function clearQuizMistake(player,cardId){if(game?.quizMistakes)delete game.quizMistakes[quizMistakeKey(player,cardId)];}
  function beginCardQuiz(cardId,player,target){
    const error=E.allowed(game,player,cardId,target);if(error){showToast(error);return;}
    quizTurn={cardId,player,target,attempt:0,wrongEver:hasQuizMistake(player,cardId),question:questionFor(cardId,null,0,game.mode==='tutorial'),wrong:false,feedback:''};
    modal={type:'cardquiz'};saveMatch();render();
  }
  function loadProgress(){try{const value=JSON.parse(localStorage.getItem('ap2tcg.progress')||'[]');return Array.isArray(value)?[...new Set(value.filter(n=>Number.isInteger(n)&&n>=1&&n<=E.MISSIONS.length))]:[];}catch{return []}}
  function saveProgress(){try{localStorage.setItem('ap2tcg.progress',JSON.stringify(progress))}catch{}}
  function loadDeck(){try{const d=JSON.parse(localStorage.getItem('ap2tcg.deck.v02')||'null');return deckOwned(d)?d:{...E.BASIC_PRESETS.basic_angriff};}catch{return {...E.BASIC_PRESETS.basic_angriff}}}
  function storeDeck(){try{localStorage.setItem('ap2tcg.deck.v02',JSON.stringify(deckDraft))}catch{}}
  function saveMatch(){try{if(game&&game.mode!=='hotseat')localStorage.setItem('ap2tcg.match.v02',JSON.stringify({version:3,game,quizTurn}));else localStorage.removeItem('ap2tcg.match.v02');}catch{}}
  function validSavedGame(g){
    if(!g||!['ai','tutorial'].includes(g.mode)||!Array.isArray(g.players)||g.players.length!==2||!Number.isInteger(g.active)||g.active<0||g.active>1||!Number.isInteger(g.turn)||g.turn<1||!['main','response'].includes(g.phase))return false;
    if(!Array.isArray(g.log)||!Array.isArray(g.events)||!(g.winner===null||g.winner===0||g.winner===1))return false;
    if(g.mode==='tutorial'&&(!Number.isInteger(g.missionId)||g.missionId<1||g.missionId>E.MISSIONS.length||!Number.isInteger(g.tutorialStep)||g.tutorialStep<0||g.tutorialStep>E.MISSIONS[g.missionId-1].steps.length))return false;
    const validCards=ids=>Array.isArray(ids)&&ids.length<=200&&ids.every(id=>Object.hasOwn(E.CARDS,id));
    const systemIds=E.SYSTEMS.map(s=>s.id),legalSystem=new Map(E.SYSTEMS.map(s=>[s.id,s]));
    if(g.phase==='response'){
      const q=g.pending;
      if(!q||![0,1].includes(q.owner)||![0,1].includes(q.defender)||q.owner===q.defender||
         !['ddos','exploit','internal','disk'].includes(q.card)||!legalSystem.has(q.target)||
         !Number.isInteger(q.damage)||q.damage<0||q.damage>3||
         !Number.isInteger(q.prevent)||q.prevent<0||q.prevent>3)return false;
    }
    return g.players.every((p,i)=>p&&p.id===i&&typeof p.name==='string'&&p.name.length<120&&
      Array.isArray(p.systems)&&p.systems.length===systemIds.length&&systemIds.every(id=>p.systems.some(s=>
        s?.id===id&&Number.isInteger(s.hp)&&s.hp>=0&&s.hp<=legalSystem.get(id).maxHp&&
        Array.isArray(s.scannedBy)&&s.scannedBy.every(x=>x===0||x===1)&&
        typeof s.vulnerable==='boolean'&&
        ['fortified','raidCharge','backupCharge'].every(k=>Number.isInteger(s[k])&&s[k]>=0&&s[k]<=100)))&&
      validCards(p.hand)&&validCards(p.deck)&&validCards(p.discard)&&
      Number.isInteger(p.kp)&&p.kp>=0&&Number.isInteger(p.maxKp)&&p.maxKp>=3&&p.maxKp<=8&&p.kp<=p.maxKp&&
      Number.isInteger(p.segmentation)&&p.segmentation>=0&&p.segmentation<=100&&
      p.access&&typeof p.access.client==='boolean'&&typeof p.access.internal==='boolean');
  }
  function loadSavedEntry(){
    try{
      const entry=JSON.parse(localStorage.getItem('ap2tcg.match.v02')||'null');
      if(![2,3].includes(entry?.version)||!validSavedGame(entry.game))return null;
      entry.game.quizRequired=true;entry.game.quizPermit=null;
      if(!entry.game.quizMistakes||typeof entry.game.quizMistakes!=='object'||Array.isArray(entry.game.quizMistakes))entry.game.quizMistakes={};
      const q=entry.version===3?entry.quizTurn:null;
      const validQuiz=q&&typeof q.cardId==='string'&&Object.hasOwn(E.CARDS,q.cardId)&&[0,1].includes(q.player)&&q.question&&Array.isArray(q.question.options)&&q.question.options.length>=2&&q.question.options.every(x=>typeof x==='string')&&Number.isInteger(q.question.answer)&&q.question.answer>=0&&q.question.answer<q.question.options.length;
      // The game state remains the authority when a previously opened dialog is restored.
      const quizTurn=validQuiz&&!E.allowed(entry.game,q.player,q.cardId,q.target)?q:null;
      if(quizTurn?.wrongEver)entry.game.quizMistakes[quizMistakeKey(quizTurn.player,quizTurn.cardId)]=true;
      return {game:entry.game,quizTurn};
    }catch{return null;}
  }
  function loadMatch(){return loadSavedEntry()?.game||null;}
  function esc(x){return String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  const PATHS={
    shield:'<path d="M12 2 20 5v6c0 5-3 8-8 11C7 19 4 16 4 11V5z"/><path d="m9 12 2 2 4-4"/>',
    'shield-check':'<path d="M12 2 20 5v6c0 5-3 8-8 11C7 19 4 16 4 11V5z"/><path d="m9 12 2 2 4-4"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c5 5 5 13 0 18M12 3c-5 5-5 13 0 18"/>',
    monitor:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>',
    network:'<rect x="9" y="2" width="6" height="6" rx="1"/><rect x="2" y="16" width="6" height="6" rx="1"/><rect x="16" y="16" width="6" height="6" rx="1"/><path d="M12 8v4H5v4m7-4h7v4"/>',
    database:'<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 4 16 4 16 0V5M4 12c0 4 16 4 16 0"/>',
    search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5M10 7v7m-3-3h7"/>',
    zap:'<path d="m13 2-10 12h8l-1 8 11-13h-8z"/>',
    bug:'<rect x="7" y="7" width="10" height="13" rx="5"/><path d="M12 7V3m-5 7H3m4 5H3m14-5h4m-4 5h4M6 5l2 2m10-2-2 2"/>',
    mail:'<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 7 10 7 10-7"/>',
    route:'<circle cx="5" cy="5" r="2"/><circle cx="19" cy="19" r="2"/><path d="M5 7v5h14v5M10 3l4 4-4 4"/>',
    crosshair:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 1v4m0 14v4M1 12h4m14 0h4"/>',
    'hard-drive':'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 14h18M7 17h.01M11 17h.01"/>',
    wrench:'<path d="M21 7a6 6 0 0 1-8 7L6 21l-3-3 7-7a6 6 0 0 1 7-8l-4 4 4 4z"/>',
    lock:'<rect x="5" y="10" width="14" height="12" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    'git-branch':'<circle cx="6" cy="4" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="6" cy="20" r="2"/><path d="M6 6v12m0-6c0-4 12 0 12-4"/>',
    refresh:'<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5 11a7 7 0 0 1 12-5l3 6M19 13a7 7 0 0 1-12 5l-3-6"/>',
    'file-search':'<path d="M7 2h8l5 5v6M7 2v20h6M15 2v5h5"/><circle cx="17" cy="17" r="3"/><path d="m19.5 19.5 2 2"/>',
    terminal:'<rect x="2" y="3" width="20" height="18" rx="2"/><path d="m6 8 4 4-4 4m7 0h5"/>',
    swords:'<path d="m4 3 16 16M20 3 4 19M2 18l4 4m16-4-4 4"/>',
    book:'<path d="M12 5C8 3 5 3 2 4v16c4-1 7-1 10 1 3-2 6-2 10-1V4c-3-1-6-1-10 1zm0 0v16"/>',
    info:'<circle cx="12" cy="12" r="10"/><path d="M12 10v7M12 6h.01"/>',
    arrow:'<path d="m5 12 14 0m-6-6 6 6-6 6"/>',
    check:'<path d="m4 12 5 5L20 6"/>',
    x:'<path d="M5 5 19 19M19 5 5 19"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/>',
    spark:'<path d="m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z"/>',
    layers:'<path d="m12 2 10 5-10 5L2 7zm-10 9 10 5 10-5m-20 5 10 5 10-5"/>',
    server:'<rect x="4" y="3" width="16" height="6" rx="1"/><rect x="4" y="11" width="16" height="6" rx="1"/><path d="M7 6h.01M7 14h.01M12 17v4"/>',
    users:'<circle cx="8" cy="8" r="3"/><circle cx="17" cy="9" r="2"/><path d="M2 20v-2c0-6 12-6 12 0v2M15 16c4-1 7 0 7 4"/>',
    card:'<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 7h8M8 11h8M8 15h5"/>',
    crown:'<path d="m2 7 5 4 5-7 5 7 5-4-2 13H4z"/>',
    target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    chevron:'<path d="m9 5 7 7-7 7"/>',
    key:'<circle cx="7" cy="15" r="4"/><path d="M10 12 20 2l2 2-3 3 2 2-3 3-2-2-4 4"/>',
    'map-pin':'<path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
    wifi:'<path d="M2 9a16 16 0 0 1 20 0M5 13a11 11 0 0 1 14 0m-11 4a6 6 0 0 1 8 0M12 21h.01"/>'
  };
  function icon(name,size=20){return `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${PATHS[name]||PATHS.card}</svg>`;}
  const modeInfo={blue:{first:'#103f76',second:'#071a36',glow:'#40aeff'},red:{first:'#7c292d',second:'#2e0812',glow:'#ff806e'},purple:{first:'#583672',second:'#1b122e',glow:'#d79cff'},gold:{first:'#826432',second:'#2d2414',glow:'#ffd38b'},green:{first:'#25694e',second:'#102b2c',glow:'#79efb4'}};
  function art(card){
    const t=modeInfo[card.tint], id=card.id, glyph=PATHS[card.icon]||PATHS.card;
    const seed=[...id].reduce((a,v)=>a+v.charCodeAt(0),0), n=seed%4;
    const structure=`<g opacity=".65" fill="#07101e"><path d="M0 156V96l21-22 13 15 13-35 20 24 15-46 19 29 20-18 16 28 20-31 16 26 23-20v110Z"/><path d="M0 155 52 113 91 132 138 94 200 128v32Z" fill="#020711"/></g>`;
    const network=`<g stroke="${t.glow}" stroke-width="1.8" opacity=".65" fill="none"><path d="M12 105H48L72 75H126L153 51H188"/><path d="M18 32h43l30 25h39l36 29h22"/><circle cx="48" cy="105" r="3" fill="${t.glow}"/><circle cx="126" cy="75" r="3" fill="${t.glow}"/><circle cx="153" cy="51" r="3" fill="${t.glow}"/></g>`;
    const objects={
      scan:`<g transform="translate(46 20)"><circle cx="52" cy="51" r="40" stroke="${t.glow}" stroke-width="3" fill="#112943bb"/><path d="M52 11V90M12 51H92M23 22 81 80" stroke="${t.glow}" stroke-width="1.5" opacity=".7"/><path d="M52 51 89 35" stroke="#e8f7ff" stroke-width="4"/><circle cx="52" cy="51" r="7" fill="${t.glow}"/></g>`,
      ddos:`<g><path d="M96 14 68 68h23l-18 55 65-73h-33l21-36" fill="#ff9b4d" stroke="#ffdc9c" stroke-width="3"/><path d="M30 25 44 54 30 57 54 91M167 28 145 55 166 68 138 100" stroke="#ff6d5d" stroke-width="7" stroke-linecap="round"/></g>`,
      phishing:`<g transform="translate(44 31)"><rect width="112" height="78" x="0" y="0" rx="8" fill="#102238" stroke="${t.glow}" stroke-width="3"/><path d="M3 6 56 47 109 6" fill="none" stroke="#ffdce8" stroke-width="4"/><path d="M76 5c2-26 46-20 43 7s-24 22-28 11" stroke="#ff80d4" stroke-width="4" fill="none"/></g>`,
      pivot:`<g fill="#15365b" stroke="${t.glow}" stroke-width="4"><circle cx="46" cy="65" r="15"/><circle cx="100" cy="31" r="15"/><circle cx="160" cy="83" r="15"/><path d="M61 56 85 42M113 43 145 73" stroke-width="7" stroke-dasharray="7 5"/><path d="m138 66 9 9 13-3" fill="none"/></g>`,
      raid:`<g>${[42,96,150].map(x=>`<rect x="${x-20}" y="36" width="40" height="82" rx="6" fill="#0c2737" stroke="${t.glow}" stroke-width="3"/><path d="M${x-12} 57h24M${x-12} 76h24M${x-12} 95h24" stroke="#9bffcf" stroke-width="4"/><circle cx="${x}" cy="110" r="3" fill="#c6fbdc"/>`).join('')}</g>`,
      backup:`<g><circle cx="94" cy="69" r="47" stroke="${t.glow}" stroke-width="11" fill="#092b2e8c" stroke-dasharray="204 85" transform="rotate(-65 94 69)"/><path d="m46 34 8 31 29-13" stroke="${t.glow}" stroke-width="11" stroke-linecap="round" stroke-linejoin="round" fill="none"/><path d="M95 34v35h25" stroke="#d4ffef" stroke-width="8" fill="none"/></g>`,
      backupplan:`<g><path d="M54 50h92v65H54z" fill="#0c2c30" stroke="${t.glow}" stroke-width="5"/><path d="M74 49V32h52v17" stroke="#e9fbed" stroke-width="4" fill="none"/><rect x="75" y="67" width="50" height="29" rx="4" stroke="${t.glow}" stroke-width="3" fill="none"/><path d="M100 68v28" stroke="#d2ffe4" stroke-width="3"/></g>`,
      fortify:`<g fill="#152b42" stroke="#ffc978" stroke-width="3"><path d="M34 111V42h22V29h22v13h44V29h22v13h22v69Z"/><path d="M28 113h145" stroke-width="7"/><path d="M89 112V75h24v37" fill="#473326"/></g>`,
      segmentation:`<g>${['#5fb9ff','#ffbf68','#b18dff'].map((c,i)=>`<rect x="${12+i*61}" y="38" width="51" height="67" rx="7" stroke="${c}" stroke-width="3" fill="${c}20"/><path d="M${25+i*61} 58h25M${25+i*61} 76h25" stroke="${c}" stroke-width="3"/>`).join('')}<path d="M64 70h9M125 70h9" stroke="#ffe19c" stroke-width="5" stroke-dasharray="4 7"/></g>`,
      script:`<g><rect x="32" y="28" width="137" height="95" rx="10" fill="#081823" stroke="${t.glow}" stroke-width="4"/><path d="m53 56 21 17-21 17M89 92h54" fill="none" stroke="#c8ffe0" stroke-width="6"/><circle cx="48" cy="39" r="4" fill="#ffc080"/><circle cx="63" cy="39" r="4" fill="#ffe0a6"/></g>`,
      disk:`<g><rect x="58" y="20" width="88" height="100" rx="12" fill="#1a2431" stroke="${t.glow}" stroke-width="4"/><circle cx="101" cy="67" r="30" fill="#172b35" stroke="#c8d6df" stroke-width="5"/><circle cx="101" cy="67" r="7" fill="#ffd4bf"/><path d="M117 32 93 55l22 19-19 18" stroke="#ff8e70" stroke-width="5" fill="none"/></g>`,
      dnscheck:`<g fill="#12334e" stroke="#86dfff" stroke-width="3"><circle cx="100" cy="23" r="13"/><circle cx="36" cy="87" r="15"/><circle cx="100" cy="117" r="15"/><circle cx="163" cy="87" r="15"/><path d="M92 36 44 75M108 36 155 75M52 92 86 108M148 92 113 108" fill="none" stroke-dasharray="4 5"/></g>`
    };
    const motif=objects[id]||`<g transform="translate(61 30)"><circle cx="39" cy="40" r="56" fill="${t.glow}18" stroke="${t.glow}77" stroke-width="2"/><g transform="translate(0 0) scale(3.3)" fill="none" stroke="${t.glow}" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round">${glyph}</g></g>`;
    return `<svg class="art-svg" viewBox="0 0 200 150" role="img" aria-label="Illustration: ${esc(card.name)}"><defs><linearGradient id="c${id}" x1="0" y1="0" x2=".9" y2="1"><stop stop-color="${t.first}"/><stop offset="1" stop-color="${t.second}"/></linearGradient><radialGradient id="r${id}"><stop stop-color="${t.glow}" stop-opacity=".5"/><stop offset="1" stop-color="${t.glow}" stop-opacity="0"/></radialGradient></defs><rect width="200" height="150" fill="url(#c${id})"/><circle cx="103" cy="65" r="90" fill="url(#r${id})"/>${structure}${network}<g opacity=".27" stroke="${t.glow}" fill="none"><path d="M0 ${22+n*4}H200M0 133H200"/><circle cx="100" cy="68" r="68"/></g>${motif}<path d="M0 147h200" stroke="${t.glow}" stroke-width="6" opacity=".7"/></svg>`;
  }

  function cardUI(id,index,playerIndex){
    const card=E.CARDS[id], isChosen=selected?.id===id&&selected?.index===index;
    const status=game?E.cardPlayability(game,playerIndex,id):{playable:true,reason:''};
    const disabled=!status.playable;
    const current=game?.mode==='tutorial'?E.currentStep(game):null;
    const guided=current?.card===id, short=card.desc.split(/[.!?]/)[0];
    return `<button class="game-card ${card.tint} ${isChosen?'chosen':''} ${disabled?'dimmed':''} ${guided?'guided guide-mark':''}" data-action="card" data-card="${id}" data-index="${index}" data-player="${playerIndex}" aria-label="${esc(card.name)}. Kosten ${card.cost} KP. ${esc(card.desc)} ${esc(status.reason)}" title="${esc(disabled?status.reason:card.desc)}">
      ${guided?'<span class="guide-pin">'+icon('target',12)+' SPIELEN</span>':''}${disabled?`<span class="card-blocker" title="${esc(status.reason)}">${icon('lock',13)}</span>`:''}
      <div class="card-head"><span class="card-name">${esc(card.name)}</span><span class="card-cost">${card.cost}<small>KP</small></span></div>
      <div class="card-art">${art(card)}<span class="art-category">${icon(card.icon,18)}</span></div>
      <div class="card-type">${icon(card.icon,15)} <span>${esc(card.category)}</span><span class="card-type-dot"></span></div>
      <div class="card-description">${esc(short)}.</div><div class="card-foot"><span>AP2 · ${card.category.toUpperCase()}</span><span>${icon('spark',12)}</span></div>
    </button>`;
  }

  const ZONE_META={gateway:{short:'NETZGRENZE',sub:'Kontrolliert Zugriffe',icon:'shield',hint:'Öffentlicher Grenzübergang'},web:{short:'DMZ',sub:'Öffentlicher Dienst',icon:'globe',hint:'Von außen erreichbar'},client:{short:'CLIENTNETZ',sub:'Benutzer-Endgeräte',icon:'monitor',hint:'Zugang durch Phishing'},dns:{short:'SERVERNETZ',sub:'Namensauflösung + Anmeldung',icon:'network',hint:'Servernetz-Zugang benötigt'},data:{short:'SERVERNETZ',sub:'Kritische Daten',icon:'database',hint:'Servernetz-Zugang benötigt'}};
  function systemArtwork(s){
    const stroke=s.id==='gateway'?'#f6c985':s.id==='web'?'#80d9ff':s.id==='client'?'#92baff':s.id==='dns'?'#d8b8ff':'#95e7bb';
    const base=`<g fill="#061626" stroke="${stroke}" stroke-width="2.5" stroke-linejoin="round">`;
    const scenes={
      gateway:`<path d="M28 114V48h13V30h24v18h23V30h24v18h13v66z"/><path d="M43 72h68M43 92h68"/><path d="M69 114V84h16v30" fill="#1a2a3b"/><path d="M36 41h81" stroke-width="4"/>`,
      web:`<path d="M42 114V31l34-16 34 16v83z"/><path d="M41 45h70M41 64h70M41 84h70M41 103h70"/><path d="M75 22v92"/><circle cx="77" cy="69" r="24" fill="#1d4568" stroke="${stroke}" stroke-width="3"/><path d="M53 69h48M77 45c12 16 12 32 0 48M77 45c-12 16-12 32 0 48" fill="none"/>`,
      client:`<path d="M15 40h55v45H15zM84 32h55v53H84z"/><path d="M23 48h39v29H23zM93 41h38v35H93z" fill="#2b6285"/><path d="M43 85v17m-18 0h35M111 85v17m-18 0h36"/><path d="M8 113h145"/>`,
      dns:`<path d="M16 83h39v32H16zM101 83h39v32h-39zM60 14h36v36H60z"/><path d="M78 50v14H36v18M78 64h44v18" fill="none" stroke-width="5"/><circle cx="78" cy="32" r="8" fill="${stroke}"/><circle cx="36" cy="99" r="8" fill="${stroke}"/><circle cx="121" cy="99" r="8" fill="${stroke}"/>`,
      data:`<ellipse cx="78" cy="35" rx="47" ry="17" fill="#16382f"/><path d="M31 35v62c0 24 94 24 94 0V35"/><path d="M31 59c0 22 94 22 94 0M31 80c0 22 94 22 94 0" fill="none"/><ellipse cx="78" cy="35" rx="47" ry="17" fill="#204e41"/><circle cx="78" cy="35" r="9" fill="${stroke}"/>`
    };
    return `<svg class="system-artwork" viewBox="0 0 156 132" aria-hidden="true"><defs><radialGradient id="sys-${s.id}"><stop stop-color="${stroke}" stop-opacity=".22"/><stop offset="1" stop-color="${stroke}" stop-opacity="0"/></radialGradient></defs><ellipse cx="78" cy="74" rx="76" ry="64" fill="url(#sys-${s.id})"/><path d="M14 120h128" stroke="${stroke}" stroke-width="1.5" opacity=".45"/>${base}${scenes[s.id]}</g><g fill="${stroke}"><circle cx="15" cy="118" r="3"/><circle cx="142" cy="118" r="3"/></g></svg>`;
  }
  function targetAvailability(s,owner,selectable,asOpponent){
    if(selected&&selectable)return {name:s.hp===0?'RÜCKSPIEL MÖGLICH':'GÜLTIGES ZIEL',kind:'legal',symbol:'target'};
    if(s.hp===0)return {name:'AUSFALL',kind:'down',symbol:'x'};
    if(selected)return {name:'NICHT WÄHLBAR',kind:'locked',symbol:'lock'};
    if(asOpponent){if(['gateway','web'].includes(s.id))return {name:'ÖFFENTLICH',kind:'public',symbol:'globe'};
      const p=game.players[viewer()],has=s.id==='client'?p.access.client:p.access.internal;
      return has?{name:'ZUGANG',kind:'legal',symbol:'check'}:{name:'GESPERRT',kind:'locked',symbol:'lock'};}
    return {name:'GESCHÜTZT',kind:'friendly',symbol:'shield'};
  }
  function viewer(){if(!game)return 0;if(game.mode==='hotseat')return game.phase==='response'?game.pending.defender:game.active;return 0;}
  function systemsMarkup(owner,asOpponent){
    const p=game.players[owner];const eligible=selected?E.eligibleTargets(game,selected.id,selected.player):[];
    const guideStep=E.currentStep(game);
    function sysTile(s){
      const selectable=eligible.some(t=>t.owner===owner&&t.system===s.id);
      const guide=game.mode==='tutorial'&&!game.completed&&((guideStep?.type==='select'&&guideStep.owner===owner&&guideStep.system===s.id)||(guideStep?.target===s.id&&guideStep?.targetOwner===owner&&selected?.id===guideStep.card));
      const destroyed=s.hp===0, scanned=s.scannedBy.includes(viewer()), state=targetAvailability(s,owner,selectable,asOpponent);
      const advice=selected?E.targetAdvice(game,selected.id,selected.player,owner,s.id):null;
      const estimate=advice?.legal&&['ddos','exploit','internal','disk'].includes(selected.id)?`<span class="damage-preview ${advice.damage?'':'blocked'}">${icon(advice.damage?'zap':'shield',13)} ${advice.damage?'-'+advice.damage+' HP':'0 HP'}</span>`:'';
      const flags=[s.raidCharge?{icon:'database',tip:`RAID ${s.raidCharge}`} :null,s.backupCharge?{icon:'refresh',tip:`Sicherungen ${s.backupCharge}`}:null,s.fortified?{icon:'shield-check',tip:`Härtung ${s.fortified}`}:null,s.vulnerable?{icon:'bug',tip:'Schwachstelle bestätigt'}:null,scanned?{icon:'search',tip:'Analysiert'}:null].filter(Boolean);
      const meta=ZONE_META[s.id], zoneIcon=icon(meta.icon,13);
      return `<button class="system-tile system-${s.id} ${destroyed?'destroyed':''} ${selected?(selectable?'targetable is-legal':'is-locked'):''} ${guide?'guided guide-mark':''} ${inspecting?.owner===owner&&inspecting?.id===s.id?'inspected':''} ${blockedTarget?.owner===owner&&blockedTarget?.key===s.id?'blocked-explained':''}" data-action="system" data-owner="${owner}" data-system="${s.id}" data-valid="${selectable?'yes':'no'}" title="${esc(advice?.reason||s.name+': '+meta.hint+'. '+s.desc)}" aria-label="${asOpponent?'Gegner':'Eigenes System'}: ${esc(s.name)}, ${s.hp} von ${s.maxHp} Integrität. ${esc(state.name)}.">
        ${guide?'<span class="guide-pin">'+icon('target',12)+' HIER</span>':''}
        <div class="system-zone">${zoneIcon}<span>${esc(meta.short)}</span></div>
        <div class="system-picture">${systemArtwork(s)}${estimate}<span class="access-indicator ${state.kind}">${icon(state.symbol,14)}<span>${state.name}</span></span></div>
        <div class="system-bottom"><div class="system-name">${esc(s.name)}</div><div class="system-description">${esc(meta.sub)}</div>
        <div class="system-vitals"><span class="hp-icon">${icon('shield',14)} <strong>${s.hp}/${s.maxHp}</strong></span><span class="mini-hp">${Array.from({length:s.maxHp},(_,i)=>`<i class="${i<s.hp?'is-full':''}"></i>`).join('')}</span></div></div>
        ${flags.length?`<div class="system-flags">${flags.map(f=>`<span title="${esc(f.tip)}" aria-label="${esc(f.tip)}">${icon(f.icon,13)}</span>`).join('')}</div>`:''}
      </button>`;
    }
    return `<section class="network-field ${asOpponent?'opponent':'own'}" aria-label="${asOpponent?'Gegnernetz':'Eigenes Netzwerk'}">
      <div class="field-heading"><span class="network-avatar">${icon(asOpponent?'crosshair':'shield',20)}</span><span class="field-person"><strong>${esc(p.name)}</strong><small>${asOpponent?'GEGNERISCHES NETZ':'DEINE INFRASTRUKTUR'}</small></span><span class="field-pills"><span class="kp-mini">${icon('spark',14)} ${p.kp} KP</span><span class="outage-pill">${icon('server',14)} ${p.systems.filter(s=>s.hp<=0).length}/5 AUSFÄLLE</span></span></div>
      <div class="system-line">${p.systems.map(sysTile).join('')}</div>
    </section>`;
  }

  function tutorialGuide(){
    if(!game||game.mode!=='tutorial')return null;
    const mission=E.MISSIONS.find(m=>m.id===game.missionId),step=E.currentStep(game);
    if(!step)return {step:null,mission,title:'Mission abgeschlossen',detail:'Alle Aufgaben erfüllt.',where:'',selector:'',button:'',tip:''};
    const card=step.card?E.CARDS[step.card]:null;
    if(game.phase==='response'&&game.pending?.defender===1)return {step,mission,title:'Angriff wird gerade aufgelöst',detail:'Der Computer reagiert automatisch. Danach erscheint deine nächste Aufgabe.',where:'SPIELFELDMITTE · ANGRIFF',selector:'.attack-banner',button:'Angriff zeigen',tip:'Im normalen Duell erhält der Verteidiger ein Reaktionsfenster.'};
    if(step.type==='select'){
      const system=E.SYSTEMS.find(s=>s.id===step.system);
      return {step,mission,title:`${system.name} anklicken`,detail:`Wähle das markierte System im ${step.owner===0?'eigenen':'gegnerischen'} Netzwerk.`,where:step.owner===0?'DEIN NETZWERK (BLAU)':'GEGNERISCHES NETZWERK (ROT)',selector:`[data-action="system"][data-owner="${step.owner}"][data-system="${step.system}"]`,button:'System zeigen',tip:step.text};
    }
    if(step.type==='quiz')return {step,mission,title:'Prüfungsfrage beantworten',detail:'Lies die Aufgabenstellung und wähle eine der drei Antworten.',where:'PRÜFUNGSFRAGE IN DER SPIELFELDMITTE',selector:'.quiz-banner',button:'Frage zeigen',tip:'Die Antwort soll fachlich begründet werden können. Bei einer falschen Antwort kannst du erneut wählen.'};
    if(step.type==='incident'||step.type==='aclIncident')return {step,mission,title:step.type==='incident'?'Laufwerksausfall simulieren':'ACL-Schutz testen',detail:'Benutze die hervorgehobene Test-Schaltfläche in der Mitte des Spielfelds.',where:'SPIELFELDMITTE · TESTAKTION',selector:`[data-action="${step.type}"]`,button:'Test zeigen',tip:step.text};
    if(card){
      const choosingTarget=Boolean(selected?.id===step.card)&&card.target!=='none';
      const owner=step.targetOwner!=null?step.targetOwner:card.target==='self'?0:1;
      const target=step.target||((card.id==='internal'||card.id==='disk')?'data':null);
      if(choosingTarget&&target){
        const system=E.SYSTEMS.find(s=>s.id===target);
        return {step,mission,title:`Jetzt ${system.name} als Ziel wählen`,detail:'Klicke auf das gelb markierte Zielsystem, um die Karte auszuführen.',where:owner===0?'DEIN NETZWERK (BLAU)':'GEGNERISCHES NETZWERK (ROT)',selector:`[data-action="system"][data-owner="${owner}"][data-system="${target}"]`,button:'Ziel zeigen',tip:step.text};
      }
      return {step,mission,title:`Karte „${card.name}“ auswählen`,detail:step.type==='defend'?'Reagiere jetzt: Klicke auf die markierte Verteidigungskarte.':card.target==='none'?'Klicke auf die markierte Handkarte. Der Effekt wird sofort ausgeführt.':'Klicke zuerst auf die markierte Handkarte. Danach wählst du das hervorgehobene Zielsystem.',where:step.type==='defend'?'DEINE HAND · VERTEIDIGUNG':'DEINE HAND · AKTIONSKARTEN',selector:`[data-action="card"][data-card="${step.card}"]`,button:'Karte zeigen',tip:step.text};
    }
    return {step,mission,title:'Nächste Aktion ausführen',detail:step.text||'',where:'SPIELFELD',selector:'.arena-top',button:'Anweisung zeigen',tip:step.text||''};
  }
  function progressLine(){return `<div class="progress-mini">${E.MISSIONS.map(m=>`<div class="pip ${progress.includes(m.id)?'done':''} ${game?.missionId===m.id?'current':''}" title="Mission ${m.id}"></div>`).join('')}</div>`;}
  function missionPanel(){
    const g=tutorialGuide(), mission=g.mission,step=g.step,completed=Math.min(game.tutorialStep,mission.steps.length);
    const symbol=step?.type==='select'?'target':step?.type==='quiz'?'book':step?.type==='incident'||step?.type==='aclIncident'?'wrench':step?.type==='defend'?'shield':'card';
    const headerLabel=selected&&step?.card?'ZIEL WÄHLEN':step?.type==='select'?'SYSTEM FINDEN':step?.type==='quiz'?'FRAGE LÖSEN':step?.type==='defend'?'VERTEIDIGEN':step?.type==='incident'||step?.type==='aclIncident'?'TEST STARTEN':'KARTE SPIELEN';
    return `<section class="tutorial-strip tutor-panel" role="region" aria-label="Nächste Aktion" aria-live="polite">
      <div class="tutor-step-icon">${icon(symbol,28)}<span>${completed+1}</span></div>
      <div class="tutor-main"><div class="tutor-top"><span class="tutor-label">MISSION ${mission.id} · ${esc(mission.title)}</span><span class="tutor-counter">${completed+1} / ${mission.steps.length}</span></div>
      <div class="tutor-steps" aria-label="Missionsfortschritt">${mission.steps.map((s,i)=>`<span class="tutor-step ${i<completed?'done':i===completed?'active':''}" title="Schritt ${i+1}">${i<completed?icon('check',10):''}</span>`).join('')}</div>
      <div class="tutor-command"><span class="tutor-signal">${headerLabel}</span><strong>${esc(g.title)}</strong></div>
      ${guideTipOpen?`<div class="visual-tip">${icon('info',16)} ${esc(g.tip)}</div>`:''}
      ${guideError?`<div class="tutor-error" role="alert">${icon('info',16)} ${esc(guideError)}</div>`:''}</div>
      <div class="tutor-controls"><button class="btn primary tutor-jump" data-action="focusguide">${icon('target',18)} <span>${esc(g.button)}</span></button><button class="btn secondary icon-help" data-action="togglehint" aria-label="Erklärung anzeigen" title="Schritt erklären">${icon('info',18)}</button></div>
    </section>`;
  }

  function guideDock(){
    if(!game||game.mode!=='tutorial'||game.completed||modal)return '';
    const g=tutorialGuide();return `<div class="guide-dock" role="complementary" aria-label="Nächster Tutorial-Schritt"><span class="guide-mobile-icon">${icon('target',19)}</span><div class="guide-dock-info"><small>${game.tutorialStep+1}/${g.mission.steps.length} · JETZT</small><strong>${esc(g.title)}</strong></div><button class="btn primary" data-action="focusguide" aria-label="${esc(g.button)}">${icon('arrow',20)}</button></div>`;
  }

  function focusGuide(){const g=tutorialGuide();const node=g?.selector&&document.querySelector(g.selector);if(!node){showToast('Das Zielelement ist derzeit nicht verfügbar.');return;}node.scrollIntoView({behavior:'smooth',block:'center',inline:'nearest'});node.classList.add('guide-focus');if(node.matches('button'))node.focus({preventScroll:true});setTimeout(()=>node.classList.remove('guide-focus'),1600);}
  function actionPanel(){
    const view=viewer(),step=E.currentStep(game);
    if(game.mode==='tutorial'&&step?.type==='quiz')return `<div class="quiz-banner guide-mark"><div class="quiz-icon">${icon('book',27)}</div><div class="quiz-body"><div class="eyebrow">AP2 · ${esc(E.MISSIONS.find(m=>m.id===game.missionId).tag)} · WÄHLE EINE ANTWORT</div><strong>${esc(step.question)}</strong><div class="quiz-options">${step.options.map((option,i)=>`<button class="btn secondary quiz-opt" data-action="answer" data-index="${i}"><span>${String.fromCharCode(65+i)}</span> ${esc(option)}</button>`).join('')}</div>${quizFeedback?`<p class="quiz-feedback">${esc(quizFeedback)}</p>`:''}</div></div>`;
    if(game.phase==='response'){
      const atk=game.pending,card=E.CARDS[atk.card],target=E.findSys(game,atk.defender,atk.target);
      return `<div class="attack-banner"><div class="attack-pulse">${icon('zap',24)}</div><div class="action-explain"><strong>ANGRIFF · ${esc(card.name)}</strong><p>${icon(target.icon,16)} ${esc(target.name)} <span class="damage-value">−${atk.damage} HP</span></p></div><span class="reaction-tag">${icon('shield',16)} REAKTION</span>${game.mode!=='tutorial'&&atk.defender===view?`<button class="btn secondary" data-action="allow">Schaden zulassen</button>`:''}</div>`;
    }
    if(selected){const c=E.CARDS[selected.id],count=E.eligibleTargets(game,selected.id,selected.player).length;
      return `<div class="select-banner">${icon('target',24)}<div class="action-explain"><strong>${esc(c.name)} · ${c.cost} KP</strong><p>${count} gültige Ziel${count===1?'':'e'} leuchten gelb. Wähle eines aus.</p>${blockedTarget?`<div class="blocked-reason">${icon('lock',15)} ${esc(blockedTarget.reason)}</div>`:''}</div><span class="reaction-tag">${icon('target',15)} ZIEL WÄHLEN</span><button class="btn small secondary" data-action="cancel">${icon('x',16)} Abbrechen</button></div>`;}
    if(game.mode==='tutorial'&&step?.type==='incident')return `<div class="select-banner incident-banner">${icon('hard-drive',23)}<div class="action-explain"><strong>Laufwerk testen</strong><p>RAID-Fehlertoleranz prüfen</p></div><button class="btn primary guide-mark" data-action="incident">${icon('zap',16)} Ausfall simulieren</button></div>`;
    if(game.mode==='tutorial'&&step?.type==='aclIncident')return `<div class="select-banner incident-banner">${icon('shield',23)}<div class="action-explain"><strong>Segmentgrenze testen</strong><p>ACL-Regel kontrollieren</p></div><button class="btn primary guide-mark" data-action="aclIncident">${icon('target',16)} Test starten</button></div>`;
    return `<div class="status-banner">${icon(game.active===view?'spark':'clock',18)} <span>${game.mode==='tutorial'?'Markiertes Element verwenden':game.active===view?'Du bist am Zug · Karte wählen oder KP zurückhalten':'Gegner ist am Zug'}</span><span class="status-key">${icon('shield',14)} Reaktionen benötigen KP</span></div>`;
  }

  function viewHand(){
    const v=viewer(),p=game.players[v];
    if(game.mode==='hotseat'&&handoff)return '';
    return `<section class="hand-section"><div class="hand-head"><div class="hand-title">${icon('layers',21)} <div><small>DEIN ARSENAL</small><strong>${game.mode==='hotseat'?esc(p.name)+' · ':''}Handkarten <span>(${p.hand.length})</span></strong></div></div><div class="hand-counter"><span>${icon('layers',15)} ${p.deck.length} Deck</span><span>${icon('refresh',15)} ${p.discard.length} Ablage</span></div></div><div class="hand-scroll" role="group" aria-label="Deine Handkarten">${p.hand.length?p.hand.map((id,i)=>cardUI(id,i,v)).join(''):'<div class="empty-hand">'+icon('card',28)+(game.mode==='tutorial'?' In diesem Schritt wird keine Handkarte benötigt.':' Keine Handkarten. Nächste Runde ziehen.')+'</div>'}</div></section>`;
  }

  function routeFor(key,from){
    const access=game.players[from].access;
    if(key==='gateway')return 'Netzgrenze: öffentlich erreichbar. Nur passende Angriffsarten können hier Schaden verursachen.';
    if(key==='web')return 'DMZ: öffentlich erreichbar. Dienstanalyse und Überlastungsangriff sind mögliche Einstiege.';
    if(key==='client')return access.client?'Client-Zugang besteht. Laterale Bewegung kann Servernetz-Zugang eröffnen.':'Client-Zugang fehlt. Eine Phishing-Karte kann diesen Einstieg eröffnen.';
    return access.internal?'Servernetz-Zugang vorhanden. Gezielte Angriffe sind jetzt möglich.':'Internes Servernetz gesperrt. Erst Phishing im Clientnetz und dann laterale Bewegung (bei erlaubender ACL).';
  }
  function cardDetail(){
    if(selected){const c=E.CARDS[selected.id];return `<div class="inspector-art">${art(c)}</div><div class="inspector-heading">${icon(c.icon,19)} <strong>${esc(c.name)}</strong><span>${c.cost} KP</span></div><p class="inspector-text">${esc(c.desc)}</p><details class="ap2-expand"><summary>${icon('book',15)} AP2-Fachwissen</summary><p>${esc(c.ap2)}</p></details>`;}
    if(inspecting){const s=E.findSys(game,inspecting.owner,inspecting.id),type=ZONE_META[s.id],enemy=inspecting.owner!==viewer(),status=targetAvailability(s,inspecting.owner,false,enemy);
      return `<div class="inspector-art system-inspector">${systemArtwork(s)}</div><div class="inspector-heading">${icon(s.icon,19)} <strong>${esc(s.name)}</strong></div><div class="inspector-metrics"><span>${icon('shield',15)} ${s.hp}/${s.maxHp} HP</span><span>${icon(type.icon,15)} ${esc(type.short)}</span></div><p class="inspector-text">${esc(type.sub)}. ${esc(type.hint)}.</p><div class="access-summary ${status.kind}">${icon(status.symbol,16)} ${status.name}</div>${enemy?`<div class="route-hint"><strong>${icon('route',16)} Angriffsweg</strong><p>${esc(routeFor(s.id,viewer()))}</p><div class="route-steps">${(s.id==='data'||s.id==='dns'?['Phishing','Laterale Bewegung','Systemangriff']:s.id==='client'?['Phishing']:['Direkter Dienstzugriff']).map(t=>`<span>${esc(t)}</span>`).join('')}</div></div>`:''}<details class="ap2-expand"><summary>${icon('book',15)} Technischer Hintergrund</summary><p>${esc(s.desc)}</p>${s.id==='dns'?'<p>DNS für Namensauflösung; Verzeichnisdienst für Benutzeranmeldung.</p>':''}</details>`;}
    return `<div class="inspector-default"><div class="inspect-orb">${icon('target',35)}</div><strong>Fünf Ziele, fünf Funktionen</strong><p>Klicke ein System an. Hier erscheinen Details und Erreichbarkeit.</p><div class="role-legend">${[['gateway','Netzgrenze'],['web','DMZ · öffentlich'],['client','Client-Zugang'],['dns','Namensauflösung'],['data','Kritisches Ziel']].map(([id,role])=>`<div>${icon(ZONE_META[id].icon,18)} <span>${role}</span></div>`).join('')}</div></div>`;
  }

  function gameScreen(){
    const v=viewer(),p=game.players[v],opp=game.players[1-v];
    return `<div class="game-shell v04 ${game.mode==='tutorial'?'is-tutorial':''}">
      <header class="game-header"><button class="brand mini" data-action="home" aria-label="Zurück zum Hauptmenü"><span class="brand-crest">${icon('network',25)}</span><span><strong>AP2<span class="gold"> TCG</span></strong><small>NETWORK WARFARE</small></span></button><div class="header-center">${game.mode==='tutorial'?icon('book',16)+' TUTORIAL':game.mode==='hotseat'?icon('users',16)+' LOKALES DUELL':icon('swords',16)+' KI-DUELL'} <span class="turn-badge">ZUG ${game.turn} · ${settings.trivia.toUpperCase()} · ${effectiveNetworkShare()}/${100-effectiveNetworkShare()} ${settings.addonPacks.length?'NETZ/ADD-ON':'NETZWERK'}</span></div><div class="top-actions"><button class="btn text" data-action="help" title="Regeln">${icon('book',18)}<span>Regeln</span></button><button class="btn text" data-action="restart" title="Neustart">${icon('refresh',18)}<span>Neustart</span></button></div></header>
      <div class="game-layout v04-layout">
        <main class="arena v04-arena"><div class="arena-top">${game.mode==='tutorial'?missionPanel():`<div class="duel-strip">${icon('swords',24)} <span>${esc(game.players[0].name)}</span><b>VS</b><span>${esc(game.players[1].name)}</span><small>FÜNF SYSTEME PRO NETZ</small></div>`}</div>
          <div class="battle-legend" aria-label="Zielstatus-Legende"><span>${icon('target',14)} Gelb: anwählbar</span><span>${icon('lock',14)} Grau: gesperrt</span><span>${icon('zap',14)} Vorschau: Schaden</span><span>${icon('database',14)} Datenserver: kritisches Ziel</span></div>
          ${systemsMarkup(1-v,true)}
          <div class="attack-center">${actionPanel()}</div>
          ${systemsMarkup(v,false)}
          <div class="resource-bar"><div class="resource-title">${icon('spark',19)}<div><small>DEINE KAPAZITÄT</small><strong>${p.kp} <span>/ ${p.maxKp}</span> KP</strong></div></div><div class="resource-track">${Array.from({length:8},(_,i)=>`<span class="resource-cell ${i<p.kp?'filled':''} ${i>=p.maxKp?'locked':''}"></span>`).join('')}</div>${game.mode==='tutorial'?`<span class="resource-mini">${icon('book',17)} MISSION</span>`:`<button class="btn primary turn-end" data-action="end" ${game.phase!=='main'||game.active!==v?'disabled':''}>Zug beenden ${icon('arrow',19)}</button>`}</div>
          ${viewHand()}
        </main>
        <aside class="visual-sidebar"><div class="sidebar-title">${icon('info',17)} SYSTEM-INSPEKTOR</div><div class="sidebar-detail">${cardDetail()}</div><div class="sidebar-access"><span>${icon('key',17)} ZUGANG</span><div class="access-row"><div class="access ${p.access.client?'online':''}">${icon(p.access.client?'check':'lock',16)} Client</div><div class="access ${p.access.internal?'online':''}">${icon(p.access.internal?'check':'lock',16)} Server</div></div></div><details class="sidebar-logs"><summary>${icon('clock',17)} Letzte Ereignisse <span>${icon('chevron',14)}</span></summary><div class="event-log">${game.log.map((l,i)=>`<div class="log-entry ${i===0?'latest':''}">${esc(l)}</div>`).join('')}</div></details><div class="sidebar-victory">${icon('crown',18)} <span>3 Ausfälle oder Datenserver auf 0 HP</span></div></aside>
      </div>
    </div>${guideDock()}${renderModal()}`;
  }

  function deckEditor(){
    const total=Object.values(deckDraft).reduce((sum,n)=>sum+n,0),valid=deckOwned(deckDraft),cats=[...new Set(Object.values(E.CARDS).map(c=>c.category))];
    const counts=cats.map(cat=>({cat,count:Object.values(E.CARDS).filter(c=>c.category===cat).reduce((n,c)=>n+(deckDraft[c.id]||0),0)}));
    return `<div class="landing editor-page"><header class="landing-header"><button class="brand" data-action="home"><span class="brand-crest">${icon('network',26)}</span><span><strong>AP2<span class="gold"> TCG</span></strong><small>DECKLABOR · V1.3</small></span></button><button class="btn secondary" data-action="home">Zurück zum Menü</button></header>
    <div class="editor-header"><div><div class="eyebrow">DECKEDITOR · 40 KARTEN</div><h1>Baue deine <em>Strategie.</em></h1><p>Maximal vier Exemplare je Kartentyp. Änderungen werden lokal im Browser gespeichert, sobald das Deck gültig ist.</p></div><div class="deck-count ${valid?'complete':''}"><strong>${total}<small> / 40</small></strong><span>${valid?'SPIELBEREIT':'DECK UNVOLLSTÄNDIG'}</span></div></div>
    <div class="presets"><span>BASISDECKS</span>${Object.keys(E.BASIC_PRESETS).map(k=>`<button class="btn ${chosenPreset===k?'primary':'secondary'}" data-action="preset" data-preset="${k}">${k==='basic_angriff'?'Basis · Angriff':'Basis · Schutz'}</button>`).join('')}</div>
    <div class="collection-status">${icon('spark',18)} <strong>${collection.credits} Forschungspunkte</strong><span>Neue Karten durch richtige Antworten und Duelle verdienen.</span></div><div class="deck-stats">${counts.map(x=>`<div class="deck-stat"><span>${esc(x.cat)}</span><strong>${x.count}</strong></div>`).join('')}</div>
    <div class="editor-list">${Object.values(E.CARDS).map(c=>`<article class="editor-card ${ownedCount(c.id)===0?'collection-locked':''}"><div class="editor-icon ${c.tint}">${icon(c.icon,27)}</div><div class="editor-card-info"><div class="editor-title">${esc(c.name)} <span>${c.cost} KP · ${esc(c.category)}</span></div><p>${esc(c.desc)}</p><small>${esc(c.ap2)}</small><div class="owned-tag">${icon(ownedCount(c.id)?'check':'lock',13)} Sammlung: ${ownedCount(c.id)} / 4 ${ownedCount(c.id)<4?`<button class="btn secondary small-buy" data-action="buycard" data-id="${c.id}" ${collection.credits<cardCost(c.id)?'disabled':''}>${icon('spark',12)} +1 für ${cardCost(c.id)} FP</button>`:'· vollständig'}</div></div><div class="deck-controls"><button data-action="deckminus" data-id="${c.id}" aria-label="${esc(c.name)} reduzieren" ${(deckDraft[c.id]||0)<=0?'disabled':''}>−</button><strong>${deckDraft[c.id]||0}</strong><button data-action="deckplus" data-id="${c.id}" aria-label="${esc(c.name)} erhöhen" ${(deckDraft[c.id]||0)>=ownedCount(c.id)||total>=40?'disabled':''}>+</button></div></article>`).join('')}</div>
    <div class="editor-footer"><span>${valid?'Deck vollständig. Bereit für ein Testduell.':'Genau 40 Karten erforderlich. Die Auswahl bleibt bis zum Speichern als Entwurf erhalten.'}</span><button class="btn primary" data-action="saveDeck" ${valid?'':'disabled'}>${icon('check',17)} Deck speichern</button><button class="btn secondary" data-action="deckduel" ${valid?'':'disabled'}>${icon('swords',17)} Mit Deck gegen KI</button></div></div>`;
  }
  function countPackQuestions(packId){return TOPICS.filter(t=>t.packId===packId).reduce((n,t)=>n+Object.values(t.questions).reduce((a,qs)=>a+qs.length,0),0);}
  function packSelector(){
    return `<section class="pack-selector" aria-label="Fragen-Packs"><div class="pack-intro"><span>${icon('layers',18)} <b>FRAGEN-PAKETE</b></span><small>Netzwerktechnik immer aktiv · andere Themen frei zuschaltbar</small></div><div class="pack-grid">${PACKS.map(pk=>{
      const active=pk.id===CORE_ID||settings.addonPacks.includes(pk.id),count=countPackQuestions(pk.id);
      return `<button type="button" data-action="togglepack" data-pack="${esc(pk.id)}" aria-pressed="${active?'true':'false'}" ${pk.id===CORE_ID?'disabled':''} class="pack-choice ${active?'pack-active':''} ${pk.id===CORE_ID?'pack-core':''}">
        <span class="pack-icon">${icon(pk.icon,24)}</span><span class="pack-main"><b>${esc(pk.title)}</b><small>${esc(pk.description)}</small><em>${TOPICS.filter(t=>t.packId===pk.id).length} Themen · ${count} Fragen</em></span><span class="pack-status">${pk.id===CORE_ID?'GRUNDSPIEL':active?'AKTIV':'HINZUFÜGEN'}</span>
      </button>`;}).join('')}</div>
      <div class="share-control" aria-label="Fragenverhältnis einstellen">
        <div class="share-heading"><div><b>${icon('sliders',17)} FRAGENVERHÄLTNIS</b><small>Standard 70 % Netzwerk / 30 % Add-ons · in 5-%-Schritten</small></div><button type="button" class="share-reset" data-action="ratioreset" ${settings.networkShare===DEFAULT_NETWORK_SHARE?'disabled':''}>Standard 70/30</button></div>
        <div class="share-numbers"><span class="share-network">${icon('network',17)} <b data-share-network>${settings.networkShare} %</b> Netzwerk</span><span class="share-addon">${icon('layers',17)} <b data-share-addons>${100-settings.networkShare} %</b> Add-ons</span></div>
        <div class="share-bar" aria-hidden="true"><div data-share-bar-network class="share-bar-network" style="width:${settings.networkShare}%"></div><div data-share-bar-addon class="share-bar-addon" style="width:${100-settings.networkShare}%"></div></div>
        <label class="share-slider-label" for="network-share">Netzwerkanteil einstellen</label>
        <input id="network-share" class="share-slider" data-action="networkshare" type="range" min="0" max="100" step="5" value="${settings.networkShare}" aria-describedby="share-message" aria-valuetext="${settings.networkShare} Prozent Netzwerk und ${100-settings.networkShare} Prozent Add-ons">
        <div class="share-scale"><span>0 % Netzwerk</span><span>50 / 50</span><span>100 % Netzwerk</span></div>
        <p id="share-message" class="share-message">${settings.addonPacks.length?'Aktiv: '+settings.networkShare+' % Netzwerktechnik und '+(100-settings.networkShare)+' % aus '+settings.addonPacks.length+' Add-on-Paket(en).':'Aktuell 100 % Netzwerkfragen, da kein Add-on aktiv ist. Dein Wunschverhältnis bleibt gespeichert.'}</p>
      </div>
      <div class="pack-notice">${icon('network',16)} Effektiv ${effectiveNetworkShare()} % Netzwerkfragen · ${100-effectiveNetworkShare()} % aus aktivierten Add-ons. Packs ändern nur die Fragen, nicht die Kartensammlung.</div></section>`;
  }
  function topicCatalog(){
    if(!TOPICS.length)return '';
    return `<details class="topic-catalog"><summary>${icon('book',17)} <strong>Aktive Fragen im Detail</strong><span>${activePackIds().length} Paket(e) · ${activePackIds().reduce((n,id)=>n+countPackQuestions(id),0)} Fragen</span></summary><div class="topic-catalog-groups">${activePackIds().map(id=>{
      const pk=packById.get(id),p=topicRotation.packs[id],done=new Set(p.order.slice(0,p.index));
      return `<div class="topic-catalog-group"><h3>${esc(pk.title)} <small>${p.index}/${p.order.length} Themen in dieser Runde</small></h3>${pk.groups.map(group=>`<div class="pack-subgroup"><h4>${esc(group.title)}</h4><div>${group.topics.map(tid=>{const t=topicsById.get(tid);return `<span class="topic-pill ${done.has(tid)?'done':''}">${done.has(tid)?icon('check',12):icon('book',12)} ${esc(t.name)}</span>`;}).join('')}</div></div>`).join('')}</div>`;
    }).join('')}</div></details>`;
  }
  function homeScreen(){const saved=loadMatch();return `<div class="landing"><header class="landing-header"><div class="brand"><span class="brand-crest">${icon('network',30)}</span><span><strong>AP2<span class="gold"> TCG</span></strong><small>NETWORK WARFARE · FISI</small></span></div><span class="demo-tag">APP-EDITION · V1.2</span></header>
    <div class="hero"><div class="hero-copy"><div class="eyebrow">STRATEGISCHES KARTENDUELL · IHK AP2 FISI</div><h1>Verteidige dein <em>Netzwerk.</em><br>Überliste das <em>gegnerische.</em></h1><p>Jeder Spieler kontrolliert fünf IT-Systeme. Plane Angriffe, erreiche interne Netzsegmente, halte Kapazität für Reaktionen zurück und bringe die Infrastruktur deines Gegners zum Erliegen.</p><div class="difficulty-control"><label>AP2-Fragen <select data-action="setting" data-name="trivia" aria-label="Frageschwierigkeit"><option value="basic" ${settings.trivia==='basic'?'selected':''}>Basis</option><option value="normal" ${settings.trivia==='normal'?'selected':''}>Standard</option><option value="hard" ${settings.trivia==='hard'?'selected':''}>Prüfungsnah</option></select></label><label>Bot <select data-action="setting" data-name="bot" aria-label="Bot-Schwierigkeit"><option value="easy" ${settings.bot==='easy'?'selected':''}>Leicht</option><option value="normal" ${settings.bot==='normal'?'selected':''}>Mittel</option><option value="hard" ${settings.bot==='hard'?'selected':''}>Schwer</option></select></label><span class="collection-status">${icon('layers',16)} ${Object.keys(E.CARDS).filter(id=>ownedCount(id)>0).length}/${Object.keys(E.CARDS).length} freigeschaltet · ${collection.credits} FP</span></div>${packSelector()}${topicCatalog()}<div class="hero-actions"><button class="btn primary large" data-action="mission" data-id="1">${icon('book',19)} Tutorial starten ${icon('arrow',18)}</button><button class="btn secondary large" data-action="newai">${icon('swords',19)} Duell gegen KI</button><button class="btn secondary large" data-action="newlocal">${icon('users',19)} Lokales 1v1</button><button class="btn secondary large" data-action="editor">${icon('layers',19)} Deckeditor</button><button class="btn install-app large" data-action="install">${icon('spark',19)} App installieren</button>${saved?`<button class="btn secondary large" data-action="continue">${icon('refresh',19)} Match fortsetzen</button>`:''}</div><p class="hero-foot">Netzwerktechnik mit ${countPackQuestions(CORE_ID)} Fragen im Grundspiel · weitere AP2-Themen als frei zuschaltbare Fragen-Packs</p></div><div class="hero-visual"><div class="orb orb-one"></div><div class="orb orb-two"></div><div class="scene-crest">${icon('network',96)}</div><div class="hero-system hs-one">${icon('shield',24)} Firewall</div><div class="hero-system hs-two">${icon('database',24)} Datenserver</div><div class="hero-system hs-three">${icon('globe',24)} Webserver</div><div class="scene-title">FÜNF SYSTEME. EIN NETZWERK.</div></div></div>
    <section class="mission-section"><div class="section-header"><div><div class="eyebrow">LERNPFAD</div><h2>Zehn Tutorial-Missionen</h2></div><span>${progress.length}/${E.MISSIONS.length} abgeschlossen</span></div><div class="mission-cards">${E.MISSIONS.map(m=>`<button class="mission-card ${progress.includes(m.id)?'passed':''}" data-action="mission" data-id="${m.id}"><span class="mission-visual">${icon(({1:'network',2:'search',3:'shield',4:'route',5:'database',6:'shield-check',7:'bug',8:'globe',9:'git-branch',10:'hard-drive'})[m.id],40)}</span><span class="mission-no">${String(m.id).padStart(2,'0')}</span><span class="mission-kicker">${esc(m.tag)}</span><strong>${esc(m.title)}</strong><span class="mission-short">${esc(m.short)}</span><span class="mission-cta">${progress.includes(m.id)?icon('check',16)+' Erneut spielen':'Mission spielen '+icon('arrow',16)}</span></button>`).join('')}</div></section>
    <footer class="landing-footer">AP2 TCG · Konzeptprototyp · Keine Verbindung zu Wizards of the Coast · Im Lernmodus werden technische Abläufe vereinfacht.</footer></div>${renderModal()}`;}
  const LESSONS={1:'Die DMZ beherbergt öffentliche Dienste. Interne Servernetze müssen über geeignete Regeln und Segmentgrenzen geschützt werden.',2:'Aufklärung liefert Informationen, aber noch keinen Zugriff. Ein erreichbarer Dienst ist nicht automatisch verwundbar.',3:'Gegenmaßnahmen brauchen freie Kapazität. Erst nach dem Reaktionsfenster wird der tatsächlich verbleibende Schaden berechnet.',4:'Der Übergang zwischen Netzen hängt von Routing und Zugriffsregeln ab. Eine VLAN-Zuordnung allein autorisiert keine Verbindung.',5:'RAID 5 toleriert einen einzelnen Laufwerksausfall. Ein Backup mit geprüftem Rückspiel dient der Wiederherstellung und ist davon unabhängig.',6:'VLANs trennen Broadcast-Domänen; für Inter-VLAN-Verkehr wird Layer-3-Routing benötigt. Eine ACL kann unerlaubte Übergänge sperren.',7:'Ein offener Dienst ist keine nachgewiesene Schwachstelle. Erst nach der Prüfung ist im Spiel ein gezielter Exploit möglich.',8:'DNS beantwortet Anfragen zur Namensauflösung, der Verzeichnisdienst ist für Benutzeranmeldungen zuständig.',9:'Bei IPv4-/28 gibt es 16 Adressen, normalerweise 14 nutzbare Hostadressen. Kommunikation über unterschiedliche IP-Netze erfordert Routing.',10:'RAID 5 nutzt rechnerisch die Kapazität eines Datenträgers für verteilte Parität und toleriert einen Ausfall. Es ist kein Backup.'};
  function renderModal(){if(!modal)return '';const m=modal;
    if(m.type==='cardquiz'){
      const t=quizTurn;if(!t)return '';
      const card=E.CARDS[t.cardId],q=t.question;
      return `<div class="modal-backdrop trivia-modal"><section class="dialog trivia-dialog" role="dialog" aria-modal="true" aria-label="AP2-Fachfrage"><div class="trivia-header">${icon(card.icon,28)}<div><div class="eyebrow">AP2-TRIVIA · ${DIFFICULTIES[settings.trivia]}</div><h2>${esc(card.name)}</h2><div class="topic-header"><span class="topic-badge">${icon('book',13)} ${esc(q.packTitle||'Netzwerktechnik')}</span><strong>${esc(q.subgroup||'')} · ${esc(q.topic||'Kartenthema')}</strong></div></div><span class="trivia-cost">${card.cost} KP${t.wrongEver?' · kein Erstversuch-Bonus':''}</span></div><div class="topic-progress"><span>${game.mode==='tutorial'?'TUTORIAL · Frage passend zur Karte':`${esc(q.packTitle||'Netzwerktechnik')} · ${currentPackProgress(q.packId||CORE_ID).done+1}/${currentPackProgress(q.packId||CORE_ID).total} Themen`}</span><div class="topic-progress-track"><i style="width:${game.mode==='tutorial'?100:Math.round((currentPackProgress(q.packId||CORE_ID).done+1)/Math.max(1,currentPackProgress(q.packId||CORE_ID).total)*100)}%"></i></div></div><p class="trivia-question">${q.operator?`<span class="quiz-operator">${esc(q.operator)}</span>`:''} ${esc(q.question)}</p>${t.wrong?`<div class="trivia-error" role="alert"><strong>Nicht korrekt.</strong><p>Richtige Antwort: <b>${esc(q.options[q.answer])}</b></p><p>${esc(t.feedback)}</p><button class="btn primary" data-action="retrytrivia">Frage erneut versuchen</button></div>`:`<div class="trivia-options">${q.options.map((a,i)=>`<button data-action="answercard" data-index="${i}" class="btn trivia-option"><b>${'ABCDE'[i]||String(i+1)}</b><span>${esc(a)}</span></button>`).join('')}</div>`}<div class="trivia-footer"><span>${icon('book',15)} Erst richtige Antwort, dann Karte ausspielen. Im Tutorial immer passend zur Karte.</span><button class="btn secondary" data-action="canceltrivia">Abbrechen</button></div></section></div>`;
    }
    if(m.type==='complete'){const mission=E.MISSIONS.find(x=>x.id===game.missionId);return `<div class="modal-backdrop"><div class="dialog victory"><div class="victory-medal">${icon('check',40)}</div><div class="eyebrow">MISSION ERFOLGREICH</div><h2>${esc(mission.title)}</h2><p>${esc(mission.description)}</p>${MISSION_REWARDS[mission.id]?`<div class="collection-status">${icon('layers',19)} Neue Karte: ${esc(E.CARDS[MISSION_REWARDS[mission.id]].name)} · +1 Exemplar</div>`:''}<div class="detail-learn"><span class="eyebrow">AP2-MERKSATZ</span><p>${esc(LESSONS[mission.id])}</p></div><div class="dialog-actions"><button class="btn secondary" data-action="home">Missionsübersicht</button><button class="btn primary" data-action="next">${mission.id<E.MISSIONS.length?'Nächste Mission':'Freies Duell'} ${icon('arrow',18)}</button></div></div></div>`;}
    if(m.type==='end'){return `<div class="modal-backdrop"><div class="dialog victory"><div class="victory-medal">${icon('crown',42)}</div><div class="eyebrow">MATCH BEENDET</div><h2>${esc(game.players[game.winner].name)} gewinnt!</h2><p>Das Duell endet durch den Ausfall des Datenservers, drei ausgefallene Basissysteme oder einen nicht möglichen Kartenziehversuch.</p><div class="dialog-actions"><button class="btn secondary" data-action="home">Hauptmenü</button><button class="btn primary" data-action="restart">Neues Duell ${icon('arrow',18)}</button></div></div></div>`;}
    if(m.type==='handoff'){return `<div class="modal-backdrop"><div class="dialog"><div class="eyebrow">LOKALES 1V1</div><h2>Spielerwechsel</h2><p>Übergib das Gerät an <strong>${esc(game.players[viewer()].name)}</strong>. Der nächste Spieler sieht erst danach seine Handkarten.</p><div class="dialog-actions"><button class="btn primary" data-action="ready">Bereit · Hand anzeigen</button></div></div></div>`;}
    if(m.type==='help'){return `<div class="modal-backdrop"><div class="dialog rules"><button class="close" data-action="close">${icon('x',22)}</button><div class="eyebrow">REGELÜBERSICHT · V1.2</div><h2>So funktioniert AP2 TCG</h2><p>Beide Spieler starten mit Firewall/Gateway (5 HP), Webserver (4 HP), Arbeitsstationen (4 HP), Verzeichnis-/DNS-Server (5 HP) und Datenserver (6 HP).</p><div class="rules-grid"><div><strong>1. Ressourcen</strong><p>3 KP zu Beginn. Ab deinem zweiten eigenen Zug steigt dein KP-Limit um 1 bis maximal 8, und deine KP werden aufgefüllt. Nicht verwendete KP bleiben für gegnerische Reaktionsfenster erhalten.</p></div><div><strong>2. Angriff</strong><p>Öffentliche Ziele sind sofort erreichbar. Interne Server erfordern Client-Zugang durch Phishing und anschließend laterale Bewegung, wenn die ACL dies zulässt.</p></div><div><strong>3. Reaktion</strong><p>Bei einem Angriff kann der Verteidiger passende Reaktionskarten ausspielen. Danach wird der verbleibende Schaden aufgelöst. Im Prototyp gibt es ein Reaktionsfenster pro Angriff.</p></div><div><strong>4. Sieg</strong><p>Du gewinnst, wenn drei von fünf gegnerischen Basissystemen ausgefallen sind oder der gegnerische Datenserver ausfällt.</p></div></div><p class="small-hint">Fragen-Packs: Netzwerktechnik ist immer aktiv. Andere Bereiche können im Hauptmenü als Fragen-Add-ons frei zugeschaltet werden. Bei aktiven Add-ons kannst du das Verhältnis von 0 bis 100 % Netzwerkanteil in 5-%-Schritten einstellen (Standard 70/30). Ohne Add-ons gilt effektiv 100 % Netzwerk. Innerhalb jedes Packs rotieren die Themen ohne Wiederholung bis zum Ende der Runde. Jede Karte benötigt vor dem Ausspielen eine richtige Antwort. Im Tutorial wird immer eine zur ausgespielten Karte passende Frage gestellt; im freien Duell gilt der einstellbare Fragenmix.</p><p class="small-hint">Bei einer leeren Bibliothek führt ein verpflichtender Kartenziehversuch zur Niederlage. Die Kartenwirkungen sind didaktische Abstraktionen. Ein Portscan gibt keinen Zugang oder Schwachstellennachweis. Ein Rückspiel braucht eine vorherige Datensicherung. RAID ist kein Backup.</p><button class="btn primary" data-action="close">Verstanden</button></div></div>`;}
    return '';
  }
  function showToast(text){toast=text;let box=document.getElementById('toast');if(!box){box=document.createElement('div');box.id='toast';document.body.appendChild(box);}box.innerHTML=`${icon('info',17)} ${esc(text)}`;box.classList.add('show');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>box.classList.remove('show'),3200);}
  function render(){
    app.innerHTML=game?gameScreen():screen==='editor'?deckEditor():homeScreen();
    if(modal){requestAnimationFrame(()=>document.querySelector('.trivia-option:not([disabled]), .trivia-error [data-action="retrytrivia"]')?.focus({preventScroll:true}));}
    if(game?.mode==='ai')scheduleAI();
  }
  function start(mode,missionId){clearTimeout(aiTimer);aiTimer=null;blockedTarget=null;guideError='';guideTipOpen=false;guideSuccess='';game=E.createGame({mode,missionId,seed:Date.now()&0xffffffff,deck:loadDeck(),deck2:E.BASIC_PRESETS.basic_schutz,aiDifficulty:settings.bot,quizRequired:true});screen='home';selected=null;inspecting=null;modal=null;handoff=false;quizFeedback='';quizTurn=null;saveMatch();render();window.scrollTo(0,0);}
  function afterAction(options={}){blockedTarget=null;selected=null;quizFeedback='';guideError='';guideTipOpen=false;guideSuccess='';
    if(game?.mode==='tutorial'&&game.phase==='response'&&game.pending?.defender===1){setTimeout(()=>{if(game?.mode==='tutorial'&&game.phase==='response'&&game.pending?.defender===1&&!game.completed){E.resolvePending(game);afterAction();}},460);}
    if(game?.mode==='hotseat'&&game.phase==='response'&&!modal){handoff=true;modal={type:'handoff'};}

    if(game?.mode==='tutorial'&&game.completed&&!modal){awardMission(game.missionId);modal={type:'complete'};}
    if(game?.mode==='hotseat'&&options.resolvedDefense&&game.phase==='main'&&!modal){handoff=true;modal={type:'handoff'};}
    if(game?.winner!=null){if(!game.rewardsClaimed && game.mode==='ai'){
      rewardPoints(game.winner===0?10:4);collection.matches++;if(game.winner===0)collection.wins++;storeCollection();game.rewardsClaimed=true;
    }modal={type:'end'};}
    saveMatch();render();
  }
  function perform(cardId,player,target){const reacting=game.phase==='response';const res=E.playCard(game,player,cardId,target);if(!res.ok){guideError=res.error;showToast(res.error);render();return;}afterAction({resolvedDefense:reacting});}
  function onCard(index,player){
    if(modal||game.winner!==null)return;
    const id=game.players[player].hand[index];if(!id)return;
    if(game.phase==='response'){
      if(game.pending.defender!==player){showToast('Der andere Spieler reagiert.');return;}
      if(game.mode==='tutorial'&&E.currentStep(game)?.card!==id){guideError=`Wähle die markierte Karte „${E.CARDS[E.currentStep(game).card].name}“.`;showToast(guideError);render();return;}
      beginCardQuiz(id,player,null);return;
    }
    const c=E.CARDS[id];
    if(game.active!==player){showToast('Du bist derzeit nicht am Zug.');return;}
    const playability=E.cardPlayability(game,player,id);
    if(!playability.playable){showToast(playability.reason);return;}
    const step=E.currentStep(game);
    if(game.mode==='tutorial'&&step?.card!==id){guideError=`Spiele zuerst die markierte Karte „${E.CARDS[step.card]?.name||'laut Missionsanweisung'}“.`;showToast(guideError);render();return;}
    if(c.category==='Reaktion'){showToast('Reaktionskarten werden bei einem gegnerischen Angriff gespielt.');return;}
    if(c.target==='none'){beginCardQuiz(id,player,null);return;}
    const targets=E.eligibleTargets(game,id,player);
    if(!targets.length){showToast(E.cardPlayability(game,player,id).reason);return;}
    guideError='';guideSuccess='';blockedTarget=null;selected={id,index,player};inspecting=null;render();
    if(game.mode==='tutorial')requestAnimationFrame(()=>focusGuide());
    else requestAnimationFrame(()=>{document.querySelector('.network-field.opponent .system-tile.is-legal, .network-field.own .system-tile.is-legal')?.scrollIntoView({behavior:'smooth',block:'nearest'});});
  }
  function onSystem(owner,key){
    if(modal||!game)return;
    if(selected){
      const advice=E.targetAdvice(game,selected.id,selected.player,owner,key);
      if(!advice.legal){blockedTarget={owner,key,reason:advice.reason};showToast(advice.reason);render();return;}
      blockedTarget=null;beginCardQuiz(selected.id,selected.player,{owner,system:key});return;
    }
    if(game.mode==='tutorial'){const step=E.currentStep(game);if(step?.type==='select'&&(step.owner!==owner||step.system!==key)){guideError='Dieses System ist nicht das gesuchte Ziel. Achte auf den gelben Rahmen und das Schild „HIER KLICKEN“.';showToast(guideError);render();return;}}
    inspecting={owner,id:key};E.selectSystem(game,owner,key);afterPassive();
  }
  function afterPassive(){guideError='';guideTipOpen=false;if(game?.mode==='tutorial'&&game.completed){awardMission(game.missionId);modal={type:'complete'};}saveMatch();render();}
  function scheduleAI(){
    if(aiTimer||!game||game.mode!=='ai'||modal||game.winner!==null)return;
    if((game.phase==='response'&&game.pending.defender===1)||(game.phase==='main'&&game.active===1)){
      aiTimer=setTimeout(()=>{aiTimer=null;if(!game||modal||game.mode!=='ai')return;E.aiStep(game);afterAction();},440);
    }
  }
  document.addEventListener('click',e=>{
    const btn=e.target.closest('[data-action]');if(!btn)return;
    const action=btn.dataset.action;
    if(action==='togglepack'){const id=btn.dataset.pack;if(!ADDON_IDS.includes(id)||game)return;settings.addonPacks=settings.addonPacks.includes(id)?settings.addonPacks.filter(x=>x!==id):[...settings.addonPacks,id];resetShareCycle();safeSave(SETTINGS_KEY,settings);render();return;}
    if(action==='ratioreset'&&!game){settings.networkShare=DEFAULT_NETWORK_SHARE;resetShareCycle();safeSave(SETTINGS_KEY,settings);render();return;}
    if(action==='install'){
      const installPrompt=window.__ap2InstallPrompt;
      if(installPrompt){window.__ap2InstallPrompt=null;installPrompt.prompt();installPrompt.userChoice?.then(()=>render());}
      else showToast('Installation: Diese App über HTTPS öffnen und im Browser-Menü „App installieren“ wählen.');
      return;
    }
    if(action==='answercard'){
      if(!quizTurn||!game)return;
      const q=quizTurn.question,choice=Number(btn.dataset.index);
      if(choice!==q.answer){quizTurn.wrong=true;quizTurn.wrongEver=true;markQuizMistake(quizTurn.player,quizTurn.cardId);quizTurn.feedback=q.explain;saveMatch();render();return;}
      const turn=quizTurn;const r=E.grantQuizPermit(game,turn.player,turn.cardId,turn.target);
      if(!r.ok){showToast(r.error);modal=null;quizTurn=null;saveMatch();render();return;}
      commitQuestion(turn.question);
      if(game.mode!=='tutorial')advanceTopic(turn.question.topicId);
      collection.answers++;if(!turn.wrongEver&&!hasQuizMistake(turn.player,turn.cardId))rewardPoints(1);else storeCollection();
      clearQuizMistake(turn.player,turn.cardId);quizTurn=null;modal=null;
      perform(turn.cardId,turn.player,turn.target);return;
    }
    if(action==='retrytrivia'){if(quizTurn){quizTurn.attempt=(quizTurn.attempt||0)+1;quizTurn.question=questionFor(quizTurn.cardId,quizTurn.question.topicId,quizTurn.attempt,game.mode==='tutorial');quizTurn.wrong=false;quizTurn.feedback='';saveMatch();render();}return;}
    if(action==='canceltrivia'){quizTurn=null;modal=null;saveMatch();render();return;}
    if(action==='buycard'){const id=btn.dataset.id;if(!E.CARDS[id]||ownedCount(id)>=4||collection.credits<cardCost(id))return;
      collection.credits-=cardCost(id);collection.owned[id]=ownedCount(id)+1;storeCollection();render();return;}
    if(action==='focusguide'){focusGuide();return;}
    if(action==='togglehint'){guideTipOpen=!guideTipOpen;render();return;}
    if(action==='home'){clearTimeout(aiTimer);aiTimer=null;if(game)saveMatch();game=null;modal=null;quizTurn=null;selected=null;handoff=false;screen='home';render();window.scrollTo(0,0);return;}
    if(action==='editor'){clearTimeout(aiTimer);aiTimer=null;game=null;modal=null;quizTurn=null;screen='editor';deckDraft=loadDeck();chosenPreset='basic_angriff';render();window.scrollTo(0,0);return;}
    if(action==='preset'){deckDraft={...E.BASIC_PRESETS[btn.dataset.preset]};chosenPreset=btn.dataset.preset;render();return;}
    if(action==='deckplus'||action==='deckminus'){const id=btn.dataset.id;if(!E.CARDS[id])return;const total=Object.values(deckDraft).reduce((a,n)=>a+n,0);const current=deckDraft[id]||0;deckDraft[id]=Math.max(0,Math.min(ownedCount(id),current+(action==='deckplus'&&total<40?1:action==='deckminus'?-1:0)));chosenPreset='';render();return;}
    if(action==='saveDeck'){if(!deckOwned(deckDraft)){showToast('Genau 40 Karten und höchstens 4 je Sorte erforderlich.');return;}storeDeck();showToast('Deck lokal gespeichert.');return;}
    if(action==='deckduel'){if(!deckOwned(deckDraft)){showToast('Das Deck muss genau 40 Karten enthalten.');return;}storeDeck();start('ai');return;}
    if(action==='continue'){const saved=loadSavedEntry();if(!saved){showToast('Kein gespeichertes Match verfügbar.');return;}game=saved.game;quizTurn=saved.quizTurn;screen='home';selected=null;modal=game.completed?{type:'complete'}:game.winner!==null?{type:'end'}:quizTurn?{type:'cardquiz'}:null;render();return;}
    if(action==='mission'){start('tutorial',Number(btn.dataset.id));return;}
    if(action==='newai'){start('ai');return;}
    if(action==='newlocal'){start('hotseat');return;}
    if(action==='restart'){if(game)start(game.mode,game.missionId);return;}
    if(action==='help'){modal={type:'help'};render();return;}
    if(action==='close'){modal=null;render();return;}
    if(action==='ready'){modal=null;handoff=false;render();return;}
    if(action==='next'){const missionId=game.missionId;if(missionId<E.MISSIONS.length)start('tutorial',missionId+1);else start('ai');return;}
    if(!game)return;
    if(action==='card'){onCard(Number(btn.dataset.index),Number(btn.dataset.player));return;}
    if(action==='system'){onSystem(Number(btn.dataset.owner),btn.dataset.system);return;}
    if(action==='cancel'){selected=null;blockedTarget=null;guideError='';render();return;}
    if(action==='incident'){const r=E.simulateIncident(game);if(!r.ok){guideError=r.error;showToast(r.error);render();}else afterAction();return;}
    if(action==='aclIncident'){const r=E.simulateAclIncident(game);if(!r.ok){guideError=r.error;showToast(r.error);render();}else afterAction();return;}
    if(action==='answer'){const r=E.answerQuiz(game,Number(btn.dataset.index));if(!r.ok){quizFeedback='Noch nicht korrekt. Prüfe die Randbedingungen.';guideError='Diese Antwort ist nicht richtig. Prüfe die Angaben und versuche es erneut.';showToast(r.error);render();}else {const explanation=r.explain;afterAction();showToast(explanation);}return;}
    if(action==='allow'){if(game.phase!=='response'||game.pending.defender!==viewer())return;E.resolvePending(game);afterAction({resolvedDefense:true});return;}
    if(action==='end'){const r=E.endTurn(game);if(!r.ok){showToast(r.error);return;}selected=null;if(game.winner!==null){afterAction();return;}if(game.mode==='hotseat'){handoff=true;modal={type:'handoff'};}saveMatch();render();return;}
  });
  document.addEventListener('input',e=>{
    if(!e.target.matches('input[data-action="networkshare"]'))return;
    const n=Math.max(0,Math.min(100,Number(e.target.value)||0));
    document.querySelector('[data-share-network]').textContent=n+' %';
    document.querySelector('[data-share-addons]').textContent=(100-n)+' %';
    document.querySelector('[data-share-bar-network]').style.width=n+'%';
    document.querySelector('[data-share-bar-addon]').style.width=(100-n)+'%';
    e.target.setAttribute('aria-valuetext',n+' Prozent Netzwerk und '+(100-n)+' Prozent Add-ons');
  });
  document.addEventListener('change',e=>{
    if(e.target.matches('input[data-action="networkshare"]')&&!game){
      const n=Number(e.target.value);
      if(Number.isInteger(n)&&n>=0&&n<=100&&n%5===0){settings.networkShare=n;resetShareCycle();safeSave(SETTINGS_KEY,settings);}
      render();return;
    }
    if(e.target.matches('select[data-action="setting"]')){
      const k=e.target.dataset.name,v=e.target.value;
      if(k==='trivia'&&['basic','normal','hard'].includes(v))settings.trivia=v;
      if(k==='bot'&&['easy','normal','hard'].includes(v))settings.bot=v;

      safeSave(SETTINGS_KEY,settings);render();
    }
  });
  function navigateBack(){
    // Used by the native Android WebView host. Never expose the next player's
    // private cards by dismissing a pass-and-play handoff overlay.
    if(handoff||modal?.type==='handoff')return true;
    if(quizTurn){quizTurn=null;modal=null;saveMatch();render();return true;}
    if(modal?.type==='help'){modal=null;render();return true;}
    if(selected){selected=null;blockedTarget=null;render();return true;}
    if(modal){modal=null;saveMatch();game=null;screen='home';render();return true;}
    if(game){saveMatch();game=null;screen='home';render();window.scrollTo(0,0);return true;}
    if(screen==='editor'){screen='home';render();window.scrollTo(0,0);return true;}
    return false;
  }
  window.AP2MobileBack=navigateBack;
  document.addEventListener('keydown',e=>{
    if(e.key!=='Escape')return;
    if(navigateBack())e.preventDefault();
  });
  render();
})();
