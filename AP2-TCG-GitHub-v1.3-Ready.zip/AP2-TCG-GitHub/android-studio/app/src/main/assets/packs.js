/* AP2 TCG v1.0 – modularer Fragenpaket-Katalog */
window.AP2PACKS=[
  {
    "id": "netzwerk",
    "title": "Netzwerktechnik",
    "type": "core",
    "description": "Netzwerkgrundlagen, Switching, Routing, Dienste und Sicherheit im Netz",
    "icon": "network",
    "groups": [
      {
        "id": "adressierung",
        "title": "Adressierung",
        "topics": [
          "ipv4",
          "ipv6"
        ]
      },
      {
        "id": "switching",
        "title": "Switching und VLAN",
        "topics": [
          "switch"
        ]
      },
      {
        "id": "routing-wan",
        "title": "Routing und WAN",
        "topics": [
          "routing",
          "vpn"
        ]
      },
      {
        "id": "netzdienste",
        "title": "Netzdienste",
        "topics": [
          "dnsdhcp",
          "proxy"
        ]
      },
      {
        "id": "netzschutz",
        "title": "Netzsicherheit",
        "topics": [
          "firewall",
          "wirelesssecurity"
        ]
      },
      {
        "id": "medien",
        "title": "Medien und WLAN",
        "topics": [
          "wlan",
          "media"
        ]
      },
      {
        "id": "analyse",
        "title": "Diagnose und Leistung",
        "topics": [
          "diagnose",
          "osi",
          "qos"
        ]
      }
    ]
  },
  {
    "id": "admin",
    "title": "Betriebssysteme und Administration",
    "type": "addon",
    "description": "Linux, Windows, Rechte und Aufgabenautomatisierung",
    "icon": "terminal",
    "groups": [
      {
        "id": "os",
        "title": "Betriebssysteme",
        "topics": [
          "linux",
          "windows"
        ]
      },
      {
        "id": "rechte",
        "title": "Dateisysteme und Rechte",
        "topics": [
          "filesystems"
        ]
      },
      {
        "id": "automation",
        "title": "Automatisierung",
        "topics": [
          "automation"
        ]
      }
    ]
  },
  {
    "id": "server",
    "title": "Server, Cloud und Speicher",
    "type": "addon",
    "description": "RAID, Sicherungen, Virtualisierung und Verfügbarkeit",
    "icon": "database",
    "groups": [
      {
        "id": "storage",
        "title": "Storage und Datensicherung",
        "topics": [
          "raid",
          "storageperf",
          "backup"
        ]
      },
      {
        "id": "plattformen",
        "title": "Virtualisierung und Cloud",
        "topics": [
          "virtual",
          "cloud"
        ]
      },
      {
        "id": "verfuegbarkeit",
        "title": "Hochverfügbarkeit",
        "topics": [
          "ha"
        ]
      }
    ]
  },
  {
    "id": "security",
    "title": "IT-Sicherheit und Betrieb",
    "type": "addon",
    "description": "Sicherheitsmaßnahmen, Identität, Monitoring und IT-Service",
    "icon": "shield",
    "groups": [
      {
        "id": "schutz",
        "title": "Sicherheit und Identität",
        "topics": [
          "security",
          "identity"
        ]
      },
      {
        "id": "betrieb",
        "title": "Monitoring, Störungen und Service",
        "topics": [
          "monitoring",
          "risk",
          "itservice"
        ]
      }
    ]
  },
  {
    "id": "daten",
    "title": "Daten, SQL und Modellierung",
    "type": "addon",
    "description": "Datenbanken, UML, Datentypen und Schnittstellen",
    "icon": "file-search",
    "groups": [
      {
        "id": "datenbanken",
        "title": "Daten und Schnittstellen",
        "topics": [
          "sql",
          "formats"
        ]
      },
      {
        "id": "modellierung",
        "title": "UML und Logik",
        "topics": [
          "uml"
        ]
      }
    ]
  },
  {
    "id": "wiso",
    "title": "WiSo und Wirtschaftlichkeit",
    "type": "addon",
    "description": "Arbeitsrecht, Sozialversicherung, Kalkulation und Beschaffung",
    "icon": "book",
    "groups": [
      {
        "id": "wiso-grundlagen",
        "title": "Arbeitswelt und Unternehmen",
        "topics": [
          "arbeitsrecht",
          "sozial",
          "unternehmen"
        ]
      },
      {
        "id": "wiso-wirtschaft",
        "title": "Wirtschaft und Kalkulation",
        "topics": [
          "wiso",
          "beschaffung",
          "economics",
          "wiso_rechnen",
          "wiso_umwelt"
        ]
      }
    ]
  }
];
