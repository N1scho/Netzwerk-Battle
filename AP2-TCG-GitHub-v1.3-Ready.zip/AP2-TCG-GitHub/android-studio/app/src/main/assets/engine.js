/* AP2 TCG — deterministic game rules, dependency-free.
   The prototype deliberately models simplified AP2 concepts rather than real attack instructions. */
(function (root, factory) {
  const engine = factory();
  if (typeof module === 'object' && module.exports) module.exports = engine;
  root.AP2ENGINE = engine;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const SYSTEMS = [
    { id:'gateway', name:'Firewall / Gateway', zone:'Grenze', maxHp:5, icon:'shield', desc:'Prüft eingehende und ausgehende Verbindungen.' },
    { id:'web', name:'Webserver', zone:'DMZ', maxHp:4, icon:'globe', desc:'Öffentlich erreichbarer Dienst in der DMZ.' },
    { id:'client', name:'Arbeitsstationen', zone:'Clientnetz', maxHp:4, icon:'monitor', desc:'Benutzer-Endgeräte im internen Netz.' },
    { id:'dns', name:'Verzeichnis- / DNS-Server', zone:'Servernetz', maxHp:5, icon:'network', desc:'Verzeichnisdienst und DNS erfüllen getrennte Aufgaben.' },
    { id:'data', name:'Datenserver', zone:'Servernetz', maxHp:6, icon:'database', desc:'Kritisches Ziel mit geschützten Daten.' }
  ];

  const CARDS = {
    scan: { id:'scan', name:'Dienstanalyse', category:'Analyse', cost:1, tint:'blue', icon:'search', target:'enemy', desc:'Decke ein erreichbares Ziel auf. Für gezielte Exploits ist Aufklärung erforderlich.', ap2:'Erreichbarkeit und Dienstanalyse sind verschiedene Schritte.' },
    ddos: { id:'ddos', name:'Überlastungsangriff', category:'Angriff', cost:2, tint:'red', icon:'zap', target:'enemy', desc:'Füge einem öffentlichen Ziel 2 Verfügbarkeitsschaden zu.', ap2:'Ein öffentlicher Dienst kann auch ohne internen Netzzugang gestört werden.' },
    exploit: { id:'exploit', name:'Schwachstelle ausnutzen', category:'Angriff', cost:3, tint:'red', icon:'bug', target:'enemy', desc:'Füge einem analysierten Ziel mit bestätigter Schwachstelle 3 Schaden zu.', ap2:'Erreichbarkeit und ein Scan beweisen keine Schwachstelle. Im Spiel muss diese gesondert bestätigt sein.' },
    phishing: { id:'phishing', name:'Phishing-Versuch', category:'Angriff', cost:2, tint:'purple', icon:'mail', target:'enemy', desc:'Markiere das Clientnetz des Gegners mit „Zugang: Client“.', ap2:'Social Engineering kann eine Zugangshürde umgehen, ist aber kein garantierter Erfolg.' },
    pivot: { id:'pivot', name:'Laterale Bewegung', category:'Angriff', cost:1, tint:'purple', icon:'route', target:'none', desc:'Benötigt Client-Zugang. Erhalte Zugang zum Servernetz, wenn keine ACL-Sperre aktiv ist.', ap2:'Netzübergänge hängen von Routing und Zugriffsregeln ab.' },
    internal: { id:'internal', name:'Gezielter Systemangriff', category:'Angriff', cost:2, tint:'red', icon:'crosshair', target:'enemy', desc:'Benötigt Servernetz-Zugang. Füge einem internen Server 2 Schaden zu.', ap2:'Ein internes Ziel muss über einen erlaubten Pfad erreichbar sein.' },
    disk: { id:'disk', name:'Laufwerksstörung', category:'Ereignis', cost:2, tint:'red', icon:'hard-drive', target:'enemy', desc:'Benötigt Servernetz-Zugang. Löse einen Laufwerksausfall am Datenserver aus (2 Schaden).', ap2:'RAID 5 toleriert den Ausfall eines Laufwerks im intakten Verbund.' },
    filter: { id:'filter', name:'Traffic-Filter', category:'Reaktion', cost:1, tint:'gold', icon:'shield', target:'none', desc:'Reagiere auf Überlastung und verhindere 2 Schaden.', ap2:'Netzfilter können unerwünschten Datenverkehr abweisen.' },
    patch: { id:'patch', name:'Patchmanagement', category:'Reaktion', cost:1, tint:'gold', icon:'wrench', target:'none', desc:'Reagiere auf einen Exploit und verhindere 3 Schaden.', ap2:'Patches schließen bekannte Schwachstellen; nicht jede Störung ist ein Exploit.' },
    isolate: { id:'isolate', name:'Zugriff entziehen', category:'Reaktion', cost:1, tint:'gold', icon:'lock', target:'none', desc:'Reagiere auf einen internen Angriff: verhindere 2 Schaden und widerrufe Serverzugang.', ap2:'Zugänge lassen sich durch Zugriffssperren oder Isolation begrenzen.' },
    fortify: { id:'fortify', name:'Firewall-Härtung', category:'Infrastruktur', cost:2, tint:'gold', icon:'shield-check', target:'self', desc:'Verstärke Gateway oder Webserver. Der nächste externe Treffer wird um 1 reduziert.', ap2:'Defense in Depth begrenzt externe Angriffsflächen.' },
    segmentation: { id:'segmentation', name:'Segmentierung + ACL', category:'Infrastruktur', cost:2, tint:'blue', icon:'git-branch', target:'self', desc:'Sichere dein internes Netz. Der nächste Versuch „Laterale Bewegung“ wird verhindert.', ap2:'Erst eine passende ACL begrenzt den Verkehr über Segmentgrenzen.' },
    raid: { id:'raid', name:'RAID-5-Verbund', category:'Infrastruktur', cost:3, tint:'green', icon:'database', target:'self', desc:'Sichere deinen Datenserver gegen den nächsten einzelnen Laufwerksausfall.', ap2:'RAID schützt vor einem Laufwerksausfall, aber nicht vor versehentlichem Löschen.' },
    backup: { id:'backup', name:'Geprüftes Rückspiel', category:'Wiederherstellung', cost:2, tint:'green', icon:'refresh', target:'self', desc:'Verbrauche einen zuvor angelegten Sicherungsstand und stelle bis zu 3 HP wieder her.', ap2:'Rückspiel nur mit einem zuvor erstellten und geprüften Sicherungsstand; RAID ersetzt keine Datensicherung.' },
    log: { id:'log', name:'Logauswertung', category:'Analyse', cost:1, tint:'blue', icon:'file-search', target:'none', desc:'Ziehe 2 Karten aus deiner Bibliothek.', ap2:'Logdateien unterstützen Ursachenanalyse und Fehlerdiagnose.' },
    script: { id:'script', name:'Automatisierungsskript', category:'Infrastruktur', cost:2, tint:'green', icon:'terminal', target:'self', desc:'Repariere 1 HP an einem eigenen Ziel und ziehe eine Karte.', ap2:'Skripte führen wiederkehrende Abläufe reproduzierbar aus.' },
    vuln: { id:'vuln', name:'Schwachstellenprüfung', category:'Analyse', cost:1, tint:'purple', icon:'bug', target:'enemy', desc:'Prüfe ein zuvor analysiertes erreichbares System auf eine modellierte Schwachstelle. Markiere es als verwundbar.', ap2:'Eine Schwachstelle muss nachgewiesen werden. Ein offener Port allein genügt dafür nicht.' },
    dnscheck: { id:'dnscheck', name:'DNS-Diagnose', category:'Analyse', cost:1, tint:'blue', icon:'search', target:'self', desc:'Prüfe die Namensauflösung am eigenen DNS-System und ziehe 1 Karte.', ap2:'DNS übersetzt Namen in IP-Adressen; der Verzeichnisdienst übernimmt Benutzeranmeldungen.' },
    backupplan: { id:'backupplan', name:'Sicherungsstand anlegen', category:'Infrastruktur', cost:2, tint:'green', icon:'database', target:'self', desc:'Lege für ein intaktes eigenes System einen Sicherungsstand an (maximal 2).', ap2:'Eine Datensicherung muss vor dem Schadensereignis erstellt und für ein Rückspiel geeignet sein.' }
  };

  const DECK_BLUEPRINT = {
    scan:3, ddos:3, exploit:2, phishing:3, pivot:2, internal:3,
    disk:2, filter:3, patch:2, isolate:2, fortify:2,
    segmentation:2, raid:1, backup:1, log:1, script:1,
    vuln:2, dnscheck:2, backupplan:3
  }; // 40 cards

  const MISSIONS = [
    { id:1, title:'Netzwerk kennenlernen', tag:'Orientierung', short:'Fünf Zielsysteme und Netzsegmente erkennen.', description:'Lerne den Aufbau der beiden Netze kennen. Wähle die markierten Systeme nacheinander aus.', steps:[
      {type:'select', owner:0, system:'gateway', text:'Wähle deine Firewall / dein Gateway. Es schützt die Netzgrenze.'},
      {type:'select', owner:0, system:'data', text:'Wähle deinen Datenserver. Er ist ein kritisches Ziel im internen Servernetz.'},
      {type:'select', owner:1, system:'web', text:'Wähle den gegnerischen Webserver in der DMZ. Öffentliche Dienste sind von außen erreichbar.'}
    ] },
    { id:2, title:'Aufklären und angreifen', tag:'Erster Angriff', short:'Dienstanalyse ausspielen und den Webserver treffen.', description:'Wende Aufklärung und anschließend einen Verfügbarkeitsangriff an.', steps:[
      {type:'play', card:'scan', targetOwner:1, target:'web', text:'Spiele „Dienstanalyse“ und wähle den gegnerischen Webserver.'},
      {type:'damage', card:'ddos', target:'web', text:'Spiele „Überlastungsangriff“ auf den gegnerischen Webserver. Der Gegner reagiert in dieser Mission nicht.'}
    ] },
    { id:3, title:'Auf Angriffe reagieren', tag:'Verteidigung', short:'Schaden mit einer Reaktionskarte verhindern.', description:'Der Gegner greift gerade deinen Webserver an. Nutze eine Reaktionskarte.', steps:[
      {type:'defend', card:'filter', text:'Der Gegner verursacht 2 Schaden. Spiele „Traffic-Filter“, bevor der Angriff aufgelöst wird.'}
    ] },
    { id:4, title:'Ins Servernetz vordringen', tag:'Netzzugang', short:'Client-Zugang und laterale Bewegung kombinieren.', description:'Ein internes Ziel kann nicht einfach wie ein Webserver angegriffen werden.', steps:[
      {type:'play', card:'phishing', targetOwner:1, target:'client', text:'Spiele „Phishing-Versuch“ auf das gegnerische Clientnetz.'},
      {type:'play', card:'pivot', text:'Spiele „Laterale Bewegung“. Der vorhandene Client-Zugang ermöglicht in dieser Mission den Übergang ins Servernetz.'},
      {type:'damage', card:'internal', target:'data', text:'Nutze den Servernetz-Zugang und greife den gegnerischen Datenserver gezielt an.'}
    ] },
    { id:5, title:'RAID und Rückspiel', tag:'Systembetrieb', short:'Laufwerksausfall abfangen und ein System wiederherstellen.', description:'Unterscheide Redundanz im RAID-Verbund von der Wiederherstellung aus einem Backup.', steps:[
      {type:'play', card:'raid', targetOwner:0, target:'data', text:'Spiele „RAID-5-Verbund“ auf deinen Datenserver.'},
      {type:'incident', text:'Klicke auf „Laufwerksausfall simulieren“. Das RAID soll den ersten Ausfall tolerieren.'},
      {type:'play', card:'backup', targetOwner:0, target:'data', text:'Dein Datenserver war bereits beschädigt. Spiele „Geprüftes Rückspiel“, um 3 HP wiederherzustellen.'}
    ] },
    { id:6, title:'Segmentierung und ACL', tag:'Netzwerksicherheit', short:'Eine seitliche Bewegung durch eine ACL verhindern.', description:'Die passende Zugriffskontrolle verhindert den Übergang vom Client- ins Servernetz.', steps:[
      {type:'play',card:'segmentation',targetOwner:0,target:'gateway',text:'Spiele „Segmentierung + ACL“ auf dein Gateway.'},
      {type:'aclIncident',text:'Simuliere einen gegnerischen Versuch, vom Clientnetz in dein Servernetz zu gelangen.'},
      {type:'quiz',question:'Welche Komponente erlaubt die Kommunikation zwischen unterschiedlichen IP-Netzen? (Nennen)',options:['Nur ein Trunk-Port','Router oder Layer-3-Switch','Ein Access-Port'],answer:1,explain:'Ein Trunk überträgt VLAN-Tags. Für Verkehr zwischen IP-Netzen wird Layer-3-Routing benötigt.'}
    ] },
    { id:7, title:'Schwachstelle gezielt prüfen', tag:'Analyse und Angriff', short:'Erst analysieren, dann prüfen und gezielt angreifen.', description:'Ein offener Port ist kein Beweis für eine ausnutzbare Sicherheitslücke.', steps:[
      {type:'play',card:'scan',targetOwner:1,target:'web',text:'Analysiere den gegnerischen Webserver.'},
      {type:'play',card:'vuln',targetOwner:1,target:'web',text:'Prüfe den analysierten Webserver auf eine modellierte Schwachstelle.'},
      {type:'damage',card:'exploit',target:'web',text:'Spiele den gezielten Angriff erst nach bestätigter Schwachstelle.'}
    ] },
    { id:8, title:'DNS richtig diagnostizieren', tag:'Namensauflösung', short:'Diagnosekarte nutzen und Dienstfehler zuordnen.', description:'Unterscheide Fehler bei DNS von Problemen bei der Benutzeranmeldung.', steps:[
      {type:'play',card:'dnscheck',targetOwner:0,target:'dns',text:'Spiele „DNS-Diagnose“ auf den eigenen DNS-Server.'},
      {type:'quiz',question:'Ein Server ist über seine IP-Adresse erreichbar, jedoch nicht über seinen Namen. Welchen Dienst prüfst du zuerst? (Nennen)',options:['DNS-Namensauflösung','STP auf dem Switch','RAID-Controller'],answer:0,explain:'Wenn IP-Kommunikation funktioniert, jedoch die Auflösung des Namens nicht, liegt die erste Prüfung bei den DNS-Einstellungen und DNS-Anfragen.'}
    ] },
    { id:9, title:'Subnetze und Routing', tag:'IPv4', short:'Host-Anzahl berechnen und Layer 3 erkennen.', description:'Berechne die nutzbaren IPv4-Adressen und ordne den Netzwechsel zu.', steps:[
      {type:'quiz',question:'Wie viele regulär nutzbare Hostadressen hat ein IPv4-/28-Netz? (Berechnen)',options:['14','16','30'],answer:0,explain:'32 − 28 = 4 Hostbits, also 2⁴ = 16 Adressen; abzüglich Netz- und Broadcastadresse bleiben 14.'},
      {type:'quiz',question:'Zwei Endgeräte liegen in VLAN 10 und VLAN 20 mit unterschiedlichen IP-Subnetzen. Was ist für ihre Kommunikation notwendig? (Nennen)',options:['Ein Trunk ohne Routing','Inter-VLAN-Routing und erlaubende Regeln','Nur derselbe DNS-Server'],answer:1,explain:'VLANs trennen Broadcast-Domänen. Verkehr über ihre IP-Grenzen benötigt Routing und passende Sicherheitsregeln.'}
    ] },
    { id:10, title:'RAID-Leistungsmerkmale', tag:'Storage', short:'Kapazität und Fehlertoleranz sicher berechnen.', description:'Begründe die Kapazität und die Ausfalltoleranz eines RAID-5-Verbunds.', steps:[
      {type:'quiz',question:'Vier Festplatten mit jeweils 2 TB bilden ein RAID 5. Wie groß ist die nutzbare Kapazität? (Berechnen)',options:['8 TB','6 TB','4 TB'],answer:1,explain:'RAID 5: (4 − 1) × 2 TB = 6 TB nutzbare Kapazität (dezimal, ohne Metadaten).'},
      {type:'quiz',question:'Welche Aussage zu RAID 5 ist korrekt? (Erläutern)',options:['Es ersetzt ein Backup vollständig','Es toleriert zwei gleichzeitige Laufwerksausfälle','Es toleriert den Ausfall eines Laufwerks'],answer:2,explain:'RAID 5 toleriert einen ausgefallenen Datenträger. Ein zweiter Ausfall vor erfolgreichem Wiederaufbau führt üblicherweise zum Datenverlust.'}
    ] }
  ];

  function rng(seed) { let x=(seed>>>0)||1234567; return () => { x^=x<<13; x^=x>>>17; x^=x<<5; return ((x>>>0)%1000000)/1000000; }; }
  function deckFromBlueprint(seed) {
    const out=[];
    Object.entries(DECK_BLUEPRINT).forEach(([id,count])=>{for(let i=0;i<count;i++)out.push(id);});
    const random=rng(seed); for(let i=out.length-1;i>0;i--){ const j=Math.floor(random()*(i+1)); [out[i],out[j]]=[out[j],out[i]]; }
    return out;
  }

  // The player begins with two fully usable Basic decks. Additional card copies are earned.
  const BASIC_IDS = ["scan", "ddos", "phishing", "pivot", "internal", "filter", "fortify", "segmentation", "log", "script", "dnscheck"];
  const BASIC_PRESETS = {basic_angriff:{"scan": 4, "ddos": 4, "phishing": 4, "pivot": 4, "internal": 4, "filter": 4, "fortify": 4, "segmentation": 4, "log": 4, "script": 2, "dnscheck": 2},basic_schutz:{"scan": 4, "ddos": 3, "phishing": 3, "pivot": 3, "internal": 3, "filter": 4, "fortify": 4, "segmentation": 4, "log": 4, "script": 4, "dnscheck": 4}};

  const PRESETS = {
    ausgeglichen: {...DECK_BLUEPRINT},
    offensiv: {scan:4,ddos:4,exploit:4,phishing:4,pivot:3,internal:4,disk:2,filter:3,patch:1,isolate:1,fortify:1,segmentation:2,raid:0,backup:0,log:1,script:0,vuln:4,dnscheck:1,backupplan:1},
    defensiv: {scan:3,ddos:2,exploit:1,phishing:2,pivot:2,internal:2,disk:1,filter:4,patch:4,isolate:3,fortify:3,segmentation:3,raid:2,backup:2,log:1,script:2,vuln:1,dnscheck:1,backupplan:1}
  };
  function validateDeck(blueprint){
    if(!blueprint||typeof blueprint!=='object'||Array.isArray(blueprint))return false;
    if(Object.entries(blueprint).some(([id,n])=>!CARDS[id]||!Number.isInteger(n)||n<0||n>4))return false;
    return Object.values(CARDS).reduce((sum,c)=>sum+(blueprint[c.id]||0),0)===40;
  }
  function deckFromList(blueprint,seed){
    if(!validateDeck(blueprint))throw new Error('Das Deck muss genau 40 Karten mit maximal vier Exemplaren je Karte haben.');
    const out=[];Object.keys(CARDS).forEach(id=>{for(let i=0;i<(blueprint[id]||0);i++)out.push(id);});
    const random=rng(seed);for(let i=out.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[out[i],out[j]]=[out[j],out[i]];}
    return out;
  }
  function sysArray() {return SYSTEMS.map(s=>({...s, hp:s.maxHp, scannedBy:[], vulnerable:false, fortified:0, raidCharge:0, backupCharge:0}));}
  function createPlayer(id,name,deck) {return {id,name,systems:sysArray(),deck:[...deck],hand:[],discard:[],kp:3,maxKp:3,access:{client:false,internal:false},segmentation:0};}
  function draw(state,owner,amount=1){
    const p=state.players[owner];
    for(let i=0;i<amount;i++){
      if(state.winner!==null)return;
      if(p.deck.length){p.hand.push(p.deck.pop());continue;}
      // Prevent deadlocked PvP games: failing a mandatory draw loses the duel.
      // Tutorials intentionally have empty teaching decks and are exempt.
      if(state.mode==='tutorial'){log(state,`${p.name}: Tutorial-Bibliothek leer.`);continue;}
      state.winner=1-owner;
      state.phase='ended';
      log(state,`${p.name} verliert: Beim Kartenziehen war die Bibliothek leer.`);
      return;
    }
  }
  function log(state,entry){state.log.unshift(entry);state.log=state.log.slice(0,24);}
  function findSys(state,owner,key){return state.players[owner].systems.find(s=>s.id===key);}
  function createGame(opts={}) {
    const mode=opts.mode||'ai', mission=mode==='tutorial'?MISSIONS.find(m=>m.id===(opts.missionId||1)):null;
    if(mode==='tutorial'&&!mission)throw new Error('Unbekannte Tutorial-Mission.');
    const seed=opts.seed??314159;
    const s={aiDifficulty:opts.aiDifficulty||'normal', quizRequired:opts.quizRequired!==false, quizPermit:null, quizMistakes:{}, rngState:(seed>>>0)||0x6d2b79f5, mode, missionId:mission?mission.id:null, tutorialStep:0, completed:false, active:0, turn:1, phase:'main', players:[createPlayer(0,opts.p1||'Du',opts.deck&&validateDeck(opts.deck)?deckFromList(opts.deck,seed):deckFromBlueprint(seed)),createPlayer(1,opts.p2||(mode==='hotseat'?'Spieler 2':'Firewall-KI'),opts.deck2&&validateDeck(opts.deck2)?deckFromList(opts.deck2,seed+23):deckFromBlueprint(seed+23))], pending:null,winner:null,log:[],events:[],aiMoves:0,handOff:false};
    if(mode==='tutorial'){
      s.players[0].hand=[];s.players[1].hand=[];s.players[0].deck=[];s.players[1].deck=[];
      if(mission.id===2)s.players[0].hand=['scan','ddos'];
      if(mission.id===3){s.players[0].hand=['filter','patch','backup'];s.players[0].kp=3;s.pending={owner:1,defender:0,card:'ddos',target:'web',damage:2,prevent:0};s.active=1;s.phase='response';}
      if(mission.id===4){s.players[0].hand=['phishing','pivot','internal'];s.players[0].kp=5;s.players[0].maxKp=5;}
      if(mission.id===5){s.players[0].hand=['raid','backup'];s.players[0].kp=6;s.players[0].maxKp=6;findSys(s,0,'data').hp=3;findSys(s,0,'data').backupCharge=1;}
      if(mission.id===6){s.players[0].hand=['segmentation'];s.players[0].kp=3;s.players[1].access.client=true;}
      if(mission.id===7){s.players[0].hand=['scan','vuln','exploit'];s.players[0].kp=5;s.players[0].maxKp=5;}
      if(mission.id===8){s.players[0].hand=['dnscheck'];s.players[0].deck=['log'];s.players[0].kp=3;}
    }else{draw(s,0,5);draw(s,1,5);}
    log(s,mode==='tutorial'?`Mission ${mission.id}: ${mission.title}`:'Duell gestartet. Beide Netze sind betriebsbereit.');
    return s;
  }
  function currentStep(state){if(state.mode!=='tutorial')return null;return MISSIONS.find(m=>m.id===state.missionId).steps[state.tutorialStep]||null;}
  function event(state,type,attrs={}){
    const ev={type,...attrs};state.events.push(ev);if(state.events.length>150)state.events.shift();
    if(state.mode!=='tutorial'||state.completed)return;
    const step=currentStep(state);if(!step)return;
    if(step.type===type && (!step.card||step.card===attrs.card) && (!step.system||step.system===attrs.system) && (!step.target||step.target===attrs.target) && (step.owner==null||step.owner===attrs.owner) && (step.targetOwner==null||step.targetOwner===attrs.targetOwner)){
      state.tutorialStep++;
      const mission=MISSIONS.find(m=>m.id===state.missionId);
      if(state.tutorialStep>=mission.steps.length){state.completed=true;log(state,'Mission abgeschlossen!');}
    }
  }
  function selectSystem(state,owner,key){if(!findSys(state,owner,key))return {ok:false,error:'Unbekanntes System.'};event(state,'select',{owner,system:key});return {ok:true};}
  function isReachable(state,owner,targetOwner,key){if(owner===targetOwner)return true;const a=state.players[owner];return key==='gateway'||key==='web'||(key==='client'&&a.access.client)||(['dns','data'].includes(key)&&a.access.internal);}
  function eligibleTargets(state,cardId,owner){
    const c=CARDS[cardId];if(!c)return [];
    if(c.target==='none')return [];
    const targetOwner=c.target==='self'?owner:1-owner;
    return state.players[targetOwner].systems.filter(s=>{
      if(c.id==='scan')return s.hp>0&&!s.scannedBy.includes(owner)&&isReachable(state,owner,targetOwner,s.id);
      if(c.id==='vuln')return s.hp>0&&s.scannedBy.includes(owner)&&!s.vulnerable&&isReachable(state,owner,targetOwner,s.id);
      if(c.id==='ddos')return s.hp>0&&['gateway','web'].includes(s.id);
      if(c.id==='exploit')return s.hp>0&&s.vulnerable&&s.scannedBy.includes(owner)&&isReachable(state,owner,targetOwner,s.id);
      if(c.id==='phishing')return s.id==='client'&&s.hp>0&&!state.players[owner].access.client;
      if(c.id==='internal')return s.hp>0&&['dns','data'].includes(s.id)&&state.players[owner].access.internal;
      if(c.id==='disk')return s.hp>0&&s.id==='data'&&state.players[owner].access.internal;
      if(c.id==='raid')return s.id==='data'&&s.hp>0;
      if(c.id==='backup')return s.hp<s.maxHp&&s.backupCharge>0; // a tested backup can also recover a failed, non-critical system
      if(c.id==='fortify')return ['gateway','web'].includes(s.id)&&s.hp>0;
      if(c.id==='segmentation')return s.id==='gateway'&&s.hp>0;
      if(c.id==='script')return s.hp>0&&s.hp<s.maxHp;
      if(c.id==='backupplan')return s.hp===s.maxHp&&s.backupCharge<2;
      if(c.id==='dnscheck')return s.id==='dns'&&s.hp>0;
      return true;
    }).map(s=>({owner:targetOwner,system:s.id}));
  }

  // A single source of truth for explanation, target eligibility and previews.
  // No state is changed; both the game and the UI can use this information.
  function targetAdvice(state, cardId, owner, targetOwner, key) {
    const c=CARDS[cardId], sys=state.players[targetOwner]?.systems.find(s=>s.id===key);
    const result=(legal,reason,extra={})=>({legal,reason,system:key,owner:targetOwner,damage:0,projectedHp:sys?.hp??null,protection:'',...extra});
    if (!c || !sys) return result(false,'Karte oder Zielsystem unbekannt.');
    if (c.target==='none') return result(false,'Diese Karte wird ohne Zielsystem ausgespielt.');
    if (targetOwner!==(c.target==='self'?owner:1-owner)) return result(false,c.target==='self'?'Wähle ein eigenes System.':'Wähle ein gegnerisches System.');
    if (sys.hp<=0 && c.id!=='backup') return result(false,'Dieses System ist ausgefallen. Nur ein gültiger Sicherungsstand ermöglicht ein Rückspiel.');
    const own=state.players[owner];
    const legal=eligibleTargets(state,cardId,owner).some(t=>t.owner===targetOwner&&t.system===key);
    if (!legal) {
      if (c.id==='scan' && sys.scannedBy.includes(owner)) return result(false,'Bereits analysiert. Als Nächstes ist eine Schwachstellenprüfung möglich.');
      if (c.id==='vuln' && !sys.scannedBy.includes(owner)) return result(false,'Erst Dienstanalyse auf dieses Ziel spielen.');
      if (c.id==='vuln' && sys.vulnerable) return result(false,'Schwachstelle bereits bestätigt. Jetzt ist ein Exploit möglich.');
      if (c.id==='exploit' && !sys.scannedBy.includes(owner)) return result(false,'Erst Dienstanalyse, dann Schwachstellenprüfung.');
      if (c.id==='exploit' && !sys.vulnerable) return result(false,'Schwachstelle nicht bestätigt. Schwachstellenprüfung ausspielen.');
      if (['internal','disk'].includes(c.id) && !own.access.internal) return result(false,'Servernetz-Zugang fehlt. Phishing → laterale Bewegung.');
      if (c.id==='ddos') return result(false,'Überlastung wirkt nur gegen öffentlich erreichbare Dienste (Gateway oder Webserver).');
      if (c.id==='phishing') return result(false,own.access.client?'Client-Zugang besteht bereits. Spare die Karte für einen späteren Zugang.':'Phishing ist auf Arbeitsstationen begrenzt.');
      if (c.id==='disk') return result(false,'Laufwerksstörung ist nur beim Datenserver möglich.');
      if (c.id==='raid') return result(false,'RAID-Schutz kann nur auf dem Datenserver installiert werden.');
      if (c.id==='backup') return result(false,sys.backupCharge<=0?'Kein Sicherungsstand. Zuerst eine Sicherung anlegen.':'Das Ziel benötigt keine Reparatur.');
      if (c.id==='script') return result(false,'Nur beschädigte eigene Systeme lassen sich reparieren.');
      if (c.id==='backupplan') return result(false,sys.hp!==sys.maxHp?'Ein neuer Sicherungsstand benötigt ein intaktes System.':'Maximal zwei Sicherungsstände je System.');
      if (c.id==='dnscheck') return result(false,'DNS-Diagnose wirkt ausschließlich auf den eigenen DNS-Server.');
      if (c.id==='segmentation') return result(false,'ACL-Segmentierung wird am eigenen Gateway eingerichtet.');
      if (c.id==='fortify') return result(false,'Firewall-Härtung wirkt nur auf Gateway oder Webserver.');
      if (!isReachable(state,owner,targetOwner,key)) return result(false,key==='client'?'Clientnetz nicht erreichbar: zunächst Phishing-Versuch ausspielen.':'Dieses System liegt hinter einer Segmentgrenze. Erst Client-Zugang und danach Servernetz-Zugang herstellen.');
      return result(false,'Ziel für diese Karte nicht zulässig.');
    }
    if (['ddos','exploit','internal','disk'].includes(cardId)) {
      let damage=cardId==='exploit'?3:2, protection='';
      if (cardId==='disk' && sys.raidCharge>0) {damage=0;protection='RAID verhindert diesen Laufwerksausfall.';}
      else if (['ddos','exploit'].includes(cardId) && sys.fortified>0) {damage-=1;protection='Firewall-Härtung reduziert den Schaden um 1.';}
      return result(true,damage?`Voraussichtlich ${damage} Schaden vor möglichen Reaktionen.`:'Durch vorhandenen Schutz voraussichtlich 0 Schaden.',{damage,projectedHp:Math.max(0,sys.hp-damage),protection,reactionPossible:['ddos','exploit','internal'].includes(cardId)});
    }
    const effects={scan:'Deckt den Dienst für Folgeaktionen auf.',vuln:'Bestätigt eine Schwachstelle für den Exploit.',phishing:'Erzeugt Client-Zugang.',fortify:'Verstärkt den Schutz gegen externe Angriffe.',segmentation:'Blockiert einen späteren unzulässigen Netzübergang.',raid:'Fängt einen Laufwerksausfall ab.',backup:'Stellt bis zu 3 HP aus einer Sicherung wieder her.',script:'Repariert 1 HP und zieht eine Karte.',backupplan:'Legt einen Sicherungsstand an.',dnscheck:'Prüft DNS und zieht eine Karte.'};
    const heal=cardId==='backup'?3:cardId==='script'?1:0;
    return result(true,effects[cardId]||'Karte auf dieses Ziel ausspielen.',{projectedHp:Math.min(sys.maxHp,sys.hp+heal)});
  }
  function cardPlayability(state, owner, cardId) {
    const c=CARDS[cardId],p=state.players[owner];
    const reply=(playable,reason)=>({playable,reason});
    if(!c || !p) return reply(false,'Unbekannte Karte.');
    if(state.winner!==null)return reply(false,'Das Duell ist beendet.');
    if(!p.hand.includes(cardId))return reply(false,'Karte nicht auf der Hand.');
    if(c.cost>p.kp)return reply(false,`Benötigt ${c.cost} KP, verfügbar ${p.kp}.`);
    if(state.mode==='tutorial' && !state.completed && currentStep(state)?.card!==cardId)return reply(false,'Aktuell ist eine andere Tutorial-Aktion vorgesehen.');
    if(state.phase==='response') {
      if(state.pending?.defender!==owner)return reply(false,'Der andere Spieler entscheidet.');
      if(c.category!=='Reaktion')return reply(false,'Im Reaktionsfenster sind nur passende Verteidigungskarten erlaubt.');
      const matching={ddos:'filter',exploit:'patch',internal:'isolate'}[state.pending.card];
      return reply(cardId===matching,cardId===matching?'Reaktion bereit.':'Diese Reaktion passt nicht zum Angriff.');
    }
    if(state.phase!=='main'||state.active!==owner)return reply(false,'Du bist derzeit nicht am Zug.');
    if(c.category==='Reaktion')return reply(false,'Nur bei einem gegnerischen Angriff spielbar.');
    if(cardId==='pivot'&&!p.access.client)return reply(false,'Erst Client-Zugang durch Phishing erhalten.');
    if(cardId==='pivot'&&p.access.internal)return reply(false,'Servernetz-Zugang besteht bereits. Eine weitere laterale Bewegung ist nicht erforderlich.');
    if(c.target!=='none' && eligibleTargets(state,cardId,owner).length===0)return reply(false,'Kein gültiges Ziel. Prüfe Zugangsweg und Kartenbedingungen.');
    return reply(true,c.target==='none'?'Sofort spielbar.':'Zielsystem auswählen.');
  }

  function allowed(state,owner,cardId,target){
    const c=CARDS[cardId];if(!c)return 'Unbekannte Karte.';
    const p=state.players[owner];
    if(state.winner!==null)return 'Das Duell ist beendet.';
    if(!p.hand.includes(cardId))return 'Karte nicht auf der Hand.';
    // A single legality decision for UI and engine; avoid diverging conditions.
    const status=cardPlayability(state,owner,cardId);
    if(!status.playable)return status.reason;
    if(c.target!=='none'&&!eligibleTargets(state,cardId,owner).some(t=>t.owner===target?.owner&&t.system===target?.system))return 'Dieses Ziel ist nicht zulässig oder nicht erreichbar.';
    if(state.mode==='tutorial'&&!state.completed){
      const step=currentStep(state);
      const wanted=step?.card;
      if(!wanted)return 'Folge zunächst der aktuellen Tutorial-Anweisung.';
      if(cardId!==wanted)return `In dieser Mission ist zuerst „${CARDS[wanted].name}“ vorgesehen.`;
      if(step.target&&target?.system!==step.target)return 'Wähle das in der Missionsanweisung genannte Ziel.';
      if(step.targetOwner!=null&&target?.owner!==step.targetOwner)return 'Wähle die richtige Spielfeldseite.';
    }
    return null;
  }
  function checkWinner(state){
    for(let owner=0;owner<2;owner++){
      const p=state.players[owner], dead=p.systems.filter(s=>s.hp<=0);
      if(dead.length>=3||findSys(state,owner,'data').hp<=0){state.winner=1-owner;state.phase='ended';log(state,`${state.players[1-owner].name} gewinnt: kritischer Infrastrukturausfall.`);return;}
    }
  }
  function consume(state,owner,cardId){const p=state.players[owner];p.kp-=CARDS[cardId].cost;p.hand.splice(p.hand.indexOf(cardId),1);p.discard.push(cardId);}
  function grantQuizPermit(state,owner,cardId,target=null){
    const error=allowed(state,owner,cardId,target);if(error)return {ok:false,error};
    state.quizPermit={owner,cardId,targetOwner:target?.owner??null,targetSystem:target?.system??null};
    return {ok:true};
  }
  function playCard(state,owner,cardId,target=null){
    const error=allowed(state,owner,cardId,target);if(error)return {ok:false,error};
    if(state.quizRequired && !(state.mode==='ai'&&owner===1)){
      const q=state.quizPermit;
      if(!q||q.owner!==owner||q.cardId!==cardId||q.targetOwner!==(target?.owner??null)||q.targetSystem!==(target?.system??null))
        return {ok:false,error:'Vor dem Ausspielen muss die zugehörige AP2-Frage richtig beantwortet werden.'};
    }
    state.quizPermit=null;
    const c=CARDS[cardId], p=state.players[owner], enemy=state.players[1-owner];
    consume(state,owner,cardId);log(state,`${p.name} spielt „${c.name}“${target?' → '+findSys(state,target.owner,target.system).name:''}.`);
    if(c.category==='Reaktion'){
      const pend=state.pending;
      const prev=pend.prevent;
      pend.prevent+=cardId==='patch'?3:2;
      if(cardId==='isolate')state.players[pend.owner].access.internal=false;
      if(cardId==='patch')findSys(state,pend.defender,pend.target).vulnerable=false;
      log(state,`${c.name} verhindert bis zu ${pend.prevent-prev} Schaden.`);
      resolvePending(state);
      event(state,'defend',{card:cardId});return {ok:true};
    }
    if(['ddos','exploit','internal','disk'].includes(cardId)){
      state.pending={owner,defender:1-owner,card:cardId,target:target.system,damage:cardId==='exploit'?3:2,prevent:0};state.phase='response';
      log(state,`${enemy.name} kann jetzt reagieren.`);
      return {ok:true,pending:true};
    }
    if(cardId==='scan')findSys(state,target.owner,target.system).scannedBy.push(owner);
    if(cardId==='vuln')findSys(state,target.owner,target.system).vulnerable=true;
    if(cardId==='backupplan')findSys(state,target.owner,target.system).backupCharge++;
    if(cardId==='dnscheck')draw(state,owner,1);
    if(cardId==='phishing')p.access.client=true;
    if(cardId==='pivot'){
      if(enemy.segmentation>0){enemy.segmentation--;log(state,'Segmentierung + ACL blockiert die laterale Bewegung.');}
      else p.access.internal=true;
    }
    if(cardId==='fortify')findSys(state,target.owner,target.system).fortified++;
    if(cardId==='segmentation')p.segmentation++;
    if(cardId==='raid')findSys(state,target.owner,target.system).raidCharge++;
    if(cardId==='backup'){const sys=findSys(state,target.owner,target.system);sys.backupCharge--;sys.hp=Math.min(sys.maxHp,sys.hp+3);}
    if(cardId==='script'){findSys(state,target.owner,target.system).hp=Math.min(findSys(state,target.owner,target.system).maxHp,findSys(state,target.owner,target.system).hp+1);draw(state,owner,1);}
    if(cardId==='log')draw(state,owner,2);
    event(state,'play',{owner,card:cardId,target:target?.system,targetOwner:target?.owner});
    return {ok:true};
  }
  function resolvePending(state){
    const q=state.pending;if(!q)return {ok:false,error:'Kein Angriff zum Auflösen.'};
    const sys=findSys(state,q.defender,q.target);let remaining=Math.max(0,q.damage-q.prevent);
    if(remaining>0&&q.card==='disk'&&sys.raidCharge>0){sys.raidCharge--;remaining=0;log(state,'RAID 5 toleriert den simulierten Einzellaufwerksausfall.');}
    if(remaining>0&&['ddos','exploit'].includes(q.card)&&sys.fortified>0){sys.fortified--;remaining=Math.max(0,remaining-1);log(state,'Firewall-Härtung reduziert 1 Schaden.');}
    sys.hp=Math.max(0,sys.hp-remaining);
    log(state,remaining?`${sys.name} verliert ${remaining} HP (${sys.hp}/${sys.maxHp}).`:`${sys.name}: Angriff vollständig abgewehrt.`);
    state.pending=null;state.phase='main';
    if(remaining>0)event(state,'damage',{card:q.card,owner:q.owner,target:q.target,targetOwner:q.defender,amount:remaining});
    checkWinner(state);
    return {ok:true,damage:remaining};
  }
  function simulateIncident(state){
    if(state.mode!=='tutorial'||state.missionId!==5||currentStep(state)?.type!=='incident')return {ok:false,error:'Hier ist kein Vorfall vorgesehen.'};
    const sys=findSys(state,0,'data');
    if(sys.raidCharge>0){sys.raidCharge--;log(state,'Laufwerksausfall simuliert. RAID 5 erhält die Datenserver-Verfügbarkeit.');}
    else{sys.hp=Math.max(0,sys.hp-2);log(state,'Laufwerksausfall verursacht 2 Schaden am Datenserver.');}
    event(state,'incident',{});return {ok:true};
  }
  function simulateAclIncident(state){
    if(state.mode!=='tutorial'||state.missionId!==6||currentStep(state)?.type!=='aclIncident')return {ok:false,error:'Hier ist kein ACL-Test vorgesehen.'};
    const p=state.players[0];
    if(p.segmentation<=0)return {ok:false,error:'Richte zuerst die ACL-Segmentierung ein.'};
    p.segmentation--;log(state,'ACL-Test: Der unerlaubte Netzübergang wurde blockiert. Kein Serverzugang entstanden.');
    event(state,'aclIncident',{});return {ok:true};
  }
  function answerQuiz(state,choice){
    const step=currentStep(state);
    if(state.mode!=='tutorial'||step?.type!=='quiz')return {ok:false,error:'Keine Prüfungsfrage aktiv.'};
    if(!Number.isInteger(choice)||choice<0||choice>=step.options.length)return {ok:false,error:'Ungültige Antwort.'};
    if(choice!==step.answer){log(state,'Antwort noch nicht korrekt. Prüfe die fachliche Begründung.');return {ok:false,error:'Noch nicht korrekt. Prüfe die technischen Randbedingungen.',explain:step.explain};}
    log(state,'AP2-Aufgabe richtig gelöst.');event(state,'quiz',{});return {ok:true,explain:step.explain};
  }
  function endTurn(state){
    if(state.mode==='tutorial')return {ok:false,error:'Schließe zunächst die Tutorial-Mission ab.'};
    if(state.winner!==null||state.phase!=='main')return {ok:false,error:'Zugwechsel momentan nicht möglich.'};
    state.quizPermit=null;
    state.active=1-state.active;state.turn++;const p=state.players[state.active];
    // Both players receive exactly 3 KP on their first personal turn.
    // The limit grows from the second personal turn, preventing a second-player KP head start.
    if(state.turn>2)p.maxKp=Math.min(8,p.maxKp+1);
    p.kp=p.maxKp;draw(state,state.active,1);state.aiMoves=0;
    if(state.winner!==null)return {ok:true,ended:true};
    log(state,`${p.name} ist am Zug (${p.kp} KP).`);return {ok:true};
  }
  // Persisted PRNG makes identical AI matches reproducible and permits replayable tests.
  function nextAiRandom(state){
    let x=(Number.isInteger(state.rngState)?state.rngState:((state.turn*2654435761)>>>0))>>>0;
    if(!x)x=0x6d2b79f5;
    x^=x<<13;x^=x>>>17;x^=x<<5;
    state.rngState=x>>>0;
    return state.rngState/4294967296;
  }
  function aiChoice(state){
    if(state.mode!=='ai'||state.active!==1||state.phase!=='main'||state.winner!==null)return null;
    const p=state.players[1],enemy=state.players[0],options=[];
    // Scoring avoids replaying scans on known targets and values threats that can win the duel.
    for(const id of new Set(p.hand)){
      const c=CARDS[id];if(c.category==='Reaktion'||p.kp<c.cost)continue;
      if(id==='pivot'&&(!p.access.client||p.access.internal))continue;
      const targets=c.target==='none'?[null]:eligibleTargets(state,id,1);
      for(const target of targets){
        const sys=target?findSys(state,target.owner,target.system):null;
        let score=0;
        if(['ddos','exploit','internal','disk'].includes(id)){
          const damage=id==='exploit'?3:2;
          score=18+damage*2+(sys.hp<=damage?45:0)+(sys.id==='data'&&sys.hp<=damage?95:0)+(sys.id==='data'?12:0);
          if(sys.id==='gateway')score-=5;
          if(id==='disk'&&sys.raidCharge>0)score-=40;
        }
        if(id==='phishing')score=p.access.client?-50:25;
        if(id==='pivot')score=35;
        if(id==='scan')score=(p.hand.includes('vuln')||p.hand.includes('exploit')?28:12)+(sys?.id==='web'?4:0);
        if(id==='vuln')score=(p.hand.includes('exploit')?38:18)+(sys?.hp<=3?5:0);
        if(id==='fortify')score=sys.hp<=2?20:11;
        if(id==='segmentation')score=p.segmentation>0?0:21;
        if(id==='raid')score=sys.raidCharge>0?0:21;
        if(id==='backupplan')score=sys.backupCharge>0?2:14;
        if(id==='backup')score=14+(sys.maxHp-sys.hp)*7+(sys.id==='data'?10:0);
        if(id==='script')score=14+(sys.maxHp-sys.hp)*4;
        if(id==='log')score=p.hand.length<=3?28:11;
        if(id==='dnscheck')score=18;
        // Preserve one KP for a potentially useful defense when there is no immediate winning play.
        if(p.kp===c.cost&&p.hand.some(x=>CARDS[x].category==='Reaktion'))score-=7;
        if(score>0)options.push({id,target,score});
      }
    }
    options.sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
    const level=state.aiDifficulty||'normal';
    if(level==='easy' && options.length>1)return options[Math.min(options.length-1,Math.floor(nextAiRandom(state)*Math.min(4,options.length)))];
    if(level==='normal' && options.length>1 && nextAiRandom(state)<0.17)return options[1];
    return options[0]||null;
  }
  function aiStep(state){
    if(state.mode!=='ai'||state.winner!==null)return {ok:false};
    if(state.phase==='response'){
      if(state.pending.defender!==1)return {ok:false,awaitHuman:true};
      const wanted=state.pending.card==='ddos'?'filter':state.pending.card==='exploit'?'patch':state.pending.card==='internal'?'isolate':null;
      const defend=state.aiDifficulty==='hard'||(state.aiDifficulty==='easy'?nextAiRandom(state)<0.30:nextAiRandom(state)<0.83);
      if(defend&&wanted&&state.players[1].hand.includes(wanted)&&state.players[1].kp>=CARDS[wanted].cost)playCard(state,1,wanted);
      else resolvePending(state);
      return {ok:true};
    }
    if(state.active!==1)return {ok:false};
    const turnLimit={easy:2,normal:4,hard:6}[state.aiDifficulty]||4;
    if(state.aiMoves>=turnLimit){endTurn(state);return {ok:true,finished:true};}
    const action=aiChoice(state);if(!action){endTurn(state);return {ok:true,finished:true};}
    const result=playCard(state,1,action.id,action.target);state.aiMoves++;
    if(!result.ok){endTurn(state);return {ok:true,finished:true};}
    return {ok:true};
  }
  function tooltipFor(state,owner,key){const sys=findSys(state,owner,key);return `${sys.name} | ${sys.hp}/${sys.maxHp} HP | ${sys.zone}`;}
  return {SYSTEMS,CARDS,DECK_BLUEPRINT,BASIC_IDS,BASIC_PRESETS,MISSIONS,createGame,currentStep,selectSystem,eligibleTargets,isReachable,targetAdvice,cardPlayability,allowed,grantQuizPermit,playCard,resolvePending,simulateIncident,endTurn,aiChoice,aiStep,findSys,tooltipFor,deckFromBlueprint,deckFromList,validateDeck,PRESETS,simulateAclIncident,answerQuiz};
});
