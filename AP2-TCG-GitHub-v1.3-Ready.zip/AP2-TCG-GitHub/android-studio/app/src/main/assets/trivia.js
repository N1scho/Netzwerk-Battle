/* 57 AP2-FISI-Fragen: drei Schwierigkeitsstufen pro Kartentyp. */
window.AP2TRIVIA = {
  "scan": [
    {
      "question": "Was zeigt ein einfacher Portscan unmittelbar?",
      "options": [
        "Erreichbare Ports bzw. Dienste",
        "Ein gültiges Administratorkennwort",
        "Alle vorhandenen Sicherheitslücken"
      ],
      "answer": 0,
      "explain": "Ein Portscan erkennt erreichbare Ports und möglicherweise Dienste; daraus folgt keine bestätigte Schwachstelle."
    },
    {
      "question": "Welches Protokoll testet ein TCP-SYN-Scan auf Transporteebene?",
      "options": [
        "UDP",
        "TCP",
        "ICMP"
      ],
      "answer": 1,
      "explain": "Ein SYN-Scan untersucht das Verhalten von TCP-Ports."
    },
    {
      "question": "Eine TCP-Verbindung zu Port 443 gelingt, der Browser zeigt aber eine Zertifikatswarnung. Was ist damit bewiesen?",
      "options": [
        "Der Dienst ist per TCP erreichbar, nicht seine Vertrauenswürdigkeit",
        "Die Zertifikatskette ist gültig",
        "Der Server lässt sich administrieren"
      ],
      "answer": 0,
      "explain": "TCP-Erreichbarkeit bestätigt weder gültige Zertifikate noch sichere Konfiguration."
    }
  ],
  "ddos": [
    {
      "question": "Welches Schutzziel beeinträchtigt ein Überlastungsangriff vorrangig?",
      "options": [
        "Verfügbarkeit",
        "Vertraulichkeit",
        "Authentizität"
      ],
      "answer": 0,
      "explain": "DDoS-Angriffe zielen typischerweise auf die Verfügbarkeit von Diensten."
    },
    {
      "question": "Wofür steht das zweite D in DDoS?",
      "options": [
        "Direct",
        "Distributed",
        "Domain"
      ],
      "answer": 1,
      "explain": "Distributed Denial of Service bezeichnet einen verteilten Überlastungsangriff."
    },
    {
      "question": "Eine Webseite wird durch massenweise HTTP-Anfragen überlastet. Welche Gegenmaßnahme ist am zielgerichtetsten?",
      "options": [
        "DDoS-Filterung und Rate-Limits am Eintrittspunkt",
        "RAID 5 neu synchronisieren",
        "DNS-Cache am Client löschen"
      ],
      "answer": 0,
      "explain": "Anwendungsnahe Lastfilterung begrenzt eingehenden Anfrageverkehr."
    }
  ],
  "exploit": [
    {
      "question": "Wann ist das Ausnutzen einer Sicherheitslücke im Spiel zulässig?",
      "options": [
        "Sobald DNS antwortet",
        "Nach Bestätigung einer passenden Schwachstelle",
        "Wenn irgendein Port offen ist"
      ],
      "answer": 1,
      "explain": "Die bloße Erreichbarkeit eines Dienstes beweist keine Schwachstelle."
    },
    {
      "question": "Was ist ein Sicherheits-Patch?",
      "options": [
        "Eine Änderung, die bekannte Schwachstellen beheben kann",
        "Eine vollständige Datensicherung",
        "Ein Netzwerk-Trunk"
      ],
      "answer": 0,
      "explain": "Ein Patch kann eine spezifische Schwachstelle schließen; weitere Schutzmaßnahmen können nötig bleiben."
    },
    {
      "question": "Ein Scanner erkennt Software X, der Versionsstand fehlt. Darf eine konkrete CVE bereits als bestätigt gelten?",
      "options": [
        "Ja, bei jedem offenen Port",
        "Nein, erst nach verifizierter Betroffenheit",
        "Ja, sobald TLS aktiv ist"
      ],
      "answer": 1,
      "explain": "Für eine bestätigte Betroffenheit sind mindestens Version, Konfiguration und Herstellerhinweise zu prüfen."
    }
  ],
  "phishing": [
    {
      "question": "Welche Angriffsmethode nutzt täuschend echte Nachrichten zur Datenerlangung?",
      "options": [
        "Phishing",
        "RAID-Striping",
        "Spanning Tree"
      ],
      "answer": 0,
      "explain": "Phishing täuscht Identitäten oder Anlässe vor und soll Nutzer zu Handlungen verleiten."
    },
    {
      "question": "Welche Maßnahme senkt das Risiko gestohlener Passwörter?",
      "options": [
        "Mehrfaktor-Authentifizierung",
        "Ein größeres VLAN",
        "Deaktivierte Logdateien"
      ],
      "answer": 0,
      "explain": "MFA kann die missbräuchliche Nutzung eines entwendeten Passworts deutlich erschweren."
    },
    {
      "question": "Ein Angreifer hat das Passwort eines Mitarbeiters erbeutet. Welche zusätzliche Maßnahme reduziert die Kontoübernahme am stärksten?",
      "options": [
        "MFA mit phishingresistenter Methode",
        "Ein zusätzliches VLAN ohne ACL",
        "Ein größeres RAID"
      ],
      "answer": 0,
      "explain": "Phishingresistente MFA, etwa FIDO2, hilft gegen die missbräuchliche Kennwortnutzung."
    }
  ],
  "pivot": [
    {
      "question": "Was wird für Kommunikation zwischen unterschiedlichen IPv4-Netzen benötigt?",
      "options": [
        "Routing auf Schicht 3",
        "Nur ein Access-Port",
        "Nur ein Trunk-Port"
      ],
      "answer": 0,
      "explain": "Router bzw. Layer-3-Switches vermitteln zwischen IP-Netzen, sofern Regeln es zulassen."
    },
    {
      "question": "Ein Trunk-Port verbindet zwei Switches. Was überträgt er typischerweise?",
      "options": [
        "Mehrere VLANs per Tagging",
        "Automatisch Pakete zwischen IP-Netzen",
        "Jedes Kennwort"
      ],
      "answer": 0,
      "explain": "Ein Trunk transportiert VLANs, übernimmt aber nicht automatisch Inter-VLAN-Routing."
    },
    {
      "question": "VLAN 10 (10.0.10.0/24) und VLAN 20 (10.0.20.0/24) liegen auf demselben Switch. Was benötigt ihre IP-Kommunikation?",
      "options": [
        "Einen Trunk allein",
        "Layer-3-Routing und erlaubende Regeln",
        "Nur identische MAC-Adressen"
      ],
      "answer": 1,
      "explain": "VLANs trennen Layer-2-Broadcast-Domänen. Inter-VLAN-Verkehr braucht Routing und passende Freigaben."
    }
  ],
  "internal": [
    {
      "question": "Warum sind interne Server aus dem Internet nicht automatisch erreichbar?",
      "options": [
        "Routing, Firewalls und Netzsegmentierung können Zugriffe begrenzen",
        "DNS verbietet alle Pakete",
        "Ein RAID schützt Netzports"
      ],
      "answer": 0,
      "explain": "Die Erreichbarkeit hängt von Wegen, Regeln und vorhandenen Berechtigungen ab."
    },
    {
      "question": "Welches Werkzeug kann eine IP-Route auf ihrem Weg untersuchen?",
      "options": [
        "traceroute bzw. tracert",
        "format",
        "mkdir"
      ],
      "answer": 0,
      "explain": "Traceroute/Tracert zeigt mögliche Zwischenstationen einer IP-Verbindung."
    },
    {
      "question": "Eine Firewall soll nur HTTPS aus dem Internet an den DMZ-Webserver erlauben. Welche Regel ist am engsten?",
      "options": [
        "Internet → DMZ-Webserver TCP 443",
        "Internet → gesamtes LAN TCP/UDP alle Ports",
        "DMZ → Internet TCP 53"
      ],
      "answer": 0,
      "explain": "Eine konkrete Quelle, ein konkretes Ziel und ein Dienst begrenzen unnötige Freigaben."
    }
  ],
  "disk": [
    {
      "question": "Wie viele Laufwerksausfälle toleriert ein intaktes RAID 5?",
      "options": [
        "Genau einen",
        "Zwei gleichzeitig",
        "Beliebig viele"
      ],
      "answer": 0,
      "explain": "RAID 5 toleriert einen Laufwerksausfall; bei einem zweiten vor dem Wiederaufbau droht Datenverlust."
    },
    {
      "question": "Ein RAID-5-Verbund hat 4 × 2 TB. Wie viel Kapazität ist nutzbar?",
      "options": [
        "8 TB",
        "6 TB",
        "4 TB"
      ],
      "answer": 1,
      "explain": "Bei gleich großen Laufwerken beträgt die nutzbare Kapazität (n − 1) × Laufwerksgröße = 6 TB."
    },
    {
      "question": "Bei RAID 5 fallen zwei Platten vor einem erfolgreichen Wiederaufbau aus. Was folgt typischerweise?",
      "options": [
        "Der Verbund toleriert beide Ausfälle",
        "Ein vollständiger Datenverlust ist möglich",
        "Die Kapazität verdoppelt sich"
      ],
      "answer": 1,
      "explain": "Ein klassisches RAID 5 verträgt nur einen Plattenausfall."
    }
  ],
  "filter": [
    {
      "question": "Welcher Wert wird bei einer Portfilterregel für HTTPS typischerweise genutzt?",
      "options": [
        "TCP 443",
        "UDP 67",
        "TCP 25"
      ],
      "answer": 0,
      "explain": "HTTPS verwendet normalerweise TCP-Port 443."
    },
    {
      "question": "Eine Firewallregel erlaubt TCP 443. Was bedeutet das?",
      "options": [
        "Passender HTTPS-Verkehr kann erlaubt sein",
        "Alle Ports sind offen",
        "Das Zielsystem ist frei von Schwachstellen"
      ],
      "answer": 0,
      "explain": "Die Regel betrifft den definierten Verkehr; weitere Bedingungen können gelten."
    },
    {
      "question": "Welche klassische Regel erlaubt DNS-Anfragen aus dem Clientnetz an den internen Resolver mit minimaler Öffnung?",
      "options": [
        "Clientnetz → Resolver UDP 53 (ggf. zusätzlich TCP 53)",
        "Internet → gesamtes LAN TCP 445",
        "Resolver → Clientnetz TCP 3389"
      ],
      "answer": 0,
      "explain": "DNS verwendet häufig UDP 53, in bestimmten Fällen auch TCP 53; Freigaben müssen gezielt erfolgen."
    }
  ],
  "patch": [
    {
      "question": "Warum müssen Systeme regelmäßig gepatcht werden?",
      "options": [
        "Um bekannte Sicherheitslücken zu schließen",
        "Damit RAID doppelt so schnell wird",
        "Damit ein Trunk ohne VLAN funktioniert"
      ],
      "answer": 0,
      "explain": "Sicherheitsupdates reduzieren bekannte Angriffsflächen."
    },
    {
      "question": "Was sollte vor einem kritischen Produktivupdate geprüft werden?",
      "options": [
        "Kompatibilität, Sicherung und Rückfallplan",
        "Nur die Farbe der Benutzeroberfläche",
        "Nur die Anzahl der Mäuse"
      ],
      "answer": 0,
      "explain": "Kompatibilitäts- und Rückfallprüfung reduzieren Update-Risiken."
    },
    {
      "question": "Nach einem kritischen Patch startet ein Fachverfahren nicht mehr. Was hätte die Wiederanlaufzeit reduzieren können?",
      "options": [
        "Getesteter Rückfallplan und Sicherungsstand",
        "Alle Ports offen lassen",
        "Kein Monitoring einsetzen"
      ],
      "answer": 0,
      "explain": "Ein vorher geprüfter Rückfall- bzw. Wiederherstellungsplan begrenzt Betriebsunterbrechungen."
    }
  ],
  "isolate": [
    {
      "question": "Was bedeutet Netzisolation bei einem betroffenen Host?",
      "options": [
        "Kommunikation wird gezielt eingeschränkt oder getrennt",
        "Alle Dateien werden automatisch gelöscht",
        "DNS wird in RAID umgewandelt"
      ],
      "answer": 0,
      "explain": "Durch Isolation wird die mögliche Ausbreitung oder Kommunikation begrenzt."
    },
    {
      "question": "Welche Maßnahme entzieht einem kompromittierten Konto Berechtigungen?",
      "options": [
        "Konto sperren oder Zugänge widerrufen",
        "Neue Switchports schaffen",
        "RAID-Verbund vergrößern"
      ],
      "answer": 0,
      "explain": "Sperren und Widerrufen reduzieren den weiteren Zugriff mit kompromittierten Identitäten."
    },
    {
      "question": "Ein kompromittierter Client wird isoliert. Welche Aussage ist korrekt?",
      "options": [
        "Netzzugriffe lassen sich einschränken, der Bereinigungsnachweis bleibt separat",
        "Alle Schadprogramme werden dadurch sofort entfernt",
        "Backups des Servers sind automatisch gelöscht"
      ],
      "answer": 0,
      "explain": "Isolation reduziert weitere Kommunikation, ersetzt jedoch keine Untersuchung und Bereinigung."
    }
  ],
  "fortify": [
    {
      "question": "Was bedeutet Defense in Depth?",
      "options": [
        "Mehrere aufeinander abgestimmte Schutzmaßnahmen",
        "Nur ein einziges sehr langes Passwort",
        "RAID ohne Datensicherung"
      ],
      "answer": 0,
      "explain": "Mehrere Schutzebenen verringern das Risiko eines einzelnen Schutzversagens."
    },
    {
      "question": "Welche Regel ist für eine Internet-Webanwendung möglichst eng?",
      "options": [
        "Internet → DMZ-Webserver, TCP 443",
        "Internet → gesamtes LAN, alle Ports",
        "Internet → Datenbank, alle Ports"
      ],
      "answer": 0,
      "explain": "Freigaben sollten auf notwendige Quelle, Ziel und Dienste beschränkt werden."
    },
    {
      "question": "Ein Webserver steht in der DMZ. Was entspricht Defense in Depth?",
      "options": [
        "Nur ein starkes Root-Passwort",
        "Netztrennung, minimale Freigaben, Patches und Monitoring",
        "DMZ und LAN ohne Filter verbinden"
      ],
      "answer": 1,
      "explain": "Mehrere unabhängige Schutzschichten reduzieren die Wirkung einzelner Schwachstellen."
    }
  ],
  "segmentation": [
    {
      "question": "Was trennt ein VLAN auf einem Switch?",
      "options": [
        "Eine Broadcast-Domäne auf Schicht 2",
        "Automatisch alle IP-Routen",
        "Die Platten eines RAID"
      ],
      "answer": 0,
      "explain": "Jedes VLAN bildet grundsätzlich eine separate Broadcast-Domäne."
    },
    {
      "question": "Was macht eine ACL auf einem Router oder Layer-3-Switch?",
      "options": [
        "Sie kontrolliert erlaubten Netzwerkverkehr anhand von Regeln",
        "Sie speichert alle Passwörter",
        "Sie ersetzt alle Backups"
      ],
      "answer": 0,
      "explain": "ACLs können Datenverkehr an Segmentübergängen gezielt zulassen oder verweigern."
    },
    {
      "question": "Ein Endgerät an einem Access-Port in VLAN 10 soll VLAN 20 erreichen. Was ist erforderlich?",
      "options": [
        "Ein Router/L3-Switch mit erlaubenden Regeln",
        "Das Setzen eines Trunks am Endgerät genügt",
        "RAID 1 auf dem DHCP-Server"
      ],
      "answer": 0,
      "explain": "Erforderlich sind Layer-3-Routing und eine passende Zugriffsregel."
    }
  ],
  "raid": [
    {
      "question": "Welche Aussage zu RAID 5 ist korrekt?",
      "options": [
        "Verteilte Parität ermöglicht einen Laufwerksausfall",
        "Es benötigt exakt zwei Laufwerke",
        "Es ersetzt eine externe Datensicherung"
      ],
      "answer": 0,
      "explain": "RAID 5 verwendet verteilte Parität und benötigt mindestens drei Laufwerke."
    },
    {
      "question": "Wie viele Laufwerke sind für RAID 5 mindestens erforderlich?",
      "options": [
        "2",
        "3",
        "5"
      ],
      "answer": 1,
      "explain": "RAID 5 benötigt mindestens drei Laufwerke."
    },
    {
      "question": "Vier gleich große Festplatten zu je 2 TB bilden RAID 5. Wie groß ist die Nutzkapazität?",
      "options": [
        "8 TB",
        "6 TB",
        "4 TB"
      ],
      "answer": 1,
      "explain": "Bei gleich großen Festplatten: (4 − 1) × 2 TB = 6 TB."
    }
  ],
  "backup": [
    {
      "question": "Was ist ein Rückspiel?",
      "options": [
        "Daten aus einem Sicherungsstand wiederherstellen",
        "Dateien endgültig löschen",
        "Einen Switch neu starten"
      ],
      "answer": 0,
      "explain": "Beim Rückspiel wird ein vorhandener Sicherungsstand zurückgespielt."
    },
    {
      "question": "Welche Voraussetzung braucht ein erfolgreiches Rückspiel?",
      "options": [
        "Ein geeigneter zuvor erstellter Sicherungsstand",
        "Nur eine RAID-LED",
        "Nur einen freien DNS-Eintrag"
      ],
      "answer": 0,
      "explain": "Ein Rückspiel setzt eine vorhandene, nutzbare Datensicherung voraus."
    },
    {
      "question": "RPO = 4 Stunden, RTO = 2 Stunden. Was beschreibt diese Kombination?",
      "options": [
        "Maximal 4 Stunden Datenverlust und 2 Stunden Wiederanlaufzeit",
        "4 Stunden Reparaturzeit und 2 Stunden Aufbewahrung",
        "4 Stunden für DNS und 2 Stunden für RAID"
      ],
      "answer": 0,
      "explain": "RPO beschreibt maximal tolerierbaren Datenverlust, RTO die zulässige Wiederanlaufzeit."
    }
  ],
  "log": [
    {
      "question": "Welches Werkzeug zeigt unter Linux häufig die letzten Zeilen einer Datei?",
      "options": [
        "tail",
        "mkdir",
        "chmod"
      ],
      "answer": 0,
      "explain": "tail gibt die letzten Zeilen einer Datei aus, häufig für die Logauswertung genutzt."
    },
    {
      "question": "Was liefert ein Zeitstempel in einer Logdatei?",
      "options": [
        "Ereigniszeitpunkt für die Fehleranalyse",
        "Die Netzmaske des Switches",
        "Die Anzahl der RAID-Platten"
      ],
      "answer": 0,
      "explain": "Zeitstempel ermöglichen eine zeitliche Korrelation von Ereignissen."
    },
    {
      "question": "Du untersuchst einen Dienstausfall um 14:35. Welche Auswertung hilft beim Eingrenzen am ehesten?",
      "options": [
        "Zeitgestempelte Logs verschiedener Komponenten korrelieren",
        "Systemprotokolle sofort löschen",
        "Nur Dateinamen alphabetisch sortieren"
      ],
      "answer": 0,
      "explain": "Zeitliche Korrelation aus mehreren Quellen kann den Fehlerpfad eingrenzen."
    }
  ],
  "script": [
    {
      "question": "Welcher Befehl listet unter Linux Verzeichniseinträge auf?",
      "options": [
        "ls",
        "cd",
        "rm"
      ],
      "answer": 0,
      "explain": "ls listet Dateisystemeinträge; cd wechselt das Arbeitsverzeichnis."
    },
    {
      "question": "Was bewirkt eine Schleife in einem Skript?",
      "options": [
        "Sie wiederholt einen Anweisungsblock",
        "Sie ersetzt einen Router",
        "Sie löscht zwingend alle Dateien"
      ],
      "answer": 0,
      "explain": "Schleifen führen Anweisungen abhängig von einer Bedingung oder Iteration mehrfach aus."
    },
    {
      "question": "Ein Bash-Skript soll nur bei erfolgreicher Ausführung des ersten Befehls fortfahren. Welcher Operator eignet sich?",
      "options": [
        "&&",
        "||",
        ";"
      ],
      "answer": 0,
      "explain": "Mit && wird die nächste Anweisung nur bei Exit-Status 0 des vorherigen Befehls ausgeführt."
    }
  ],
  "vuln": [
    {
      "question": "Ist ein offener Port bereits eine nachgewiesene Schwachstelle?",
      "options": [
        "Nein",
        "Ja, immer",
        "Nur bei DNS"
      ],
      "answer": 0,
      "explain": "Eine Schwachstelle erfordert einen konkreten Nachweis in Software oder Konfiguration."
    },
    {
      "question": "Was identifiziert eine CVE-Kennung?",
      "options": [
        "Eine öffentlich dokumentierte Schwachstelle",
        "Ein bestimmtes VLAN",
        "Eine IPv4-Subnetzmaske"
      ],
      "answer": 0,
      "explain": "CVE-IDs dienen zur eindeutigen Referenzierung öffentlich bekannter Schwachstellen."
    },
    {
      "question": "Ein CVE-Eintrag nennt eine betroffene Version, das eigene System hat eine andere Version. Was ist der nächste Schritt?",
      "options": [
        "Version und Konfiguration gegen Herstellerhinweise abgleichen",
        "Sofortige Kompromittierung als bewiesen melden",
        "Eine neue VLAN-ID vergeben"
      ],
      "answer": 0,
      "explain": "Eine CVE allein beweist nicht, dass genau das konfigurierte System verwundbar ist."
    }
  ],
  "dnscheck": [
    {
      "question": "Welcher Port wird für klassische DNS-Abfragen meist verwendet?",
      "options": [
        "53",
        "25",
        "3389"
      ],
      "answer": 0,
      "explain": "DNS verwendet meistens UDP 53 und für bestimmte Antworten/Transfers auch TCP 53."
    },
    {
      "question": "Welches Werkzeug eignet sich zum Prüfen einer DNS-Antwort?",
      "options": [
        "nslookup",
        "net use",
        "taskkill"
      ],
      "answer": 0,
      "explain": "nslookup fragt DNS-Einträge bei einem Resolver ab."
    },
    {
      "question": "Ein Host kann 8.8.8.8 erreichen, aber example.org wird nicht aufgelöst. Was prüfst du zuerst?",
      "options": [
        "Konfigurierten DNS-Resolver und DNS-Abfragen",
        "RAID-Parität auf dem Webserver",
        "Monitor-Auflösung"
      ],
      "answer": 0,
      "explain": "IP-Erreichbarkeit bei fehlender Namensauflösung deutet auf eine DNS-bezogene Ursache."
    }
  ],
  "backupplan": [
    {
      "question": "Wann muss ein Sicherungsstand angelegt sein, um nach einem Vorfall zu helfen?",
      "options": [
        "Vor dem Vorfall",
        "Erst nach dem Datenverlust",
        "Nur während eines Router-Neustarts"
      ],
      "answer": 0,
      "explain": "Nur ein zuvor erstellter brauchbarer Sicherungsstand kann verloren gegangene Daten wiederherstellen."
    },
    {
      "question": "Wofür steht die 3-2-1-Regel als Backup-Grundprinzip?",
      "options": [
        "3 Kopien, 2 Medientypen, 1 extern",
        "3 Server, 2 VLANs, 1 Switch",
        "3 Router, 2 IP-Adressen, 1 DNS"
      ],
      "answer": 0,
      "explain": "Die 3-2-1-Regel empfiehlt drei Datenkopien auf zwei Medien mit einer Kopie an einem getrennten Ort."
    },
    {
      "question": "Ein System braucht RPO = 1 Stunde. Welche Sicherungsfrequenz ist grundsätzlich erforderlich?",
      "options": [
        "Nur einmal im Monat",
        "So häufig, dass höchstens 1 Stunde Datenstand verloren geht",
        "Nur nach dem Ausfall sichern"
      ],
      "answer": 1,
      "explain": "Sicherungs-/Replikationsintervalle müssen das definierte Wiederherstellungsziel ermöglichen."
    }
  ]
};
