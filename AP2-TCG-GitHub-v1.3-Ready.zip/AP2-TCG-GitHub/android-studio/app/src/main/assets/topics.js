/* AP2 TCG v1.2 – 40 Themen mit Fragenpaket-Zuordnung */
window.AP2TOPICS=[
  {
    "id": "ipv4",
    "name": "IPv4 und Subnetting",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Wie viele Bits besitzt eine IPv4-Adresse?",
          "options": [
            "32",
            "64",
            "128"
          ],
          "answer": 0,
          "explain": "IPv4-Adressen bestehen aus 32 Bits.",
          "operator": "Nennen"
        },
        {
          "question": "Wie viele Oktette hat eine IPv4-Adresse?",
          "options": [
            "4",
            "8",
            "16"
          ],
          "answer": 0,
          "explain": "IPv4 enthält 4 Gruppen zu je 8 Bit.",
          "operator": "Nennen"
        },
        {
          "question": "Welche IPv4-Adresse ist privat nach RFC 1918?",
          "options": [
            "192.168.20.10",
            "8.8.8.8",
            "1.1.1.1"
          ],
          "answer": 0,
          "explain": "192.168.0.0/16 ist ein privater IPv4-Adressraum.",
          "operator": "Nennen"
        },
        {
          "question": "Wozu dient die Subnetzmaske?",
          "options": [
            "Sie grenzt Netz- und Hostanteil einer IPv4-Adresse ab",
            "Sie nennt den DNS-Server",
            "Sie verschlüsselt Frames"
          ],
          "answer": 0,
          "explain": "Die Maske definiert das IP-Netz und die Hostbits.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Wie viele nutzbare Hostadressen hat ein normales /27-IPv4-Netz?",
          "options": [
            "32",
            "30",
            "62"
          ],
          "answer": 1,
          "explain": "Bei /27 verbleiben fünf Hostbits: 2⁵ − 2 = 30.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher CIDR-Präfix gehört zu 255.255.255.192?",
          "options": [
            "/26",
            "/24",
            "/28"
          ],
          "answer": 0,
          "explain": "192 entspricht 11000000, also 2 gesetzten Bits im vierten Oktett: 24 + 2 = /26.",
          "operator": "Nennen"
        },
        {
          "question": "Wie viele nutzbare Hostadressen hat ein übliches IPv4-/27-Netz?",
          "options": [
            "30",
            "32",
            "62"
          ],
          "answer": 0,
          "explain": "Ein /27 hat 2⁵ = 32 Adressen, davon bei klassischem Subnetz 30 nutzbare Hosts.",
          "operator": "Nennen"
        },
        {
          "question": "Wann sendet ein IPv4-Host an sein Standardgateway?",
          "options": [
            "Wenn das Ziel außerhalb seines direkt angeschlossenen Netzes liegt",
            "Bei jeder lokalen MAC-Kommunikation",
            "Nur bei DNS-Abfragen"
          ],
          "answer": 0,
          "explain": "Der Host entscheidet anhand seiner Routingtabelle und der Netzmaske.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Ein Host hat 192.168.12.94/26. Wie lautet die Netzwerkadresse?",
          "options": [
            "192.168.12.0",
            "192.168.12.64",
            "192.168.12.96"
          ],
          "answer": 1,
          "explain": "/26 ergibt 64er-Blöcke: 0–63, 64–127 usw. 94 liegt im Netz .64/26.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Host hat 172.16.5.130/25. Wie lautet die Broadcastadresse?",
          "options": [
            "172.16.5.255",
            "172.16.5.127",
            "172.16.5.129"
          ],
          "answer": 0,
          "explain": "/25 teilt das Oktett in 0–127 und 128–255; 130 liegt im zweiten Netz.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher kleinste klassische IPv4-Präfix bietet mindestens 50 nutzbare Hostadressen?",
          "options": [
            "/26",
            "/27",
            "/28"
          ],
          "answer": 0,
          "explain": "/26 liefert 64 Adressen und 62 nutzbare Hosts; /27 liefert nur 30.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Netz 10.10.0.0/24 soll in vier gleich große Netze zerlegt werden. Welcher Präfix entsteht?",
          "options": [
            "/26",
            "/25",
            "/28"
          ],
          "answer": 0,
          "explain": "Für vier Teilnetze werden zwei weitere Netzbits benötigt: /24 + 2 = /26.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Host hat 10.20.0.3/25. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.20.0.0",
            "10.20.0.128",
            "10.20.0.1"
          ],
          "answer": 0,
          "explain": "Bei /25 beträgt die Blockgröße 128. Hostadresse 3 liegt im Netz 10.20.0.0/25.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.21.17.196/26. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.21.17.192",
            "10.21.17.128",
            "10.21.17.193"
          ],
          "answer": 0,
          "explain": "Bei /26 beträgt die Blockgröße 64. Hostadresse 196 liegt im Netz 10.21.17.192/26.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.22.34.197/27. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.22.34.192",
            "10.22.34.224",
            "10.22.34.193"
          ],
          "answer": 0,
          "explain": "Bei /27 beträgt die Blockgröße 32. Hostadresse 197 liegt im Netz 10.22.34.192/27.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.23.51.150/28. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.23.51.144",
            "10.23.51.160",
            "10.23.51.145"
          ],
          "answer": 0,
          "explain": "Bei /28 beträgt die Blockgröße 16. Hostadresse 150 liegt im Netz 10.23.51.144/28.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.24.68.7/25. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.24.68.0",
            "10.24.68.128",
            "10.24.68.1"
          ],
          "answer": 0,
          "explain": "Bei /25 beträgt die Blockgröße 128. Hostadresse 7 liegt im Netz 10.24.68.0/25.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.25.85.200/26. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.25.85.192",
            "10.25.85.128",
            "10.25.85.193"
          ],
          "answer": 0,
          "explain": "Bei /26 beträgt die Blockgröße 64. Hostadresse 200 liegt im Netz 10.25.85.192/26.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.26.102.73/27. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.26.102.64",
            "10.26.102.96",
            "10.26.102.65"
          ],
          "answer": 0,
          "explain": "Bei /27 beträgt die Blockgröße 32. Hostadresse 73 liegt im Netz 10.26.102.64/27.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.27.119.90/28. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.27.119.80",
            "10.27.119.96",
            "10.27.119.81"
          ],
          "answer": 0,
          "explain": "Bei /28 beträgt die Blockgröße 16. Hostadresse 90 liegt im Netz 10.27.119.80/28.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.28.136.11/25. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.28.136.0",
            "10.28.136.128",
            "10.28.136.1"
          ],
          "answer": 0,
          "explain": "Bei /25 beträgt die Blockgröße 128. Hostadresse 11 liegt im Netz 10.28.136.0/25.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.29.153.204/26. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.29.153.192",
            "10.29.153.128",
            "10.29.153.193"
          ],
          "answer": 0,
          "explain": "Bei /26 beträgt die Blockgröße 64. Hostadresse 204 liegt im Netz 10.29.153.192/26.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.30.170.205/27. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.30.170.192",
            "10.30.170.224",
            "10.30.170.193"
          ],
          "answer": 0,
          "explain": "Bei /27 beträgt die Blockgröße 32. Hostadresse 205 liegt im Netz 10.30.170.192/27.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.31.187.30/28. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.31.187.16",
            "10.31.187.32",
            "10.31.187.17"
          ],
          "answer": 0,
          "explain": "Bei /28 beträgt die Blockgröße 16. Hostadresse 30 liegt im Netz 10.31.187.16/28.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.32.204.15/25. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.32.204.0",
            "10.32.204.128",
            "10.32.204.1"
          ],
          "answer": 0,
          "explain": "Bei /25 beträgt die Blockgröße 128. Hostadresse 15 liegt im Netz 10.32.204.0/25.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.33.221.208/26. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.33.221.192",
            "10.33.221.128",
            "10.33.221.193"
          ],
          "answer": 0,
          "explain": "Bei /26 beträgt die Blockgröße 64. Hostadresse 208 liegt im Netz 10.33.221.192/26.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.34.238.81/27. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.34.238.64",
            "10.34.238.96",
            "10.34.238.65"
          ],
          "answer": 0,
          "explain": "Bei /27 beträgt die Blockgröße 32. Hostadresse 81 liegt im Netz 10.34.238.64/27.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.35.255.214/28. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.35.255.208",
            "10.35.255.224",
            "10.35.255.209"
          ],
          "answer": 0,
          "explain": "Bei /28 beträgt die Blockgröße 16. Hostadresse 214 liegt im Netz 10.35.255.208/28.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.36.16.19/25. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.36.16.0",
            "10.36.16.128",
            "10.36.16.1"
          ],
          "answer": 0,
          "explain": "Bei /25 beträgt die Blockgröße 128. Hostadresse 19 liegt im Netz 10.36.16.0/25.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.37.33.212/26. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.37.33.192",
            "10.37.33.128",
            "10.37.33.193"
          ],
          "answer": 0,
          "explain": "Bei /26 beträgt die Blockgröße 64. Hostadresse 212 liegt im Netz 10.37.33.192/26.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.38.50.213/27. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.38.50.192",
            "10.38.50.224",
            "10.38.50.193"
          ],
          "answer": 0,
          "explain": "Bei /27 beträgt die Blockgröße 32. Hostadresse 213 liegt im Netz 10.38.50.192/27.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.39.67.154/28. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.39.67.144",
            "10.39.67.160",
            "10.39.67.145"
          ],
          "answer": 0,
          "explain": "Bei /28 beträgt die Blockgröße 16. Hostadresse 154 liegt im Netz 10.39.67.144/28.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.40.84.23/25. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.40.84.0",
            "10.40.84.128",
            "10.40.84.1"
          ],
          "answer": 0,
          "explain": "Bei /25 beträgt die Blockgröße 128. Hostadresse 23 liegt im Netz 10.40.84.0/25.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.41.101.216/26. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.41.101.192",
            "10.41.101.128",
            "10.41.101.193"
          ],
          "answer": 0,
          "explain": "Bei /26 beträgt die Blockgröße 64. Hostadresse 216 liegt im Netz 10.41.101.192/26.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.42.118.89/27. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.42.118.64",
            "10.42.118.96",
            "10.42.118.65"
          ],
          "answer": 0,
          "explain": "Bei /27 beträgt die Blockgröße 32. Hostadresse 89 liegt im Netz 10.42.118.64/27.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Host hat 10.43.135.94/28. Berechnen Sie seine Netzwerkadresse.",
          "options": [
            "10.43.135.80",
            "10.43.135.96",
            "10.43.135.81"
          ],
          "answer": 0,
          "explain": "Bei /28 beträgt die Blockgröße 16. Hostadresse 94 liegt im Netz 10.43.135.80/28.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.18.0.130/26?",
          "options": [
            "172.18.0.191",
            "172.18.0.128",
            "172.18.0.190"
          ],
          "answer": 0,
          "explain": "Ein /26-Netz hat Blöcke zu 64 Adressen; die letzte Adresse des Netzblocks ist 172.18.0.191.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.19.13.98/27?",
          "options": [
            "172.19.13.127",
            "172.19.13.96",
            "172.19.13.126"
          ],
          "answer": 0,
          "explain": "Ein /27-Netz hat Blöcke zu 32 Adressen; die letzte Adresse des Netzblocks ist 172.19.13.127.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.20.26.66/28?",
          "options": [
            "172.20.26.79",
            "172.20.26.64",
            "172.20.26.78"
          ],
          "answer": 0,
          "explain": "Ein /28-Netz hat Blöcke zu 16 Adressen; die letzte Adresse des Netzblocks ist 172.20.26.79.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.21.39.42/29?",
          "options": [
            "172.21.39.47",
            "172.21.39.40",
            "172.21.39.46"
          ],
          "answer": 0,
          "explain": "Ein /29-Netz hat Blöcke zu 8 Adressen; die letzte Adresse des Netzblocks ist 172.21.39.47.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.22.52.130/26?",
          "options": [
            "172.22.52.191",
            "172.22.52.128",
            "172.22.52.190"
          ],
          "answer": 0,
          "explain": "Ein /26-Netz hat Blöcke zu 64 Adressen; die letzte Adresse des Netzblocks ist 172.22.52.191.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.23.65.226/27?",
          "options": [
            "172.23.65.255",
            "172.23.65.224",
            "172.23.65.254"
          ],
          "answer": 0,
          "explain": "Ein /27-Netz hat Blöcke zu 32 Adressen; die letzte Adresse des Netzblocks ist 172.23.65.255.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.24.78.130/28?",
          "options": [
            "172.24.78.143",
            "172.24.78.128",
            "172.24.78.142"
          ],
          "answer": 0,
          "explain": "Ein /28-Netz hat Blöcke zu 16 Adressen; die letzte Adresse des Netzblocks ist 172.24.78.143.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.25.91.74/29?",
          "options": [
            "172.25.91.79",
            "172.25.91.72",
            "172.25.91.78"
          ],
          "answer": 0,
          "explain": "Ein /29-Netz hat Blöcke zu 8 Adressen; die letzte Adresse des Netzblocks ist 172.25.91.79.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.26.104.130/26?",
          "options": [
            "172.26.104.191",
            "172.26.104.128",
            "172.26.104.190"
          ],
          "answer": 0,
          "explain": "Ein /26-Netz hat Blöcke zu 64 Adressen; die letzte Adresse des Netzblocks ist 172.26.104.191.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.27.117.98/27?",
          "options": [
            "172.27.117.127",
            "172.27.117.96",
            "172.27.117.126"
          ],
          "answer": 0,
          "explain": "Ein /27-Netz hat Blöcke zu 32 Adressen; die letzte Adresse des Netzblocks ist 172.27.117.127.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.28.130.194/28?",
          "options": [
            "172.28.130.207",
            "172.28.130.192",
            "172.28.130.206"
          ],
          "answer": 0,
          "explain": "Ein /28-Netz hat Blöcke zu 16 Adressen; die letzte Adresse des Netzblocks ist 172.28.130.207.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.29.143.106/29?",
          "options": [
            "172.29.143.111",
            "172.29.143.104",
            "172.29.143.110"
          ],
          "answer": 0,
          "explain": "Ein /29-Netz hat Blöcke zu 8 Adressen; die letzte Adresse des Netzblocks ist 172.29.143.111.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.30.156.130/26?",
          "options": [
            "172.30.156.191",
            "172.30.156.128",
            "172.30.156.190"
          ],
          "answer": 0,
          "explain": "Ein /26-Netz hat Blöcke zu 64 Adressen; die letzte Adresse des Netzblocks ist 172.30.156.191.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.31.169.226/27?",
          "options": [
            "172.31.169.255",
            "172.31.169.224",
            "172.31.169.254"
          ],
          "answer": 0,
          "explain": "Ein /27-Netz hat Blöcke zu 32 Adressen; die letzte Adresse des Netzblocks ist 172.31.169.255.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.32.182.2/28?",
          "options": [
            "172.32.182.15",
            "172.32.182.0",
            "172.32.182.14"
          ],
          "answer": 0,
          "explain": "Ein /28-Netz hat Blöcke zu 16 Adressen; die letzte Adresse des Netzblocks ist 172.32.182.15.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lautet die Broadcastadresse zu 172.33.195.138/29?",
          "options": [
            "172.33.195.143",
            "172.33.195.136",
            "172.33.195.142"
          ],
          "answer": 0,
          "explain": "Ein /29-Netz hat Blöcke zu 8 Adressen; die letzte Adresse des Netzblocks ist 172.33.195.143.",
          "operator": "Berechnen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "adressierung",
    "subgroup": "Adressierung"
  },
  {
    "id": "ipv6",
    "name": "IPv6 und Adressierung",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Wie breit ist eine IPv6-Adresse?",
          "options": [
            "32 Bit",
            "64 Bit",
            "128 Bit"
          ],
          "answer": 2,
          "explain": "IPv6 verwendet 128-Bit-Adressen.",
          "operator": "Nennen"
        },
        {
          "question": "Welches Zeichen trennt die Blöcke einer IPv6-Adresse?",
          "options": [
            "Doppelpunkt",
            "Punkt",
            "Schrägstrich allein"
          ],
          "answer": 0,
          "explain": "IPv6-Blöcke werden in Hexadezimalschreibweise mit Doppelpunkten getrennt.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Schreibweise kennzeichnet die lokale Loopback-Adresse bei IPv6?",
          "options": [
            "::1",
            "127.0.0.1",
            "fe80::/10 als Einzelhost"
          ],
          "answer": 0,
          "explain": "IPv6 verwendet ::1 als Loopback-Adresse.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Adresstyp dient bei IPv6 der Kommunikation innerhalb eines Links?",
          "options": [
            "Link-Local-Adresse",
            "Öffentliche IPv4-Adresse",
            "Multicast als alleinige Hostadresse"
          ],
          "answer": 0,
          "explain": "Link-Local liegt im Bereich fe80::/10.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Welche IPv6-Adressart beginnt typischerweise mit fe80::/10?",
          "options": [
            "Link-Local",
            "Global Unicast",
            "Multicast"
          ],
          "answer": 0,
          "explain": "Adressen im Bereich fe80::/10 sind Link-Local-Adressen.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher typische Präfix wird einem einzelnen IPv6-LAN zugewiesen?",
          "options": [
            "/64",
            "/128 als LAN-Netz",
            "/8"
          ],
          "answer": 0,
          "explain": "/64 ist für viele IPv6-LANs die übliche Präfixlänge.",
          "operator": "Nennen"
        },
        {
          "question": "Welche ICMPv6-Nachrichten helfen einem Host, Router zu finden?",
          "options": [
            "Router Solicitation und Router Advertisement",
            "DHCPDISCOVER und DHCPOFFER",
            "ARP Request und ARP Reply"
          ],
          "answer": 0,
          "explain": "Router Discovery erfolgt im Neighbor Discovery Protocol.",
          "operator": "Nennen"
        },
        {
          "question": "Was beschreibt SLAAC?",
          "options": [
            "Automatische IPv6-Adresskonfiguration anhand von Routerinformationen",
            "Eine RAID-Sicherungsstufe",
            "Ein TCP-Verschlüsselungsmodus"
          ],
          "answer": 0,
          "explain": "SLAAC nutzt insbesondere Router Advertisements und lokale Adressbildung.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Warum benötigt IPv6 im Normalfall kein ARP?",
          "options": [
            "Es nutzt Neighbor Discovery mit ICMPv6",
            "Es nutzt DNS für MAC-Adressen",
            "Es benötigt keine Layer-2-Auflösung"
          ],
          "answer": 0,
          "explain": "Neighbor Discovery Protocol (NDP) übernimmt unter anderem die Nachbarerkennung und Adressauflösung.",
          "operator": "Begründen"
        },
        {
          "question": "Was bedeutet ein IPv6-Präfix /56 gegenüber /64 für die Unterteilung in /64-LANs?",
          "options": [
            "Es umfasst 256 /64-Subnetze",
            "Es umfasst nur ein /64-Subnetz",
            "Es umfasst 16 /64-Subnetze"
          ],
          "answer": 0,
          "explain": "Die Differenz beträgt 8 Bit: 2⁸ = 256 Teilnetze.",
          "operator": "Nennen"
        },
        {
          "question": "Warum muss ICMPv6 im Netzwerk nicht pauschal vollständig blockiert werden?",
          "options": [
            "Wichtige IPv6-Funktionen wie Neighbor Discovery und PMTUD benötigen bestimmte ICMPv6-Typen",
            "IPv6 nutzt ICMPv6 ausschließlich für Ping",
            "IPv6 funktioniert ohne jede Routerinformation"
          ],
          "answer": 0,
          "explain": "Differenzierte ICMPv6-Regeln sind notwendig.",
          "operator": "Begründen"
        },
        {
          "question": "Welche Aussage ist korrekt, wenn bei IPv6 ein Host über fe80:: eine Standardroute nutzt?",
          "options": [
            "Link-Local-Adressen dürfen Next-Hop-Adressen im gleichen Link sein",
            "Link-Local wird uneingeschränkt weltweit geroutet",
            "IPv6 kennt keine Routen"
          ],
          "answer": 0,
          "explain": "Ein IPv6-Default-Gateway kann über seine Link-Local-Adresse identifiziert werden.",
          "operator": "Erläutern"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "adressierung",
    "subgroup": "Adressierung"
  },
  {
    "id": "switch",
    "name": "Switching, VLAN und STP",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Welche Aufgabe hat ein Access-Port?",
          "options": [
            "Er verbindet ein Endgerät mit einem VLAN",
            "Er routet zwischen IP-Netzen",
            "Er führt immer alle VLANs"
          ],
          "answer": 0,
          "explain": "Ein Access-Port transportiert üblicherweise Daten eines zugeordneten VLANs ungetaggt.",
          "operator": "Nennen"
        },
        {
          "question": "Womit entscheidet ein klassischer Switch meist über die Weiterleitung eines Frames?",
          "options": [
            "Ziel-MAC-Adresse",
            "Dateiname",
            "TCP-Anwendungsname"
          ],
          "answer": 0,
          "explain": "Ein Layer-2-Switch nutzt MAC-Adresstabellen.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein VLAN?",
          "options": [
            "Logische Unterteilung einer Layer-2-Broadcast-Domäne",
            "Eine spezielle Festplatte",
            "Ein DNS-Datensatz"
          ],
          "answer": 0,
          "explain": "VLANs trennen Broadcast-Domänen auf Layer 2.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Standard wird typischerweise für VLAN-Tagging eingesetzt?",
          "options": [
            "IEEE 802.1Q",
            "IEEE 802.11ax",
            "IEEE 802.3af"
          ],
          "answer": 0,
          "explain": "802.1Q versieht Ethernet-Frames mit VLAN-Tags.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was ist die typische Funktion eines Trunk-Ports?",
          "options": [
            "Er verschlüsselt IP-Pakete",
            "Er transportiert mehrere VLANs mittels Tags",
            "Er ersetzt einen Router"
          ],
          "answer": 1,
          "explain": "Trunks transportieren mehrere VLANs über eine physische Verbindung.",
          "operator": "Nennen"
        },
        {
          "question": "Wozu dient ein Trunk-Port zwischen zwei Switches?",
          "options": [
            "Übertragung mehrerer VLANs über eine Verbindung",
            "Automatisches Routing ohne Layer 3",
            "Nur ein einziges ungetaggtes VLAN"
          ],
          "answer": 0,
          "explain": "Trunks transportieren normalerweise getaggte VLAN-Verkehre.",
          "operator": "Nennen"
        },
        {
          "question": "Warum können zwei Hosts in verschiedenen VLANs nicht allein über einen Layer-2-Switch kommunizieren?",
          "options": [
            "Es wird ein Layer-3-Routingpfad benötigt",
            "Ein Access-Port routet automatisch",
            "VLAN-Tags sind identisch mit IP-Adressen"
          ],
          "answer": 0,
          "explain": "Inter-VLAN-Kommunikation benötigt Routing.",
          "operator": "Begründen"
        },
        {
          "question": "Was passiert bei einem Broadcast-Frame innerhalb eines VLANs?",
          "options": [
            "Er wird innerhalb der zugehörigen Broadcast-Domäne verteilt",
            "Er wird über alle IP-Router unbegrenzt verteilt",
            "Er wird immer nur an den Sender zurückgegeben"
          ],
          "answer": 0,
          "explain": "VLANs begrenzen den Layer-2-Broadcastbereich.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Welche Folge soll STP in einer redundanten Layer-2-Topologie verhindern?",
          "options": [
            "Routingtabellen-Updates",
            "Ethernet-Schleifen",
            "DNS-Zonenübertragungen"
          ],
          "answer": 1,
          "explain": "STP blockiert bei Bedarf redundante Pfade gegen Schleifen und kann bei Ausfall neu konvergieren.",
          "operator": "Erläutern"
        },
        {
          "question": "Warum kann ein redundanter Switch-Ring ohne Schleifenvermeidung das Netz lahmlegen?",
          "options": [
            "Broadcasts und unbekannte Unicasts können zirkulieren und Frames vervielfachen",
            "Switches besitzen grundsätzlich eine IPv6-Route für jedes Frame",
            "VLAN-Tagging verhindert jede Schleife automatisch"
          ],
          "answer": 0,
          "explain": "Ethernet besitzt im Frame selbst kein TTL-Feld wie IP.",
          "operator": "Begründen"
        },
        {
          "question": "Was geschieht typischerweise, wenn ein durch STP blockierter Ersatzpfad nach Leitungsdefekt benötigt wird?",
          "options": [
            "STP kann die Topologie neu berechnen und den Ersatzpfad freigeben",
            "STP repariert das physische Kabel",
            "Alle VLANs werden sofort gelöscht"
          ],
          "answer": 0,
          "explain": "STP/RSTP kann nach Konvergenz alternative Layer-2-Pfade aktivieren.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Access-Port ist VLAN 20 zugewiesen, der Host hat jedoch eine IP aus VLAN 10. Was ist wahrscheinlich?",
          "options": [
            "Der Host kann viele Ziele im erwarteten Netz nicht korrekt erreichen",
            "Der Port erkennt IP-Subnetze und ändert automatisch sein VLAN",
            "IP-Konfiguration und VLAN sind grundsätzlich unabhängig in ihrer Erreichbarkeit"
          ],
          "answer": 0,
          "explain": "Die L2-Zuordnung und die L3-Adressierung müssen zum Netzkonzept passen.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "switching",
    "subgroup": "Switching und VLAN"
  },
  {
    "id": "routing",
    "name": "Routing, NAT und Gateways",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Was verbindet ein Router?",
          "options": [
            "Unterschiedliche IP-Netze",
            "Nur zwei identische Ports",
            "Ausschließlich Benutzerkonten"
          ],
          "answer": 0,
          "explain": "Router leiten IP-Pakete zwischen verschiedenen Netzen weiter.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür steht NAT?",
          "options": [
            "Network Address Translation",
            "Network Access Token",
            "Node Automatic Time"
          ],
          "answer": 0,
          "explain": "NAT setzt IP-Adressinformationen zwischen Netzbereichen um.",
          "operator": "Nennen"
        },
        {
          "question": "Welches Gerät besitzt üblicherweise die Standardgateway-Adresse eines Clients?",
          "options": [
            "Router oder Layer-3-Schnittstelle",
            "Drucker ohne Routing",
            "USB-Hub"
          ],
          "answer": 0,
          "explain": "Das Standardgateway übernimmt Weiterleitung in entfernte IP-Netze.",
          "operator": "Nennen"
        },
        {
          "question": "Was beschreibt eine statische Route?",
          "options": [
            "Manuell festgelegter Routingtabelleneintrag",
            "Automatische DNS-Zonenänderung",
            "Physischer Switch-Portmodus"
          ],
          "answer": 0,
          "explain": "Statische Routen werden administrativ konfiguriert.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Welche Funktion übernimmt das Standardgateway eines Hosts?",
          "options": [
            "Weiterleitung zu fremden IP-Netzen",
            "Vergabe der MAC-Adresse",
            "Sicherung von Dateien"
          ],
          "answer": 0,
          "explain": "Ziele außerhalb des lokalen Subnetzes erreicht der Host üblicherweise über sein Standardgateway.",
          "operator": "Nennen"
        },
        {
          "question": "Wie wählt ein Router bei mehreren passenden Routen die spezifischste Zielroute?",
          "options": [
            "Longest Prefix Match",
            "Kleinste DNS-TTL",
            "Größtes VLAN zuerst"
          ],
          "answer": 0,
          "explain": "Der längste passende Netzpräfix gewinnt im Routing-Lookup.",
          "operator": "Nennen"
        },
        {
          "question": "Was bewirkt PAT beim Internetzugang mehrerer Clients?",
          "options": [
            "Übersetzung der Adressen und Transportports für gemeinsame öffentliche IPv4-Nutzung",
            "Erzeugung mehrerer physischer WAN-Kabel",
            "Ersetzen von DNS-Zonen"
          ],
          "answer": 0,
          "explain": "PAT unterscheidet Verbindungen über Portabbildungen.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Eintrag steht üblicherweise für die IPv4-Default-Route?",
          "options": [
            "0.0.0.0/0",
            "127.0.0.1/32",
            "255.255.255.255/32"
          ],
          "answer": 0,
          "explain": "/0 passt zu jedem IPv4-Ziel, wenn keine spezifischere Route vorhanden ist.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Ein interner Client mit privater IPv4-Adresse ruft eine externe Webseite auf. Was ermöglicht häufig die Adressübersetzung?",
          "options": [
            "PAT/NAT am Übergang",
            "STP am Access-Port",
            "RAID 1 auf dem Server"
          ],
          "answer": 0,
          "explain": "NAT bzw. PAT kann private Quelladressen und Ports für die Internetkommunikation übersetzen.",
          "operator": "Nennen"
        },
        {
          "question": "Router kennt 10.0.0.0/8 und 10.20.30.0/24. Welche Route nutzt er für 10.20.30.7?",
          "options": [
            "10.20.30.0/24",
            "10.0.0.0/8",
            "Default-Route trotz passender Netze"
          ],
          "answer": 0,
          "explain": "Longest Prefix Match bevorzugt /24 gegenüber /8.",
          "operator": "Nennen"
        },
        {
          "question": "Warum muss beim Inter-VLAN-Routing eine Firewallregel trotz funktionierender Routingtabelle Verbindungen verhindern können?",
          "options": [
            "Routing ermöglicht den Pfad, Sicherheitsregeln autorisieren die Kommunikation",
            "Routing ersetzt automatisch jede ACL",
            "VLAN-Trunks verschlüsseln die Pakete"
          ],
          "answer": 0,
          "explain": "Erreichbarkeit und Zugriffskontrolle sind unterschiedliche Ebenen.",
          "operator": "Begründen"
        },
        {
          "question": "Ein Router hat keine passende Route und keine Default-Route. Welche Folge ist zu erwarten?",
          "options": [
            "Das Paket wird verworfen; je nach Konfiguration kann eine ICMP-Fehlermeldung entstehen",
            "Das Paket wird automatisch per DNS weitergeleitet",
            "Es wird als Broadcast über jedes VLAN gesendet"
          ],
          "answer": 0,
          "explain": "Ohne Route kann keine korrekte Weiterleitung erfolgen.",
          "operator": "Erläutern"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "routing-wan",
    "subgroup": "Routing und WAN"
  },
  {
    "id": "dnsdhcp",
    "name": "DNS und DHCP",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Welcher Dienst löst Hostnamen in IP-Adressen auf?",
          "options": [
            "DNS",
            "DHCP",
            "STP"
          ],
          "answer": 0,
          "explain": "DNS ist der Dienst für die Namensauflösung.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher DNS-Eintrag enthält typischerweise eine IPv4-Adresse?",
          "options": [
            "A-Record",
            "MX-Record",
            "PTR-Record"
          ],
          "answer": 0,
          "explain": "Ein A-Record weist einem Namen eine IPv4-Adresse zu.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Dienst verteilt IP-Konfigurationsdaten dynamisch?",
          "options": [
            "DHCP",
            "NTP",
            "SMTP"
          ],
          "answer": 0,
          "explain": "DHCP kann IPv4-Adresse, Subnetzmaske, Gateway und DNS-Server liefern.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür steht TTL bei DNS?",
          "options": [
            "Time to Live",
            "Transport Type Link",
            "Total Transfer Length"
          ],
          "answer": 0,
          "explain": "TTL steuert, wie lange ein DNS-Ergebnis zwischengespeichert werden darf.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Welche Informationen liefert DHCP typischerweise an Clients?",
          "options": [
            "IP-Adresse, Netzmaske, Gateway und DNS",
            "Nur die CPU-Temperatur",
            "Ausschließlich Kennwörter"
          ],
          "answer": 0,
          "explain": "DHCP kann IP-Konfiguration einschließlich Router- und DNS-Optionen zuweisen.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist die Standardreihenfolge von DHCPv4-DORA?",
          "options": [
            "Discover, Offer, Request, Acknowledge",
            "Discover, Reply, Route, Accept",
            "DNS, Offer, Relay, ACK"
          ],
          "answer": 0,
          "explain": "DORA beschreibt den üblichen vierstufigen DHCPv4-Austausch.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür dient ein MX-Record?",
          "options": [
            "Mailserver für eine Domain angeben",
            "IPv6-Adresse eines Hosts speichern",
            "Switch-Uplinks routen"
          ],
          "answer": 0,
          "explain": "MX weist auf Mail-Exchanger einer DNS-Domäne.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür wird ein DHCP-Relay benötigt?",
          "options": [
            "DHCP-Anfragen über Routergrenzen an einen DHCP-Server weiterleiten",
            "RAID 1 spiegeln",
            "STP vollständig ersetzen"
          ],
          "answer": 0,
          "explain": "Broadcastanfragen erreichen einen DHCP-Server in anderem Netz nicht ohne Relay-Funktion.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Eine DNS-Abfrage liefert NXDOMAIN. Was bedeutet dies?",
          "options": [
            "Der angefragte Name existiert im DNS nicht",
            "Der DNS-Server ist zwingend offline",
            "Der IP-Port ist gesperrt"
          ],
          "answer": 0,
          "explain": "NXDOMAIN ist die negative Antwort für einen nicht existierenden DNS-Namen; sie beweist keinen generellen Ausfall des DNS-Diensts.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Host kann 8.8.8.8 pingen, aber keinen Namen auflösen. Was prüfst du zuerst?",
          "options": [
            "Konfigurierten DNS-Server und dessen Antwortverhalten",
            "Zwingend ein defektes Netzwerkkabel",
            "Nur die lokale RAID-Parität"
          ],
          "answer": 0,
          "explain": "IP-Routing funktioniert bereits teilweise, DNS ist separat zu prüfen.",
          "operator": "Nennen"
        },
        {
          "question": "Ein DNS-A-Record wurde geändert, Clients nutzen noch alte IPs. Was ist eine plausible Ursache?",
          "options": [
            "Zwischengespeicherte Antworten bis zum Ablauf ihrer TTL",
            "STP blockiert alle Switches weltweit",
            "DHCP erzeugt automatisch neue TLS-Zertifikate"
          ],
          "answer": 0,
          "explain": "Caching kann die Sichtbarkeit aktualisierter Records verzögern.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Client erhält DHCP-Adresse 169.254.x.x statt der geplanten privaten Adresse. Was deutet dies an?",
          "options": [
            "Automatische IPv4-Link-Local-Adresse nach ausgebliebener DHCP-Zuweisung",
            "Gültige öffentliche IP des Providers",
            "Automatisch funktionierendes VPN"
          ],
          "answer": 0,
          "explain": "APIPA kann einspringen, wenn keine gültige DHCP-Konfiguration erhalten wird.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "netzdienste",
    "subgroup": "Netzdienste"
  },
  {
    "id": "firewall",
    "name": "Firewall, DMZ und ACL",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Was bewirkt eine Firewallregel?",
          "options": [
            "Sie steuert erlaubten Netzwerkverkehr",
            "Sie repariert Festplatten",
            "Sie erzeugt VLAN-Tags automatisch"
          ],
          "answer": 0,
          "explain": "Firewallregeln erlauben oder verweigern Verkehr anhand definierter Kriterien.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Information gehört üblicherweise zu einer Firewallregel?",
          "options": [
            "Quelladresse, Zieladresse, Protokoll und Port",
            "Festplattenseriennummer",
            "Bildschirmauflösung"
          ],
          "answer": 0,
          "explain": "Paketfilterregeln berücksichtigen mehrere Verbindungsmerkmale.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet DMZ in einem IT-Netz?",
          "options": [
            "Separates Netzsegment für kontrolliert erreichbare Dienste",
            "Immer ein Teil des internen Clientnetzes",
            "Ein RAID-Level"
          ],
          "answer": 0,
          "explain": "Eine DMZ isoliert Dienste vom internen LAN.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist eine ACL im Netzwerkkontext?",
          "options": [
            "Access Control List",
            "Automatic Cable Link",
            "Address Copy Layer"
          ],
          "answer": 0,
          "explain": "ACLs beschreiben Regeln zum Erlauben oder Verwerfen von Verkehr.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was beschreibt eine DMZ im Netzdesign?",
          "options": [
            "Ein separates Netzsegment für bestimmte exponierte Dienste",
            "Ein Passwortspeicher",
            "Eine RAID-Stufe"
          ],
          "answer": 0,
          "explain": "Eine DMZ ist ein getrenntes Segment mit kontrollierten Kommunikationspfaden.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Regel erlaubt externen HTTPS-Zugriff auf einen DMZ-Webserver?",
          "options": [
            "Internet zu DMZ-Webserver, TCP 443 erlauben",
            "Internet zu jedem LAN-Host, alle Ports erlauben",
            "DMZ zu allen internen Datenbanken ohne Filter erlauben"
          ],
          "answer": 0,
          "explain": "Die Regel wird auf notwendigen Dienst und Ziel begrenzt.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet „Default Deny“?",
          "options": [
            "Nicht ausdrücklich erlaubter Verkehr wird blockiert",
            "Alles wird grundsätzlich freigegeben",
            "DNS wird immer gelöscht"
          ],
          "answer": 0,
          "explain": "Default Deny reduziert unbeabsichtigte Freigaben.",
          "operator": "Nennen"
        },
        {
          "question": "Warum wird häufig eine zustandsorientierte Firewall verwendet?",
          "options": [
            "Sie berücksichtigt Verbindungszustände und Rückverkehr",
            "Sie ersetzt alle Routingtabellen",
            "Sie entschlüsselt zwingend jedes Paket"
          ],
          "answer": 0,
          "explain": "Stateful Firewalls verfolgen zulässige Verbindungen.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Welche Regel öffnet HTTPS aus dem Internet zur DMZ möglichst eng?",
          "options": [
            "Quelle Internet, Ziel Webserver, TCP 443",
            "Quelle alle, Ziel LAN, alle Ports",
            "Quelle DMZ, Ziel alle, UDP 53"
          ],
          "answer": 0,
          "explain": "Eine Freigabe wird nach konkreter Quelle, Zieladresse, Protokoll und Port eingeschränkt.",
          "operator": "Nennen"
        },
        {
          "question": "Regel 1 verweigert TCP 443 zur DMZ; Regel 2 erlaubt TCP 443. Was geschieht bei First-Match-Auswertung?",
          "options": [
            "Die erste passende Verweigerung greift",
            "Die zweite Freigabe setzt Regel 1 immer außer Kraft",
            "Beide Regeln werden addiert und ergeben TCP 886"
          ],
          "answer": 0,
          "explain": "Bei First Match bestimmt die erste passende Regel das Ergebnis.",
          "operator": "Nennen"
        },
        {
          "question": "Ein DMZ-Webserver darf intern auf Datenbankport 5432 zugreifen. Welche Freigabe folgt Least Privilege?",
          "options": [
            "Quelle Webserver, Ziel Datenbank, TCP 5432",
            "Quelle Internet, Ziel internes LAN, alle Ports",
            "Quelle gesamte DMZ, Ziel gesamtes LAN, alle Protokolle"
          ],
          "answer": 0,
          "explain": "Die Ausnahme wird auf Server, Ziel und Dienst begrenzt.",
          "operator": "Nennen"
        },
        {
          "question": "Warum darf eine DMZ nicht automatisch als vertrauenswürdiges internes Netz behandelt werden?",
          "options": [
            "Extern erreichbare Dienste besitzen erhöhte Angriffsfläche",
            "DMZ bedeutet volle Administratorrechte",
            "Segmentierung verhindert jeden Angriff"
          ],
          "answer": 0,
          "explain": "Kommunikation von DMZ zu LAN braucht gesonderte Berechtigung.",
          "operator": "Begründen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "netzschutz",
    "subgroup": "Netzsicherheit"
  },
  {
    "id": "wlan",
    "name": "WLAN und Funknetze",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Welcher Standard bezeichnet ein Funknetzwerk in der Regel?",
          "options": [
            "IEEE 802.11",
            "IEEE 802.3",
            "SATA"
          ],
          "answer": 0,
          "explain": "IEEE 802.11 umfasst WLAN-Technologien.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Frequenzbereiche sind bei WLAN häufig?",
          "options": [
            "2,4 GHz und 5 GHz",
            "50 Hz und 60 Hz",
            "12 V und 24 V"
          ],
          "answer": 0,
          "explain": "Viele WLAN-Standards nutzen 2,4 oder 5 GHz; neuere auch 6 GHz.",
          "operator": "Nennen"
        },
        {
          "question": "Wozu dient ein Access Point?",
          "options": [
            "Funkclients mit einem Netzwerk verbinden",
            "Festplatten spiegeln",
            "DNS-Namen in MACs umwandeln"
          ],
          "answer": 0,
          "explain": "Ein AP stellt WLAN-Zugang zum Netzwerk bereit.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein WLAN-Kanal?",
          "options": [
            "Frequenzbereich für die Funkübertragung",
            "Eine RAID-Gruppe",
            "Ein TCP-Dienstport"
          ],
          "answer": 0,
          "explain": "WLANs arbeiten auf festgelegten Funkkanälen.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Warum kann die Kanalwahl in einem WLAN wichtig sein?",
          "options": [
            "Benachbarte Funknetze können sich stören",
            "Sie verändert die IPv4-Bitlänge",
            "Sie ersetzt die Benutzeranmeldung"
          ],
          "answer": 0,
          "explain": "Überlappende Kanäle und Störungen beeinflussen den Funkdurchsatz und die Verbindungsqualität.",
          "operator": "Begründen"
        },
        {
          "question": "Warum kann überlappende Kanalbelegung das WLAN verschlechtern?",
          "options": [
            "Störungen und Airtime-Konkurrenz können zunehmen",
            "Alle Access Points verdoppeln automatisch den Durchsatz",
            "Jeder Kanal ist vollständig unabhängig"
          ],
          "answer": 0,
          "explain": "Kanalplanung berücksichtigt Nachbarzellen und Störungen.",
          "operator": "Begründen"
        },
        {
          "question": "Was ist ein Vorteil von 5 GHz gegenüber 2,4 GHz?",
          "options": [
            "Häufig mehr verfügbare nicht überlappende Kanäle",
            "Immer größere Reichweite durch Beton",
            "Automatisch keine Störungen"
          ],
          "answer": 0,
          "explain": "5 GHz bietet häufig mehr Kanaloptionen, Reichweite variiert.",
          "operator": "Nennen"
        },
        {
          "question": "Warum sollte ein WLAN-Site-Survey durchgeführt werden?",
          "options": [
            "Abdeckung, Störquellen und Kapazität beurteilen",
            "DNS automatisch löschen",
            "Server-RAID ersetzen"
          ],
          "answer": 0,
          "explain": "Messungen unterstützen die AP-Positionierung und Kanalplanung.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Welche Aussage zur 5-GHz-Nutzung gegenüber 2,4 GHz ist typischerweise korrekt?",
          "options": [
            "Oft mehr freie Kanäle, aber kürzere Reichweite durch Hindernisse",
            "Garantiert größere Reichweite durch Beton",
            "Identische Kanalplanung unabhängig von der Umgebung"
          ],
          "answer": 0,
          "explain": "5 GHz kann mehr nutzbare Kanäle bieten, wird durch Hindernisse jedoch häufig stärker gedämpft.",
          "operator": "Erläutern"
        },
        {
          "question": "Ein AP wird mit 80 MHz Kanalbreite statt 20 MHz betrieben. Welche Aussage ist korrekt?",
          "options": [
            "Mehr theoretischer Durchsatz, aber größerer Kanal- und Störbedarf",
            "Immer viermal größere Reichweite",
            "Keine Auswirkungen auf Kanalplanung"
          ],
          "answer": 0,
          "explain": "Breite Kanäle benötigen mehr Spektrum und können die Koexistenz erschweren.",
          "operator": "Erläutern"
        },
        {
          "question": "Warum ist 2,4 GHz in einer dichten WLAN-Umgebung häufig anfällig?",
          "options": [
            "Wenige überlappungsarme Kanäle und zahlreiche andere Funkquellen",
            "Es gibt unbegrenzt viele getrennte Kanäle",
            "Es ist grundsätzlich verschlüsselt"
          ],
          "answer": 0,
          "explain": "Kanalüberlagerung und Fremdgeräte beeinträchtigen Airtime.",
          "operator": "Begründen"
        },
        {
          "question": "Eine WLAN-Funkzelle hat gute Signalstärke, aber schlechten Durchsatz. Welche Ursache ist plausibel?",
          "options": [
            "Interferenz, viele Clients oder langsame Airtime-Nutzer",
            "Signalstärke garantiert den maximalen Durchsatz",
            "DNS-Caching erhöht zwingend Funkrate"
          ],
          "answer": 0,
          "explain": "Funkqualität umfasst mehr als den Empfangspegel.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "medien",
    "subgroup": "Medien und WLAN"
  },
  {
    "id": "diagnose",
    "name": "Netzdiagnose und Ports",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Mit welchem Werkzeug prüfst du die DNS-Auflösung?",
          "options": [
            "nslookup",
            "format",
            "chkdsk"
          ],
          "answer": 0,
          "explain": "nslookup fragt DNS-Einträge ab.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Port wird üblicherweise von DNS verwendet?",
          "options": [
            "53",
            "80",
            "3389"
          ],
          "answer": 0,
          "explain": "DNS nutzt typischerweise UDP oder TCP 53.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Funktion hat der Befehl ping?",
          "options": [
            "Er prüft Erreichbarkeit mit ICMP Echo",
            "Er erstellt Benutzerkonten",
            "Er ändert die VLAN-ID"
          ],
          "answer": 0,
          "explain": "Ping prüft ICMP-Erreichbarkeit, nicht automatisch Anwendungserreichbarkeit.",
          "operator": "Nennen"
        },
        {
          "question": "Mit welchem Befehl lässt sich unter Windows die IP-Konfiguration anzeigen?",
          "options": [
            "ipconfig",
            "chmod",
            "SELECT"
          ],
          "answer": 0,
          "explain": "ipconfig zeigt unter Windows Netzwerkkonfigurationen.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Ein Host lässt sich per IP anpingen, nicht aber per Hostnamen. Was prüfst du zuerst?",
          "options": [
            "DNS-Konfiguration",
            "RAID-Stufe",
            "Bildschirmkabel"
          ],
          "answer": 0,
          "explain": "Wenn IP-Verbindungen funktionieren, ist die Namensauflösung ein sinnvoller erster Diagnosepunkt.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür verwendet man traceroute beziehungsweise tracert?",
          "options": [
            "Um die Hop-Folge bis zu einem Ziel zu untersuchen",
            "Für Backups von Datenbanken",
            "Um RAID-Spiegel zu erstellen"
          ],
          "answer": 0,
          "explain": "Traceroute nutzt zeitlich begrenzte Pakete zur Pfadanalyse.",
          "operator": "Nennen"
        },
        {
          "question": "Was zeigt ein erfolgreicher nslookup auf einen DNS-Server?",
          "options": [
            "Eine DNS-Antwort des abgefragten Servers",
            "Eine zwingend gültige TLS-Verbindung",
            "Eine erfolgreich geöffnete SMB-Freigabe"
          ],
          "answer": 0,
          "explain": "DNS-Antworten belegen nicht automatisch die Erreichbarkeit der Anwendung.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Dienst verwendet standardmäßig TCP 22?",
          "options": [
            "SSH",
            "HTTP",
            "DNS über UDP"
          ],
          "answer": 0,
          "explain": "SSH läuft im Standard auf TCP 22.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet HTTP üblicherweise?",
          "options": [
            "TCP 80",
            "TCP 443",
            "TCP 25"
          ],
          "answer": 0,
          "explain": "Für HTTP wird standardmäßig TCP 80 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet HTTPS üblicherweise?",
          "options": [
            "TCP 443",
            "TCP 80",
            "UDP 161"
          ],
          "answer": 0,
          "explain": "Für HTTPS wird standardmäßig TCP 443 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet SSH üblicherweise?",
          "options": [
            "TCP 22",
            "TCP 23",
            "TCP 21"
          ],
          "answer": 0,
          "explain": "Für SSH wird standardmäßig TCP 22 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet DNS üblicherweise?",
          "options": [
            "UDP/TCP 53",
            "TCP 3389",
            "UDP 123"
          ],
          "answer": 0,
          "explain": "Für DNS wird standardmäßig UDP/TCP 53 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet DHCPv4-Server üblicherweise?",
          "options": [
            "UDP 67",
            "UDP 68",
            "TCP 53"
          ],
          "answer": 0,
          "explain": "Für DHCPv4-Server wird standardmäßig UDP 67 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet DHCPv4-Client üblicherweise?",
          "options": [
            "UDP 68",
            "UDP 67",
            "TCP 25"
          ],
          "answer": 0,
          "explain": "Für DHCPv4-Client wird standardmäßig UDP 68 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet SMTP-Servertransport üblicherweise?",
          "options": [
            "TCP 25",
            "TCP 110",
            "TCP 995"
          ],
          "answer": 0,
          "explain": "Für SMTP-Servertransport wird standardmäßig TCP 25 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet SMTP-Submission üblicherweise?",
          "options": [
            "TCP 587",
            "TCP 143",
            "UDP 161"
          ],
          "answer": 0,
          "explain": "Für SMTP-Submission wird standardmäßig TCP 587 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet IMAP über TLS üblicherweise?",
          "options": [
            "TCP 993",
            "TCP 995",
            "TCP 143"
          ],
          "answer": 0,
          "explain": "Für IMAP über TLS wird standardmäßig TCP 993 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet POP3 über TLS üblicherweise?",
          "options": [
            "TCP 995",
            "TCP 993",
            "TCP 110"
          ],
          "answer": 0,
          "explain": "Für POP3 über TLS wird standardmäßig TCP 995 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet SMB üblicherweise?",
          "options": [
            "TCP 445",
            "TCP 389",
            "TCP 3389"
          ],
          "answer": 0,
          "explain": "Für SMB wird standardmäßig TCP 445 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet RDP üblicherweise?",
          "options": [
            "TCP 3389",
            "TCP 1433",
            "TCP 22"
          ],
          "answer": 0,
          "explain": "Für RDP wird standardmäßig TCP 3389 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet NTP üblicherweise?",
          "options": [
            "UDP 123",
            "UDP 161",
            "TCP 8080"
          ],
          "answer": 0,
          "explain": "Für NTP wird standardmäßig UDP 123 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Standardport verwendet SNMP-Abfragen üblicherweise?",
          "options": [
            "UDP 161",
            "UDP 162",
            "UDP 123"
          ],
          "answer": 0,
          "explain": "Für SNMP-Abfragen wird standardmäßig UDP 161 genutzt; in der Praxis können Dienste andere Ports verwenden.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Ein TCP-SYN an Port 443 erhält SYN-ACK. Was lässt sich daraus ableiten?",
          "options": [
            "Ein TCP-Dienst ist erreichbar und akzeptiert den Verbindungsaufbau",
            "Das TLS-Zertifikat ist gültig",
            "Der Server ist gegen Angriffe immun"
          ],
          "answer": 0,
          "explain": "SYN-ACK zeigt TCP-Erreichbarkeit; TLS-Vertrauen und Anwendungssicherheit sind getrennte Fragen.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Client kann das Gateway pingen, aber keine fremden Netze. Was prüfst du als nächstes?",
          "options": [
            "Default-Route und Weiterleitung/Firewall am Gateway",
            "Nur die Farbe des Patchkabels",
            "Zwingend die SMB-Sitzung"
          ],
          "answer": 0,
          "explain": "Lokale Konnektivität schließt Routingfehler nicht aus.",
          "operator": "Nennen"
        },
        {
          "question": "TCP 443 ist offen, die HTTPS-Verbindung warnt vor dem Zertifikat. Was muss gesondert geprüft werden?",
          "options": [
            "Zertifikatskette, Name und Gültigkeit",
            "Nur die TCP-Portnummer",
            "VLAN-PVID allein"
          ],
          "answer": 0,
          "explain": "Transporterreichbarkeit ist unabhängig vom TLS-Vertrauen.",
          "operator": "Nennen"
        },
        {
          "question": "Ein DNS-Server beantwortet A-Records intern, externe Domains aber nicht. Welche Ursache ist plausibel?",
          "options": [
            "Fehlende oder gestörte Weiterleitung beziehungsweise rekursive Auflösung",
            "Defekte Switchport-LED beweist es",
            "Jede interne DNS-Zone ist fehlerhaft"
          ],
          "answer": 0,
          "explain": "Interne Namensauflösung und externe Rekursion sind getrennte Funktionen.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "analyse",
    "subgroup": "Diagnose und Leistung"
  },
  {
    "id": "linux",
    "name": "Linux, Bash und Berechtigungen",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Welcher Linux-Befehl zeigt Dateien in einem Verzeichnis an?",
          "options": [
            "ls",
            "cd",
            "pwd"
          ],
          "answer": 0,
          "explain": "ls listet Verzeichniseinträge.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Befehl zeigt das aktuelle Verzeichnis an?",
          "options": [
            "pwd",
            "mkdir",
            "cat"
          ],
          "answer": 0,
          "explain": "pwd gibt den aktuellen Arbeitsverzeichnispfad aus.",
          "operator": "Nennen"
        },
        {
          "question": "Mit welchem Befehl wechselst du das Verzeichnis?",
          "options": [
            "cd",
            "ls",
            "grep"
          ],
          "answer": 0,
          "explain": "cd ändert die aktuelle Shell-Arbeitsposition.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Befehl ändert Dateiberechtigungen unter Linux?",
          "options": [
            "chmod",
            "ping",
            "ipconfig"
          ],
          "answer": 0,
          "explain": "chmod ändert die Modusbits einer Datei.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Welche Bedeutung hat chmod 640 für eine Datei?",
          "options": [
            "Besitzer rw, Gruppe r, andere keine Rechte",
            "Alle dürfen schreiben",
            "Nur die Gruppe darf ausführen"
          ],
          "answer": 0,
          "explain": "6 = Lesen+Schreiben, 4 = Lesen, 0 = keine Rechte.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Befehl sucht in einer Datei nach einer Zeichenfolge?",
          "options": [
            "grep",
            "rm",
            "touch"
          ],
          "answer": 0,
          "explain": "grep filtert Zeilen anhand von Mustern.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet `chmod 640 datei`?",
          "options": [
            "Eigentümer lesen/schreiben, Gruppe lesen, andere keine Rechte",
            "Jeder darf alles",
            "Eigentümer nur ausführen"
          ],
          "answer": 0,
          "explain": "6=rw-, 4=r--, 0=---.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet `$?` in Bash?",
          "options": [
            "Exitstatus des zuletzt ausgeführten Befehls",
            "Aktuelle IP-Adresse",
            "PID aller Prozesse"
          ],
          "answer": 0,
          "explain": "Der zuletzt ausgeführte Befehl liefert seinen Rückgabestatus in $?.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "In Bash steht `test -f /tmp/x && echo ok`. Wann läuft echo?",
          "options": [
            "Wenn test den Status 0 liefert",
            "Immer, auch bei Fehler",
            "Nur wenn test fehlschlägt"
          ],
          "answer": 0,
          "explain": "Der Operator && führt den folgenden Befehl nur bei erfolgreichem Vorgänger aus.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Folge hat `cp -a /quelle/. /ziel/` in Linux typischerweise?",
          "options": [
            "Es kopiert den Inhalt inklusive versteckter Dateien mit Attributerhalt, soweit möglich",
            "Es kopiert nur Dateinamen ohne Inhalt",
            "Es löscht grundsätzlich das Quellverzeichnis"
          ],
          "answer": 0,
          "explain": "cp -a ist der Archivmodus; /quelle/. adressiert den Verzeichnisinhalt.",
          "operator": "Erläutern"
        },
        {
          "question": "Was bewirkt `find /var/log -type f -mtime +7`?",
          "options": [
            "Es sucht reguläre Dateien, deren Änderungszeit mehr als ungefähr sieben Tage zurückliegt",
            "Es zeigt nur Verzeichnisse von heute",
            "Es sortiert die Datei nach Uhrzeit"
          ],
          "answer": 0,
          "explain": "-type f filtert Dateien; -mtime +7 verwendet ganze 24-h-Zeitintervalle.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Bash-Skript enthält `set -e`. Welche Aussage ist korrekt?",
          "options": [
            "Viele fehlgeschlagene Befehle können das Skript beenden, jedoch gibt es Ausnahmen",
            "Jeder Fehler wird automatisch rückgängig gemacht",
            "Alle Variablen sind damit sicher gesetzt"
          ],
          "answer": 0,
          "explain": "set -e beeinflusst die Fehlerbehandlung, garantiert aber keine vollständige Transaktionssicherheit.",
          "operator": "Erläutern"
        }
      ]
    },
    "packId": "admin",
    "subgroupId": "os",
    "subgroup": "Betriebssysteme"
  },
  {
    "id": "windows",
    "name": "Windows, AD und Gruppenrichtlinien",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Wofür werden Gruppenrichtlinien (GPO) typischerweise genutzt?",
          "options": [
            "Zentrale Konfiguration von Windows-Umgebungen",
            "Einbau neuer RAM-Module",
            "Berechnung von IPv6-Adressen"
          ],
          "answer": 0,
          "explain": "GPOs verteilen zentral Windows-Einstellungen in passenden AD-Umgebungen.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Dienst ist in AD-Domänen für Benutzerauthentifizierung wichtig?",
          "options": [
            "Active Directory Domain Services",
            "DHCP allein",
            "STP"
          ],
          "answer": 0,
          "explain": "AD DS bietet zentrale Verzeichnis- und Authentifizierungsfunktionen.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist eine OU in Active Directory?",
          "options": [
            "Organisationseinheit",
            "Optische Übertragungseinheit",
            "Offline Update"
          ],
          "answer": 0,
          "explain": "OUs strukturieren AD-Objekte und ermöglichen GPO-Verknüpfungen.",
          "operator": "Nennen"
        },
        {
          "question": "Wie heißt die eingebaute Windows-Aufgabenplanung?",
          "options": [
            "Task Scheduler / Aufgabenplanung",
            "Eventual Mail Transfer",
            "Netstat"
          ],
          "answer": 0,
          "explain": "Aufgabenplanung kann Programme zeit- oder ereignisgesteuert ausführen.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Welche Aufgabe übernimmt Active Directory Domain Services?",
          "options": [
            "Verwaltung von Identitäten und Zugriffsrechten",
            "Nur DNS-Namensauflösung",
            "Festplattenspiegelung"
          ],
          "answer": 0,
          "explain": "AD DS ist ein Verzeichnisdienst für Identitäten, Gruppen und Anmeldung.",
          "operator": "Nennen"
        },
        {
          "question": "Wozu wird `gpupdate /force` verwendet?",
          "options": [
            "Gruppenrichtlinien auf einem Windows-Client erneut verarbeiten",
            "RAID neu formatieren",
            "DNS-Server löschen"
          ],
          "answer": 0,
          "explain": "gpupdate veranlasst Richtlinienaktualisierung.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Windows-Funktion zeichnet System- und Anwendungsereignisse auf?",
          "options": [
            "Ereignisanzeige / Event Viewer",
            "Datenträgerbereinigung allein",
            "Paint"
          ],
          "answer": 0,
          "explain": "Die Ereignisanzeige zeigt Logs aus verschiedenen Windows-Quellen.",
          "operator": "Nennen"
        },
        {
          "question": "Warum gehört DNS zu einer funktionsfähigen Active-Directory-Umgebung?",
          "options": [
            "Domänendienste veröffentlichen und finden wichtige Dienste über DNS",
            "AD ersetzt DNS für jede Kommunikation",
            "DNS wird nur für Internetbrowser gebraucht"
          ],
          "answer": 0,
          "explain": "AD verwendet unter anderem SRV-Records für Diensterkennung.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein Benutzer erhält trotz passender Gruppenmitgliedschaft keinen Zugriff auf eine NTFS-Datei über eine Freigabe. Was prüfst du?",
          "options": [
            "Freigabeberechtigungen und NTFS-Berechtigungen",
            "Ausschließlich die Bildschirmauflösung",
            "Nur den DNS-TTL-Wert"
          ],
          "answer": 0,
          "explain": "Bei SMB greifen Freigabe- und Dateisystemberechtigungen zusammen; die wirksame Berechtigung kann dadurch eingeschränkt sein.",
          "operator": "Nennen"
        },
        {
          "question": "Ein GPO gilt nicht für einen Windows-Client. Welche Prüfung ist zielgerichtet?",
          "options": [
            "gpresult, Verknüpfungen, Filterung und Replikation prüfen",
            "Sofort alle Benutzerkonten löschen",
            "Nur eine neue Grafikkarte installieren"
          ],
          "answer": 0,
          "explain": "Richtlinienverarbeitung hängt von Geltungsbereich, Sicherheitsfilter und Systemzustand ab.",
          "operator": "Nennen"
        },
        {
          "question": "Warum können Benutzer nach Gruppenänderungen weiterhin alte Zugriffsrechte haben?",
          "options": [
            "Das vorhandene Anmeldetoken muss gegebenenfalls erneuert werden",
            "Gruppenmitgliedschaften werden nur im BIOS gesetzt",
            "NTFS verbietet Gruppen"
          ],
          "answer": 0,
          "explain": "Gruppenänderungen wirken oft erst nach neuer Anmeldung beziehungsweise Tokenausstellung.",
          "operator": "Begründen"
        },
        {
          "question": "Ein Task läuft interaktiv, aber nicht geplant. Welche Kombination ist wahrscheinlich relevant?",
          "options": [
            "Ausführungskonto, Arbeitsverzeichnis und Anmeldebedingungen",
            "Nur die Domain-TTL",
            "Nur die Festplattengröße"
          ],
          "answer": 0,
          "explain": "Kontextunterschiede sind typische Fehlerursachen bei geplanten Aufgaben.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "admin",
    "subgroupId": "os",
    "subgroup": "Betriebssysteme"
  },
  {
    "id": "raid",
    "name": "Speicher und RAID",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Welche RAID-Stufe spiegelt Daten auf mindestens zwei Laufwerken?",
          "options": [
            "RAID 1",
            "RAID 0",
            "JBOD"
          ],
          "answer": 0,
          "explain": "RAID 1 nutzt Spiegelung.",
          "operator": "Nennen"
        },
        {
          "question": "Wie heißt die Technik, bei der Daten abwechselnd auf mehrere Laufwerke verteilt werden?",
          "options": [
            "Striping",
            "Spanning von IP-Adressen",
            "DNS-Caching"
          ],
          "answer": 0,
          "explain": "Striping verteilt Datenblöcke über Laufwerke.",
          "operator": "Nennen"
        },
        {
          "question": "Wie viele Laufwerke benötigt RAID 5 mindestens?",
          "options": [
            "3",
            "2",
            "1"
          ],
          "answer": 0,
          "explain": "RAID 5 braucht mindestens drei Laufwerke für Daten und verteilte Parität.",
          "operator": "Nennen"
        },
        {
          "question": "Welchen Schutz bietet RAID 0 bei einem Plattenausfall?",
          "options": [
            "Keinen",
            "Ein Ausfall wird immer toleriert",
            "Zwei Ausfälle werden toleriert"
          ],
          "answer": 0,
          "explain": "RAID 0 erhöht Leistung/Kapazitätsnutzung, aber nicht Fehlertoleranz.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Vier gleich große Laufwerke mit jeweils 2 TB bilden RAID 5. Welche rechnerische Nutzkapazität ergibt sich?",
          "options": [
            "6 TB",
            "8 TB",
            "4 TB"
          ],
          "answer": 0,
          "explain": "RAID 5 nutzt die Kapazität eines Laufwerks rechnerisch für verteilte Parität: (4 − 1) × 2 TB = 6 TB (dezimal), ohne Dateisystem-Overhead.",
          "operator": "Berechnen"
        },
        {
          "question": "Vier Laufwerke zu 2 TB bilden RAID 5. Welche Nutzkapazität ergibt sich näherungsweise?",
          "options": [
            "6 TB",
            "8 TB",
            "4 TB"
          ],
          "answer": 0,
          "explain": "(4 − 1) × 2 TB = 6 TB.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele gleichzeitige Laufwerksausfälle toleriert RAID 6 unabhängig von deren Position?",
          "options": [
            "Bis zu 2",
            "Bis zu 3 bei vier Laufwerken",
            "Keinen"
          ],
          "answer": 0,
          "explain": "RAID 6 verwendet zwei unabhängige Paritätsinformationen.",
          "operator": "Nennen"
        },
        {
          "question": "Ein RAID 10 besteht aus 4 gleich großen Platten zu 1 TB. Welche Nutzkapazität hat es näherungsweise?",
          "options": [
            "2 TB",
            "4 TB",
            "3 TB"
          ],
          "answer": 0,
          "explain": "RAID 10 verwendet Spiegelpaare und Striping; die Hälfte der Rohkapazität ist nutzbar.",
          "operator": "Berechnen"
        }
      ],
      "hard": [
        {
          "question": "Sechs Laufwerke mit je 4 TB bilden RAID 6. Wie groß ist die Nutzkapazität?",
          "options": [
            "16 TB",
            "20 TB",
            "24 TB"
          ],
          "answer": 0,
          "explain": "Bei gleich großen Laufwerken: (6 − 2) × 4 TB = 16 TB, ohne Metadaten und Dateisystem-Overhead.",
          "operator": "Nennen"
        },
        {
          "question": "RAID 5 mit fünf gleich großen Disks zu je 3 TB: Nutzkapazität?",
          "options": [
            "12 TB",
            "15 TB",
            "9 TB"
          ],
          "answer": 0,
          "explain": "(5 − 1) × 3 TB = 12 TB.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Aussage zur Ausfallsicherheit von RAID 10 ist korrekt?",
          "options": [
            "Mehrere Ausfälle sind möglich, sofern kein Spiegelpaar vollständig ausfällt",
            "Beliebige drei Laufwerke dürfen immer ausfallen",
            "Nur ein einziger Ausfall ist grundsätzlich möglich"
          ],
          "answer": 0,
          "explain": "Die tatsächliche Fehlertoleranz hängt davon ab, welche Spiegelmitglieder ausfallen.",
          "operator": "Erläutern"
        },
        {
          "question": "Warum ist nach einem Laufwerksausfall die Rebuild-Phase riskanter?",
          "options": [
            "Weitere Fehler können bei reduzierter Redundanz Datenverlust auslösen",
            "Rebuild erzeugt automatisch ein unabhängiges Backup",
            "Alle Laufwerke werden dadurch schneller und sicherer"
          ],
          "answer": 0,
          "explain": "Während Wiederaufbau liegen höhere Last und eingeschränkte Fehlertoleranz vor.",
          "operator": "Begründen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 5 aus 4 gleich großen Laufwerken zu je 2 TB.",
          "options": [
            "6 TB",
            "8 TB",
            "4 TB"
          ],
          "answer": 0,
          "explain": "RAID 5: (4 − 1) × 2 TB = 6 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 6 aus 5 gleich großen Laufwerken zu je 1 TB.",
          "options": [
            "3 TB",
            "5 TB",
            "4 TB"
          ],
          "answer": 0,
          "explain": "RAID 6: (5 − 2) × 1 TB = 3 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 0 aus 6 gleich großen Laufwerken zu je 8 TB.",
          "options": [
            "48 TB",
            "40 TB",
            "32 TB"
          ],
          "answer": 0,
          "explain": "RAID 0: (6 − 0) × 8 TB = 48 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 5 aus 7 gleich großen Laufwerken zu je 6 TB.",
          "options": [
            "36 TB",
            "42 TB",
            "30 TB"
          ],
          "answer": 0,
          "explain": "RAID 5: (7 − 1) × 6 TB = 36 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 6 aus 8 gleich großen Laufwerken zu je 4 TB.",
          "options": [
            "24 TB",
            "32 TB",
            "28 TB"
          ],
          "answer": 0,
          "explain": "RAID 6: (8 − 2) × 4 TB = 24 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 0 aus 9 gleich großen Laufwerken zu je 3 TB.",
          "options": [
            "27 TB",
            "24 TB",
            "21 TB"
          ],
          "answer": 0,
          "explain": "RAID 0: (9 − 0) × 3 TB = 27 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 5 aus 10 gleich großen Laufwerken zu je 2 TB.",
          "options": [
            "18 TB",
            "20 TB",
            "16 TB"
          ],
          "answer": 0,
          "explain": "RAID 5: (10 − 1) × 2 TB = 18 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 6 aus 11 gleich großen Laufwerken zu je 1 TB.",
          "options": [
            "9 TB",
            "11 TB",
            "10 TB"
          ],
          "answer": 0,
          "explain": "RAID 6: (11 − 2) × 1 TB = 9 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 0 aus 4 gleich großen Laufwerken zu je 8 TB.",
          "options": [
            "32 TB",
            "24 TB",
            "16 TB"
          ],
          "answer": 0,
          "explain": "RAID 0: (4 − 0) × 8 TB = 32 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 5 aus 5 gleich großen Laufwerken zu je 6 TB.",
          "options": [
            "24 TB",
            "30 TB",
            "18 TB"
          ],
          "answer": 0,
          "explain": "RAID 5: (5 − 1) × 6 TB = 24 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 6 aus 6 gleich großen Laufwerken zu je 4 TB.",
          "options": [
            "16 TB",
            "24 TB",
            "20 TB"
          ],
          "answer": 0,
          "explain": "RAID 6: (6 − 2) × 4 TB = 16 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 0 aus 7 gleich großen Laufwerken zu je 3 TB.",
          "options": [
            "21 TB",
            "18 TB",
            "15 TB"
          ],
          "answer": 0,
          "explain": "RAID 0: (7 − 0) × 3 TB = 21 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 5 aus 8 gleich großen Laufwerken zu je 2 TB.",
          "options": [
            "14 TB",
            "16 TB",
            "12 TB"
          ],
          "answer": 0,
          "explain": "RAID 5: (8 − 1) × 2 TB = 14 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 6 aus 9 gleich großen Laufwerken zu je 1 TB.",
          "options": [
            "7 TB",
            "9 TB",
            "8 TB"
          ],
          "answer": 0,
          "explain": "RAID 6: (9 − 2) × 1 TB = 7 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 0 aus 10 gleich großen Laufwerken zu je 8 TB.",
          "options": [
            "80 TB",
            "72 TB",
            "64 TB"
          ],
          "answer": 0,
          "explain": "RAID 0: (10 − 0) × 8 TB = 80 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 5 aus 11 gleich großen Laufwerken zu je 6 TB.",
          "options": [
            "60 TB",
            "66 TB",
            "54 TB"
          ],
          "answer": 0,
          "explain": "RAID 5: (11 − 1) × 6 TB = 60 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 6 aus 4 gleich großen Laufwerken zu je 4 TB.",
          "options": [
            "8 TB",
            "16 TB",
            "12 TB"
          ],
          "answer": 0,
          "explain": "RAID 6: (4 − 2) × 4 TB = 8 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 0 aus 5 gleich großen Laufwerken zu je 3 TB.",
          "options": [
            "15 TB",
            "12 TB",
            "9 TB"
          ],
          "answer": 0,
          "explain": "RAID 0: (5 − 0) × 3 TB = 15 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 5 aus 6 gleich großen Laufwerken zu je 2 TB.",
          "options": [
            "10 TB",
            "12 TB",
            "8 TB"
          ],
          "answer": 0,
          "explain": "RAID 5: (6 − 1) × 2 TB = 10 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 6 aus 7 gleich großen Laufwerken zu je 1 TB.",
          "options": [
            "5 TB",
            "7 TB",
            "6 TB"
          ],
          "answer": 0,
          "explain": "RAID 6: (7 − 2) × 1 TB = 5 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 0 aus 8 gleich großen Laufwerken zu je 8 TB.",
          "options": [
            "64 TB",
            "56 TB",
            "48 TB"
          ],
          "answer": 0,
          "explain": "RAID 0: (8 − 0) × 8 TB = 64 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 5 aus 9 gleich großen Laufwerken zu je 6 TB.",
          "options": [
            "48 TB",
            "54 TB",
            "42 TB"
          ],
          "answer": 0,
          "explain": "RAID 5: (9 − 1) × 6 TB = 48 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 6 aus 10 gleich großen Laufwerken zu je 4 TB.",
          "options": [
            "32 TB",
            "40 TB",
            "36 TB"
          ],
          "answer": 0,
          "explain": "RAID 6: (10 − 2) × 4 TB = 32 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        },
        {
          "question": "Berechnen Sie die nutzbare Rohkapazität eines RAID 0 aus 11 gleich großen Laufwerken zu je 3 TB.",
          "options": [
            "33 TB",
            "30 TB",
            "27 TB"
          ],
          "answer": 0,
          "explain": "RAID 0: (11 − 0) × 3 TB = 33 TB. Dateisystem- und Metadaten-Overhead unberücksichtigt.",
          "operator": "Berechnen"
        }
      ]
    },
    "packId": "server",
    "subgroupId": "storage",
    "subgroup": "Storage und Datensicherung"
  },
  {
    "id": "backup",
    "name": "Backup, RPO und RTO",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Was wird beim Rückspiel gemacht?",
          "options": [
            "Ein zuvor gesicherter Datenstand wird wiederhergestellt",
            "Der DNS-Cache wird geleert",
            "Ein Switch wird getaggt"
          ],
          "answer": 0,
          "explain": "Ein Rückspiel stellt Daten oder Systeme aus einer vorhandenen Sicherung wieder her.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein inkrementelles Backup?",
          "options": [
            "Es sichert Änderungen seit dem letzten Backup im Sicherungszyklus",
            "Es kopiert immer sämtliche Daten neu",
            "Es ändert ausschließlich RAID-Parität"
          ],
          "answer": 0,
          "explain": "Inkrementell bedeutet Änderungen seit dem letzten geeigneten Sicherungsstand.",
          "operator": "Nennen"
        },
        {
          "question": "Was bezeichnet RTO?",
          "options": [
            "Zielzeit für die Wiederherstellung eines Dienstes",
            "Maximale Zahl DNS-Anfragen",
            "Raid Transfer Option"
          ],
          "answer": 0,
          "explain": "Recovery Time Objective betrifft tolerierbare Unterbrechungszeit.",
          "operator": "Nennen"
        },
        {
          "question": "Was beschreibt die 3-2-1-Regel bei Backups?",
          "options": [
            "Drei Kopien auf zwei Medienarten, davon eine extern/offsite",
            "Drei RAID-Controller an zwei Routern",
            "Drei DNS-Server auf einer Platte"
          ],
          "answer": 0,
          "explain": "3-2-1 ist eine Merkhilfe für Backup-Redundanz.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was beschreibt das Recovery Point Objective (RPO)?",
          "options": [
            "Den maximal akzeptierten Datenverlust in Zeit",
            "Die maximale RAM-Belegung",
            "Die Antwortzeit einer Firewall"
          ],
          "answer": 0,
          "explain": "RPO ist der angestrebte maximale Datenverlust als Zeitspanne.",
          "operator": "Nennen"
        },
        {
          "question": "Was unterscheidet RPO und RTO?",
          "options": [
            "RPO betrifft akzeptablen Datenverlustzeitraum, RTO Wiederanlaufzeit",
            "RPO und RTO sind identische Maße",
            "RPO beschreibt Servergröße"
          ],
          "answer": 0,
          "explain": "Recovery Point und Recovery Time beschreiben verschiedene Anforderungen.",
          "operator": "Erläutern"
        },
        {
          "question": "Warum sind regelmäßige Rückspieltests erforderlich?",
          "options": [
            "Nur eine geprüfte Rücksicherung belegt Nutzbarkeit des Sicherungswegs",
            "Die Existenz einer ZIP-Datei beweist Wiederherstellbarkeit",
            "Ein Backup ist automatisch fehlerfrei"
          ],
          "answer": 0,
          "explain": "Sicherungen können beschädigt, unvollständig oder unzugänglich sein.",
          "operator": "Begründen"
        },
        {
          "question": "Warum sollten Backup-Zugangsdaten getrennt geschützt sein?",
          "options": [
            "Ein Angreifer mit Produktionsrechten soll Sicherungen nicht einfach löschen können",
            "Ein gemeinsames Admin-Konto ist zwingend",
            "Backup-Konten benötigen keine Authentifizierung"
          ],
          "answer": 0,
          "explain": "Getrennte Privilegien und unveränderbare Sicherungen erschweren Manipulation.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein Backup läuft alle 12 Stunden und das RPO beträgt 2 Stunden. Welche Aussage ist richtig?",
          "options": [
            "Das Backupintervall allein erfüllt das RPO normalerweise nicht",
            "Das RPO ist damit sicher erreicht",
            "RTO und RPO sind identisch"
          ],
          "answer": 0,
          "explain": "Bei 12 Stunden Abstand können im Ausfallfall bis zu 12 Stunden Änderungen fehlen; zusätzliche Sicherung oder Replikation ist nötig.",
          "operator": "Erläutern"
        },
        {
          "question": "RPO = 1 Stunde, Sicherung nur täglich um 00:00 Uhr. Was gilt?",
          "options": [
            "Der Plan erfüllt das RPO allein normalerweise nicht",
            "Der maximal mögliche Datenverlust beträgt eine Minute",
            "Tägliche Backups garantieren RPO 1 h"
          ],
          "answer": 0,
          "explain": "Bis zu 24 h Datenänderungen können fehlen.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Vollbackup von Sonntag und tägliche inkrementelle Sicherungen bis Mittwoch liegen vor. Was wird für Mittwoch benötigt?",
          "options": [
            "Vollbackup plus alle erforderlichen Inkremente bis Mittwoch",
            "Nur das Inkrement von Mittwoch",
            "Nur das Inkrement von Montag"
          ],
          "answer": 0,
          "explain": "Bei inkrementeller Kette müssen alle Änderungen in zeitlicher Reihenfolge eingespielt werden.",
          "operator": "Nennen"
        },
        {
          "question": "Warum schützt ein am Produktionsserver dauerhaft beschreibbares Backup nicht sicher vor Ransomware?",
          "options": [
            "Der Angreifer kann mit ausreichenden Rechten auch Sicherungen verändern oder löschen",
            "RAID 1 verhindert Dateiverschlüsselung",
            "Jedes Backup ist unveränderlich"
          ],
          "answer": 0,
          "explain": "Getrennte oder unveränderliche Sicherungen sind erforderlich.",
          "operator": "Begründen"
        }
      ]
    },
    "packId": "server",
    "subgroupId": "storage",
    "subgroup": "Storage und Datensicherung"
  },
  {
    "id": "virtual",
    "name": "Virtualisierung und Container",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Welche Funktion hat ein Hypervisor?",
          "options": [
            "Er betreibt und isoliert virtuelle Maschinen",
            "Er wandelt Namen in IPs um",
            "Er ersetzt jede Firewall"
          ],
          "answer": 0,
          "explain": "Ein Hypervisor stellt virtuelle Hardware und Ressourcen für VMs bereit.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist eine virtuelle Maschine?",
          "options": [
            "Abstrahierter Rechner mit eigenem Gastbetriebssystem",
            "Ein reines DNS-Alias",
            "Ein einzelner Ethernet-Port"
          ],
          "answer": 0,
          "explain": "Eine VM nutzt virtualisierte Hardware und ein Gastbetriebssystem.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein Container?",
          "options": [
            "Isolierte Laufzeitumgebung mit gemeinsam genutztem Host-Kernel",
            "Immer eine vollständige physische Maschine",
            "Ein RAID-Controller"
          ],
          "answer": 0,
          "explain": "Container teilen in der Regel den Kernel des Hosts.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein Hostsystem?",
          "options": [
            "Der Rechner, auf dem VMs oder Container laufen",
            "Eine DNS-Zonendatei",
            "Nur ein Client-Browser"
          ],
          "answer": 0,
          "explain": "Hosts stellen Rechen- und Speicherressourcen bereit.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was unterscheidet Container typischerweise von vollständigen VMs?",
          "options": [
            "Container teilen sich den Kernel des Hosts",
            "Container besitzen immer eigenen Hardwarekernel",
            "Container benötigen keine Isolation"
          ],
          "answer": 0,
          "explain": "Container nutzen den Hostkernel, während VMs eine eigene virtualisierte Betriebssystemumgebung bereitstellen.",
          "operator": "Erläutern"
        },
        {
          "question": "Warum kann Ressourcenüberbuchung bei Virtualisierung gefährlich sein?",
          "options": [
            "Gleichzeitige Lastspitzen können zu Engpässen führen",
            "VCPU und RAM sind immer physisch garantiert",
            "Überbuchung erzeugt unendlich viel Speicher"
          ],
          "answer": 0,
          "explain": "Ressourcenzuteilungen müssen zur tatsächlichen Last passen.",
          "operator": "Begründen"
        },
        {
          "question": "Warum verwenden Container häufig Images und persistente Datenbereiche getrennt?",
          "options": [
            "Anwendungsdateien und veränderliche Nutzdaten haben unterschiedliche Lebenszyklen",
            "Alle Daten im Container sind zwangsläufig dauerhaft",
            "Images dürfen keine Software enthalten"
          ],
          "answer": 0,
          "explain": "Persistente Datenträgerbereiche überleben Container-Neuerstellungen.",
          "operator": "Begründen"
        },
        {
          "question": "Was beschreibt Live-Migration von VMs?",
          "options": [
            "Verlagerung einer laufenden VM zwischen Hosts mit möglichst geringer Unterbrechung",
            "Eine neue IP-Adresse als einziger Schritt",
            "Löschung der VM-Sicherung"
          ],
          "answer": 0,
          "explain": "Live-Migration benötigt geeignete Host- und Speicherbedingungen.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Warum ist ein VM-Snapshot keine vollständige Backup-Strategie?",
          "options": [
            "Er ist oft von VM und Storage abhängig und nicht als unabhängige Sicherung ausgelegt",
            "Er verwendet immer ein anderes Rechenzentrum",
            "Er ersetzt automatisch eine Rückspielprobe"
          ],
          "answer": 0,
          "explain": "Snapshots dienen etwa kurzfristigen Zustandswechseln; für Backup sind unabhängige Sicherungen und Rückspieltests erforderlich.",
          "operator": "Begründen"
        },
        {
          "question": "Warum ist eine Container-Neuerstellung ohne persistenten Datenträger riskant?",
          "options": [
            "Veränderliche Daten im beschreibbaren Containerbereich können verloren gehen",
            "Ein Container enthält immer unabhängige Backups",
            "Das Image wird automatisch zum Datenspeicher"
          ],
          "answer": 0,
          "explain": "Zustandsbehaftete Anwendungen brauchen passende Persistenz.",
          "operator": "Begründen"
        },
        {
          "question": "Ein VM-Host hat 16 physische CPU-Kerne und 48 vCPUs sind zugeteilt. Welche Aussage gilt?",
          "options": [
            "Überbuchung kann funktionieren, erfordert jedoch Last- und Latenzbewertung",
            "Jede VM erhält garantiert einen exklusiven Kern",
            "Das Hostsystem hat physisch 48 Kerne"
          ],
          "answer": 0,
          "explain": "vCPU-Zuteilung ist nicht identisch mit physischen Kernen.",
          "operator": "Erläutern"
        },
        {
          "question": "Warum ersetzt ein VM-Snapshot keine getestete Backupstrategie?",
          "options": [
            "Der Snapshot kann vom selben Speicher und denselben Ausfallursachen abhängen",
            "Snapshots sind immer georedundant",
            "Snapshots beweisen Datenbankkonsistenz ohne Prüfung"
          ],
          "answer": 0,
          "explain": "Unabhängige Backups und Rückspieltests sind nötig.",
          "operator": "Begründen"
        }
      ]
    },
    "packId": "server",
    "subgroupId": "plattformen",
    "subgroup": "Virtualisierung und Cloud"
  },
  {
    "id": "cloud",
    "name": "Cloud und Servicemodelle",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Wofür steht IaaS?",
          "options": [
            "Infrastructure as a Service",
            "Internet as a Switch",
            "Identity as a Storage"
          ],
          "answer": 0,
          "explain": "IaaS stellt abstrahierte Infrastrukturressourcen bereit.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür steht SaaS?",
          "options": [
            "Software as a Service",
            "Storage and Switch Administration",
            "System as a Storage"
          ],
          "answer": 0,
          "explain": "SaaS stellt fertige Anwendungen als Dienst bereit.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist eine Public Cloud?",
          "options": [
            "Angebot durch einen externen Cloudanbieter für verschiedene Kunden",
            "Zwingend unverschlüsselter öffentlicher Speicher",
            "Ausschließlich ein Heimnetz"
          ],
          "answer": 0,
          "explain": "Public Cloud beschreibt das Bereitstellungsmodell, nicht automatisch öffentliche Daten.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Skalierung?",
          "options": [
            "Ressourcen an steigende oder sinkende Last anpassen",
            "Festplatten immer verkleinern",
            "Einfach neue Domainnamen vergeben"
          ],
          "answer": 0,
          "explain": "Skalierung kann vertikal oder horizontal erfolgen.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Wofür ist bei SaaS meist der Anbieter zuständig?",
          "options": [
            "Betrieb der Anwendung und ihrer Plattform",
            "Die fachliche Datenqualität des Kunden",
            "Alle Endgeräte des Kunden"
          ],
          "answer": 0,
          "explain": "Bei SaaS betreibt der Anbieter in der Regel die Anwendung, während Nutzer und Anbieter Verantwortung für andere Bereiche teilen.",
          "operator": "Nennen"
        },
        {
          "question": "Wer verwaltet bei SaaS typischerweise die Serverbetriebssysteme?",
          "options": [
            "Der SaaS-Anbieter",
            "Immer der Endanwender",
            "Ein externer DHCP-Client"
          ],
          "answer": 0,
          "explain": "Bei SaaS sind große Teile der technischen Plattform Anbieteraufgabe.",
          "operator": "Nennen"
        },
        {
          "question": "Was beschreibt eine Hybrid-Cloud?",
          "options": [
            "Verknüpfung mehrerer unterschiedlicher Bereitstellungsumgebungen",
            "Nur eine Cloud mit einer VM",
            "Ein RAID-Level"
          ],
          "answer": 0,
          "explain": "Hybrid-Cloud kombiniert beispielsweise Private und Public Cloud.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist Datenstandort allein kein vollständiger Nachweis für DSGVO-Konformität?",
          "options": [
            "Rechtsgrundlagen, Zugriffe, Verträge und Schutzmaßnahmen müssen zusätzlich geprüft werden",
            "Ein europäisches Rechenzentrum ersetzt alle Verträge",
            "Datenstandorte sagen nichts über physische Speicherung"
          ],
          "answer": 0,
          "explain": "Datenschutz verlangt mehr als die Angabe eines Serverstandorts.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein Unternehmen betreibt VMs in einer IaaS-Cloud. Wer patcht typischerweise das Gastbetriebssystem?",
          "options": [
            "Der IaaS-Kunde",
            "Immer der Cloudanbieter allein",
            "Der Internetprovider des Anwenders"
          ],
          "answer": 0,
          "explain": "Beim Shared-Responsibility-Modell liegt das Gastbetriebssystem bei IaaS üblicherweise in Kundenverantwortung.",
          "operator": "Nennen"
        },
        {
          "question": "Ein IaaS-Kunde betreibt einen ungepatchten Linux-Server. Wem fällt das Gastbetriebssystem typischerweise zu?",
          "options": [
            "Dem Kunden",
            "Immer ausschließlich dem Rechenzentrumsbetreiber",
            "Dem Netzwerkkabelhersteller"
          ],
          "answer": 0,
          "explain": "Shared Responsibility bedeutet bei IaaS normalerweise Kundenverantwortung für das Gast-OS.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Exit-Strategie bei Cloudnutzung?",
          "options": [
            "Plan für Datenexport, Dienstwechsel und Rückführung",
            "Sofortiges Löschen aller Nutzerdaten ohne Sicherung",
            "Ewige Bindung an denselben Anbieter"
          ],
          "answer": 0,
          "explain": "Wechselkosten und Abhängigkeiten müssen vor der Auswahl bedacht werden.",
          "operator": "Nennen"
        },
        {
          "question": "Warum kann eine Multi-AZ-Konfiguration robuster sein als eine einzelne Zone?",
          "options": [
            "Sie kann zonenbezogene Ausfallrisiken reduzieren",
            "Sie ersetzt automatisch jede Datensicherung",
            "Alle Availability Zones sind derselbe Raum"
          ],
          "answer": 0,
          "explain": "Unabhängigere Verfügbarkeitszonen können den Ausfallbereich verkleinern.",
          "operator": "Begründen"
        }
      ]
    },
    "packId": "server",
    "subgroupId": "plattformen",
    "subgroup": "Virtualisierung und Cloud"
  },
  {
    "id": "security",
    "name": "IT-Sicherheit, TLS und Datenschutz",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Was schützt eine Verschlüsselung vorrangig?",
          "options": [
            "Vertraulichkeit",
            "Ausfallsicherheit eines RAID",
            "Erhöhung der Bandbreite"
          ],
          "answer": 0,
          "explain": "Verschlüsselung dient insbesondere der Vertraulichkeit der Daten.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Integrität von Daten?",
          "options": [
            "Schutz vor unbemerkter unbefugter Veränderung",
            "Immer schnellerer Datentransfer",
            "Beliebiger Zugriff für alle"
          ],
          "answer": 0,
          "explain": "Integrität sichert die Korrektheit und Unverfälschtheit von Informationen.",
          "operator": "Nennen"
        },
        {
          "question": "Was schützt TLS typischerweise?",
          "options": [
            "Vertraulichkeit und Integrität einer Transportverbindung",
            "Den Austausch aller RAID-Festplatten",
            "Jede Anwendung vor Programmierfehlern"
          ],
          "answer": 0,
          "explain": "TLS sichert die Kommunikation, nicht die gesamte Anwendung.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Least Privilege?",
          "options": [
            "Nur notwendige Berechtigungen vergeben",
            "Alle Benutzer erhalten Adminrechte",
            "Alle Firewallregeln erlauben"
          ],
          "answer": 0,
          "explain": "Minimale Rechte begrenzen mögliche Schäden.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was bestätigt ein gültiges TLS-Serverzertifikat im üblichen HTTPS-Ablauf?",
          "options": [
            "Die überprüfte Identität des Servernamens im Vertrauensmodell",
            "Dass es keine Anwendungslücken gibt",
            "Dass die Datenbank gesichert ist"
          ],
          "answer": 0,
          "explain": "Zertifikatsprüfung bindet einen geprüften Servernamen an einen öffentlichen Schlüssel; Anwendungssicherheit folgt daraus nicht.",
          "operator": "Nennen"
        },
        {
          "question": "Wozu dient ein Hashwert bei einer Dateiüberprüfung?",
          "options": [
            "Zum Vergleich der Datenintegrität",
            "Zur automatischen Entschlüsselung ohne Schlüssel",
            "Als Ersatz aller Backups"
          ],
          "answer": 0,
          "explain": "Kryptografische Hashes helfen, Änderungen zu erkennen.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist der Vorteil eines Salt bei der Passwortspeicherung?",
          "options": [
            "Gleiche Passwörter ergeben unterschiedliche gespeicherte Hashwerte",
            "Passwörter werden ohne Hash verschlüsselt",
            "Ein Salt ist immer geheim und ersetzt das Passwort"
          ],
          "answer": 0,
          "explain": "Individuelle Salts erschweren vorberechnete Angriffe.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist MFA für administrative Zugänge sinnvoll?",
          "options": [
            "Ein gestohlenes Kennwort allein genügt häufig nicht",
            "MFA ersetzt jede Rechteprüfung",
            "MFA erhöht zwingend Netzwerkbandbreite"
          ],
          "answer": 0,
          "explain": "Ein weiterer Faktor erhöht die Hürde für Kontoübernahme.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Welche Maßnahme entspricht dem Grundsatz der Datenminimierung nach DSGVO?",
          "options": [
            "Nur erforderliche personenbezogene Daten verarbeiten",
            "Alle verfügbaren Daten unbegrenzt sammeln",
            "Protokolle ohne Zweck unbegrenzt speichern"
          ],
          "answer": 0,
          "explain": "Art. 5 DSGVO verlangt, personenbezogene Daten auf das notwendige Maß zu beschränken.",
          "operator": "Nennen"
        },
        {
          "question": "Ein TLS-Zertifikat ist abgelaufen, TCP 443 bleibt offen. Welche Aussage ist richtig?",
          "options": [
            "Transportverbindung kann bestehen, aber TLS-Vertrauensprüfung schlägt fehl",
            "TCP muss deshalb auf Layer 2 ausfallen",
            "Jede Browserwarnung ist bedeutungslos"
          ],
          "answer": 0,
          "explain": "Zertifikatsprüfung und TCP-Erreichbarkeit sind verschieden.",
          "operator": "Erläutern"
        },
        {
          "question": "Warum ist AES-GCM bei korrekter Nutzung vorteilhaft?",
          "options": [
            "Es bietet authentifizierte Verschlüsselung mit Vertraulichkeit und Integritätsschutz",
            "Es benötigt niemals Nonces",
            "Es ersetzt jedes Identitätsmanagement"
          ],
          "answer": 0,
          "explain": "AEAD-Verfahren kombinieren Verschlüsselung mit Authentizitätsprüfung.",
          "operator": "Begründen"
        },
        {
          "question": "Weshalb ist die Wiederverwendung derselben Nonce mit demselben Schlüssel bei GCM gefährlich?",
          "options": [
            "Sie kann Vertraulichkeit und Authentizität schwer beeinträchtigen",
            "Sie verbessert die Zufälligkeit",
            "Sie ist für jedes Protokoll zwingend"
          ],
          "answer": 0,
          "explain": "GCM benötigt eindeutige Nonces je Schlüssel.",
          "operator": "Begründen"
        }
      ]
    },
    "packId": "security",
    "subgroupId": "schutz",
    "subgroup": "Sicherheit und Identität"
  },
  {
    "id": "monitoring",
    "name": "Monitoring und Logdateien",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Wofür dienen Systemlogs?",
          "options": [
            "Ereignisse und Fehler nachvollziehen",
            "MAC-Adressen vergeben",
            "RAID-Kapazität erhöhen"
          ],
          "answer": 0,
          "explain": "Logs dokumentieren Ereignisse und helfen bei Diagnose und Nachvollziehbarkeit.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein Monitoring-Alarm?",
          "options": [
            "Eine Meldung bei definiertem Grenzwert oder Ereignis",
            "Ein Netzwerkkabeltyp",
            "Ein DNS-Record"
          ],
          "answer": 0,
          "explain": "Monitoring überwacht Metriken und Ereignisse.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Ressource zeigt hohe CPU-Auslastung?",
          "options": [
            "Prozessorauslastung",
            "Freien Festplattenspeicher",
            "DNS-TTL"
          ],
          "answer": 0,
          "explain": "CPU-Metriken beschreiben Rechenlast.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Uptime?",
          "options": [
            "Zeit, in der ein System in Betrieb ist",
            "Festplattenkapazität",
            "Dauer einer DNS-Zone"
          ],
          "answer": 0,
          "explain": "Uptime bezeichnet Betriebsdauer seit Start oder Verfügbarkeit je Kontext.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was ist ein sinnvoller Monitoring-Alarm?",
          "options": [
            "Eine begründete Schwellwertverletzung mit relevantem Handlungsbedarf",
            "Jedes einzelne Datenpaket",
            "Nur die Uhrzeit des Clients"
          ],
          "answer": 0,
          "explain": "Monitoring sollte verwertbare Abweichungen melden und Fehlalarme begrenzen.",
          "operator": "Nennen"
        },
        {
          "question": "Warum sind Zeitstempel in Logs wichtig?",
          "options": [
            "Ereignisse können zeitlich korreliert werden",
            "Sie verhindern jeden Fehler automatisch",
            "Sie ersetzen Rechtekonzepte"
          ],
          "answer": 0,
          "explain": "Eine konsistente Zeitbasis erleichtert Fehleranalyse über Systeme hinweg.",
          "operator": "Begründen"
        },
        {
          "question": "Was unterscheidet Monitoring von Alerting?",
          "options": [
            "Monitoring erhebt Zustände, Alerting meldet definierte Auffälligkeiten",
            "Beide sind ausschließlich Backups",
            "Alerting misst immer nur Netzwerkbandbreite"
          ],
          "answer": 0,
          "explain": "Überwachung und Benachrichtigung ergänzen einander.",
          "operator": "Erläutern"
        },
        {
          "question": "Weshalb hilft eine Baseline bei Performanceanalyse?",
          "options": [
            "Abweichungen vom Normalzustand werden sichtbar",
            "Sie verbietet jede Änderung",
            "Sie ersetzt alle Anwendungslogs"
          ],
          "answer": 0,
          "explain": "Vergleichswerte erleichtern die Bewertung von Metriken.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein Server meldet hohe CPU-Last und erhöhten Antwortzeitwert. Welche Aussage ist fachlich korrekt?",
          "options": [
            "Korrelation ist ein Hinweis, aber noch kein Kausalitätsbeweis",
            "Hohe CPU-Last beweist einen DDoS",
            "Antwortzeit und CPU sind grundsätzlich unabhängig"
          ],
          "answer": 0,
          "explain": "Für die Ursachenanalyse müssen weitere Metriken, Logs und zeitliche Abhängigkeiten geprüft werden.",
          "operator": "Erläutern"
        },
        {
          "question": "Ein Server hat sehr hohe Antwortzeiten, CPU aber nur 10 %. Was sollte zusätzlich geprüft werden?",
          "options": [
            "I/O-Wartezeiten, Netzwerk und Anwendungsabhängigkeiten",
            "CPU muss die Ursache sein",
            "Nur die Schriftfarbe des Monitoring-Tools"
          ],
          "answer": 0,
          "explain": "Geringe CPU-Last schließt andere Engpässe nicht aus.",
          "operator": "Nennen"
        },
        {
          "question": "Wie reduziert man Alarmmüdigkeit?",
          "options": [
            "Schwellwerte, Korrelation und Priorisierung passend festlegen",
            "Alle Alarme auf kritisch stellen",
            "Warnungen dauerhaft abschalten"
          ],
          "answer": 0,
          "explain": "Gezielte Eskalation verbessert die Signalqualität.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist ein Mittelwert allein bei sporadischen Latenzspitzen oft ungeeignet?",
          "options": [
            "Perzentile und Verteilung zeigen Ausreißer besser",
            "Mittelwerte zeigen immer jedes Extrem",
            "Latenz kann nicht gemessen werden"
          ],
          "answer": 0,
          "explain": "p95/p99 charakterisieren ungünstige Antwortzeitbereiche.",
          "operator": "Begründen"
        }
      ]
    },
    "packId": "security",
    "subgroupId": "betrieb",
    "subgroup": "Monitoring, Störungen und Service"
  },
  {
    "id": "sql",
    "name": "Datenbanken und SQL",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Mit welchem SQL-Befehl liest du Datensätze aus?",
          "options": [
            "SELECT",
            "DELETE",
            "DROP"
          ],
          "answer": 0,
          "explain": "SELECT fragt Datensätze ab.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher SQL-Befehl fügt neue Zeilen ein?",
          "options": [
            "INSERT",
            "SELECT",
            "GRANT"
          ],
          "answer": 0,
          "explain": "INSERT INTO fügt Datensätze hinzu.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein Primärschlüssel?",
          "options": [
            "Attribut oder Attributkombination zur eindeutigen Zeilenidentifikation",
            "Immer das größte Textfeld",
            "Nur der Name des Datenbankservers"
          ],
          "answer": 0,
          "explain": "Primary Keys sind eindeutig und nicht NULL.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher SQL-Befehl filtert Zeilen?",
          "options": [
            "WHERE",
            "ORDER BY allein",
            "CREATE"
          ],
          "answer": 0,
          "explain": "WHERE legt Bedingungen fest.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was bewirkt ein INNER JOIN?",
          "options": [
            "Nur Zeilen mit passenden Join-Bedingungen kombinieren",
            "Immer alle Zeilen beider Tabellen anzeigen",
            "Datenbanken automatisch sichern"
          ],
          "answer": 0,
          "explain": "INNER JOIN bildet Zeilenkombinationen, welche die Join-Bedingung erfüllen.",
          "operator": "Nennen"
        },
        {
          "question": "Was liefert `SELECT COUNT(*) FROM geraete`?",
          "options": [
            "Anzahl der Zeilen in der Tabelle",
            "Summe der Gerätepreise",
            "Anzahl aller Spalten"
          ],
          "answer": 0,
          "explain": "COUNT(*) zählt Zeilen unabhängig von NULL-Werten.",
          "operator": "Nennen"
        },
        {
          "question": "Wozu dient ein Fremdschlüssel?",
          "options": [
            "Er verknüpft Tabellen referenziell",
            "Er verschlüsselt SQL-Kommandos",
            "Er ersetzt Datentypen"
          ],
          "answer": 0,
          "explain": "Foreign Keys sichern Beziehungen zwischen Tabellen.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist eine sinnvolle Maßnahme gegen SQL-Injection?",
          "options": [
            "Parametrisierte Abfragen verwenden",
            "Benutzereingaben direkt an SQL anhängen",
            "Nur die CSS-Farbe ändern"
          ],
          "answer": 0,
          "explain": "Prepared Statements trennen Daten von SQL-Struktur.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Eine Tabelle enthält mehrere Zeilen pro Kunde. Wie erhältst du die Anzahl eindeutiger Kunden-IDs?",
          "options": [
            "COUNT(DISTINCT kunden_id)",
            "COUNT(*) ohne Filter",
            "SUM(kunden_id)"
          ],
          "answer": 0,
          "explain": "COUNT(DISTINCT ...) zählt unterschiedliche nicht-NULL-Werte.",
          "operator": "Nennen"
        },
        {
          "question": "`SELECT kunde_id, COUNT(*) FROM auftrag GROUP BY kunde_id` liefert was?",
          "options": [
            "Anzahl Aufträge pro Kunde",
            "Nur einen zufälligen Gesamtwert",
            "Löscht doppelte Bestellungen"
          ],
          "answer": 0,
          "explain": "GROUP BY bildet Gruppen und COUNT zählt Zeilen je Gruppe.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist bei einem INNER JOIN zwischen Kunden und Aufträgen zu erwarten?",
          "options": [
            "Nur Zeilen mit passenden Schlüsseln in beiden Tabellen",
            "Immer alle Kunden ohne Auftrag",
            "Ein Backup der beiden Tabellen"
          ],
          "answer": 0,
          "explain": "INNER JOIN kombiniert ausschließlich passende Datensätze.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Transaktions-Atomicity nach ACID?",
          "options": [
            "Alle Operationen einer Transaktion gelten gemeinsam oder keine",
            "Transaktionen sind immer unverschlüsselt",
            "Es gibt niemals Rollbacks"
          ],
          "answer": 0,
          "explain": "Atomarität verhindert teilweise übernommene Transaktionsänderungen.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "daten",
    "subgroupId": "datenbanken",
    "subgroup": "Daten und Schnittstellen"
  },
  {
    "id": "uml",
    "name": "UML, Datentypen und Logik",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Welche UML-Darstellung eignet sich für Prozessabläufe und Entscheidungen?",
          "options": [
            "Aktivitätsdiagramm",
            "Netzwerkplan",
            "RAID-Schema"
          ],
          "answer": 0,
          "explain": "Aktivitätsdiagramme modellieren Aktivitäten, Verzweigungen und Abläufe.",
          "operator": "Nennen"
        },
        {
          "question": "Was bezeichnet ein Entscheidungs-Knoten in einem UML-Aktivitätsdiagramm?",
          "options": [
            "Verzweigung nach Bedingungen",
            "Immer den Systemstart",
            "Eine physische Switch-Leitung"
          ],
          "answer": 0,
          "explain": "Entscheidungsknoten verzweigen Kontrollflüsse anhand von Guards.",
          "operator": "Nennen"
        },
        {
          "question": "Was bezeichnet eine Aktion im Aktivitätsdiagramm?",
          "options": [
            "Einen auszuführenden Arbeitsschritt",
            "Eine Datenbank-Spalte",
            "Eine IPv4-Subnetzmaske"
          ],
          "answer": 0,
          "explain": "Aktionsknoten beschreiben Verhalten beziehungsweise Tätigkeiten.",
          "operator": "Nennen"
        },
        {
          "question": "Wie viele Werte hat ein einzelnes Bit?",
          "options": [
            "2",
            "8",
            "256"
          ],
          "answer": 0,
          "explain": "Ein Bit ist binär: 0 oder 1.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was bedeutet eine Guard-Condition an einer UML-Entscheidungskante?",
          "options": [
            "Eine Bedingung für die Wahl dieses Pfades",
            "Eine ausführbare Aktion in jedem Zustand",
            "Eine Netzmaske"
          ],
          "answer": 0,
          "explain": "Eine Guard-Condition wird in eckigen Klammern notiert und bestimmt, wann die Kante genommen werden darf.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist eine Guard-Condition?",
          "options": [
            "Boolesche Bedingung an einem Übergang",
            "Eine Loopback-Adresse",
            "Eine RAID-Paarung"
          ],
          "answer": 0,
          "explain": "Guards entscheiden, welche ausgehende Kante bei einer Verzweigung genutzt wird.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet der Operator `&&` in vielen Programmiersprachen?",
          "options": [
            "Logisches UND",
            "Logisches ODER",
            "Bitweises NICHT"
          ],
          "answer": 0,
          "explain": "&& ist in vielen Sprachen ein kurzschlussfähiger UND-Operator.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Werte kann ein unsigned 8-bit-Integer annehmen?",
          "options": [
            "0 bis 255",
            "−128 bis 127",
            "0 bis 256"
          ],
          "answer": 0,
          "explain": "2⁸ = 256 Werte im Bereich 0–255.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Wie viele Werte kann ein vorzeichenloser 8-Bit-Ganzzahltyp darstellen?",
          "options": [
            "256 Werte von 0 bis 255",
            "128 Werte von 0 bis 127",
            "255 Werte von 1 bis 255"
          ],
          "answer": 0,
          "explain": "2⁸ = 256 unterschiedliche Bitmuster und Werte bei unsigned 8 Bit.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Wertebereich gilt für einen signed 16-bit-Integer im Zweierkomplement?",
          "options": [
            "−32768 bis 32767",
            "0 bis 65535",
            "−65536 bis 65535"
          ],
          "answer": 0,
          "explain": "−2¹⁵ bis 2¹⁵−1.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Bedingung ist logisch äquivalent zu `!(A || B)`?",
          "options": [
            "`!A && !B`",
            "`A && B`",
            "`A || !B`"
          ],
          "answer": 0,
          "explain": "De-Morgan-Regel: Negation von ODER wird UND der negierten Operanden.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Aktivitätsdiagramm hat einen Fork und später einen Join. Welche Semantik steht dahinter?",
          "options": [
            "Parallele Abläufe aufteilen und synchronisieren",
            "Jedes Mal eine Fehlerbedingung",
            "Zwingend ein exklusives Entweder-oder"
          ],
          "answer": 0,
          "explain": "Fork erzeugt parallele Tokenflüsse, Join synchronisiert diese nach Regeln.",
          "operator": "Nennen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 8 Bit darstellen?",
          "options": [
            "256",
            "255",
            "16"
          ],
          "answer": 0,
          "explain": "2^8 = 256 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 10 Bit darstellen?",
          "options": [
            "1.024",
            "1.023",
            "20"
          ],
          "answer": 0,
          "explain": "2^10 = 1.024 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 12 Bit darstellen?",
          "options": [
            "4.096",
            "4.095",
            "24"
          ],
          "answer": 0,
          "explain": "2^12 = 4.096 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 14 Bit darstellen?",
          "options": [
            "16.384",
            "16.383",
            "28"
          ],
          "answer": 0,
          "explain": "2^14 = 16.384 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 16 Bit darstellen?",
          "options": [
            "65.536",
            "65.535",
            "32"
          ],
          "answer": 0,
          "explain": "2^16 = 65.536 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 18 Bit darstellen?",
          "options": [
            "262.144",
            "262.143",
            "36"
          ],
          "answer": 0,
          "explain": "2^18 = 262.144 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 20 Bit darstellen?",
          "options": [
            "1.048.576",
            "1.048.575",
            "40"
          ],
          "answer": 0,
          "explain": "2^20 = 1.048.576 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 22 Bit darstellen?",
          "options": [
            "4.194.304",
            "4.194.303",
            "44"
          ],
          "answer": 0,
          "explain": "2^22 = 4.194.304 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 24 Bit darstellen?",
          "options": [
            "16.777.216",
            "16.777.215",
            "48"
          ],
          "answer": 0,
          "explain": "2^24 = 16.777.216 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 26 Bit darstellen?",
          "options": [
            "67.108.864",
            "67.108.863",
            "52"
          ],
          "answer": 0,
          "explain": "2^26 = 67.108.864 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 28 Bit darstellen?",
          "options": [
            "268.435.456",
            "268.435.455",
            "56"
          ],
          "answer": 0,
          "explain": "2^28 = 268.435.456 mögliche Bitmuster.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie viele unterschiedliche Bitmuster können 30 Bit darstellen?",
          "options": [
            "1.073.741.824",
            "1.073.741.823",
            "60"
          ],
          "answer": 0,
          "explain": "2^30 = 1.073.741.824 mögliche Bitmuster.",
          "operator": "Berechnen"
        }
      ]
    },
    "packId": "daten",
    "subgroupId": "modellierung",
    "subgroup": "UML und Logik"
  },
  {
    "id": "economics",
    "name": "Kosten, Energie und Wirtschaftlichkeit",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Was bedeutet TCO?",
          "options": [
            "Total Cost of Ownership",
            "Transmission Control Option",
            "Total Cloud Output"
          ],
          "answer": 0,
          "explain": "TCO umfasst Anschaffung und laufende Kosten über einen Zeitraum.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet TCO in der IT?",
          "options": [
            "Gesamtkosten über den Betrachtungszeitraum",
            "Nur die Netzwerkschnittstellen",
            "Ein Routerprotokoll"
          ],
          "answer": 0,
          "explain": "TCO umfasst Anschaffung, Betrieb und weitere Lebenszykluskosten.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Einheit misst elektrische Leistung?",
          "options": [
            "Watt",
            "Wattstunden",
            "Byte"
          ],
          "answer": 0,
          "explain": "Watt misst Leistung, Wattstunden Energie.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist eine Amortisationszeit?",
          "options": [
            "Zeitraum, bis eine Investition rechnerisch durch Rückflüsse gedeckt ist",
            "Dauer bis DHCP-Lease-Ende",
            "Speicherzugriffszeit pro I/O"
          ],
          "answer": 0,
          "explain": "Amortisation beschreibt wirtschaftlichen Rückfluss.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Ein Gerät benötigt konstant 100 W. Wie viel Energie verbraucht es in 10 Stunden?",
          "options": [
            "1 kWh",
            "10 kWh",
            "0,1 kWh"
          ],
          "answer": 0,
          "explain": "0,1 kW × 10 h = 1 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät benötigt 100 W und läuft 10 Stunden. Wie viel elektrische Energie verbraucht es?",
          "options": [
            "1 kWh",
            "10 kWh",
            "100 kWh"
          ],
          "answer": 0,
          "explain": "0,1 kW × 10 h = 1 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Was ist ein fixer jährlicher Betriebskostenposten für ein Rechenzentrum?",
          "options": [
            "Vereinbarte pauschale Wartungsgebühr",
            "Verbrauchsmaterial pro verarbeitetem Auftrag",
            "Abhängige Lizenzgebühr pro Nutzer bei linearer Skalierung"
          ],
          "answer": 0,
          "explain": "Fixkosten sind im betrachteten Mengenbereich unabhängig von der Stückzahl.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist ein Kostenvergleich mit Nettopreisen für umsatzsteuerabzugsberechtigte Unternehmen häufig sinnvoll?",
          "options": [
            "Abziehbare Vorsteuer ist normalerweise kein endgültiger Aufwand",
            "Umsatzsteuer ist grundsätzlich immer ein Gewinn",
            "Die Steuer ist immer exakt null"
          ],
          "answer": 0,
          "explain": "Bei Vorsteuerabzug wird der Nettopreis wirtschaftlich verglichen.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein Server kostet 1.500 € Anschaffung plus 300 € Betrieb pro Jahr. Wie hoch ist die TCO für 4 Jahre ohne Restwert?",
          "options": [
            "2.700 €",
            "1.800 €",
            "6.000 €"
          ],
          "answer": 0,
          "explain": "1.500 € + 4 × 300 € = 2.700 €; weitere Kosten bleiben in dieser Aufgabe unberücksichtigt.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Server benötigt 250 W, läuft 24/7 ein Jahr (365 Tage). Wie viel Energie sind das ungefähr?",
          "options": [
            "2.190 kWh",
            "219 kWh",
            "21.900 kWh"
          ],
          "answer": 0,
          "explain": "0,25 kW × 8.760 h = 2.190 kWh.",
          "operator": "Nennen"
        },
        {
          "question": "Strom kostet 0,30 €/kWh. Ein Gerät braucht im Jahr 600 kWh. Welche jährlichen Stromkosten entstehen?",
          "options": [
            "180 €",
            "18 €",
            "1.800 €"
          ],
          "answer": 0,
          "explain": "600 × 0,30 € = 180 €.",
          "operator": "Nennen"
        },
        {
          "question": "Eine Variante spart 400 € pro Jahr bei 2.000 € Mehrinvestition. Wie lange ist die einfache Amortisationsdauer?",
          "options": [
            "5 Jahre",
            "2 Jahre",
            "8 Jahre"
          ],
          "answer": 0,
          "explain": "2.000 € / 400 €/Jahr = 5 Jahre.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 50 W, läuft 4 h täglich an 100 Tagen. Berechnen Sie die Energie.",
          "options": [
            "20 kWh",
            "200 kWh",
            "2 kWh"
          ],
          "answer": 0,
          "explain": "50/1000 kW × 4 h × 100 = 20 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 70 W, läuft 5 h täglich an 150 Tagen. Berechnen Sie die Energie.",
          "options": [
            "52,5 kWh",
            "525 kWh",
            "5,25 kWh"
          ],
          "answer": 0,
          "explain": "70/1000 kW × 5 h × 150 = 52.5 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 90 W, läuft 6 h täglich an 200 Tagen. Berechnen Sie die Energie.",
          "options": [
            "108 kWh",
            "1080 kWh",
            "10,8 kWh"
          ],
          "answer": 0,
          "explain": "90/1000 kW × 6 h × 200 = 108 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 110 W, läuft 7 h täglich an 220 Tagen. Berechnen Sie die Energie.",
          "options": [
            "169,4 kWh",
            "1694 kWh",
            "16,94 kWh"
          ],
          "answer": 0,
          "explain": "110/1000 kW × 7 h × 220 = 169.4 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 130 W, läuft 8 h täglich an 250 Tagen. Berechnen Sie die Energie.",
          "options": [
            "260 kWh",
            "2600 kWh",
            "26 kWh"
          ],
          "answer": 0,
          "explain": "130/1000 kW × 8 h × 250 = 260 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 150 W, läuft 9 h täglich an 300 Tagen. Berechnen Sie die Energie.",
          "options": [
            "405 kWh",
            "4050 kWh",
            "40,5 kWh"
          ],
          "answer": 0,
          "explain": "150/1000 kW × 9 h × 300 = 405 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 170 W, läuft 10 h täglich an 100 Tagen. Berechnen Sie die Energie.",
          "options": [
            "170 kWh",
            "1700 kWh",
            "17 kWh"
          ],
          "answer": 0,
          "explain": "170/1000 kW × 10 h × 100 = 170 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 190 W, läuft 11 h täglich an 150 Tagen. Berechnen Sie die Energie.",
          "options": [
            "313,5 kWh",
            "3135 kWh",
            "31,35 kWh"
          ],
          "answer": 0,
          "explain": "190/1000 kW × 11 h × 150 = 313.5 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 210 W, läuft 4 h täglich an 200 Tagen. Berechnen Sie die Energie.",
          "options": [
            "168 kWh",
            "1680 kWh",
            "16,8 kWh"
          ],
          "answer": 0,
          "explain": "210/1000 kW × 4 h × 200 = 168 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 230 W, läuft 5 h täglich an 220 Tagen. Berechnen Sie die Energie.",
          "options": [
            "253 kWh",
            "2530 kWh",
            "25,3 kWh"
          ],
          "answer": 0,
          "explain": "230/1000 kW × 5 h × 220 = 253 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 250 W, läuft 6 h täglich an 250 Tagen. Berechnen Sie die Energie.",
          "options": [
            "375 kWh",
            "3750 kWh",
            "37,5 kWh"
          ],
          "answer": 0,
          "explain": "250/1000 kW × 6 h × 250 = 375 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Gerät verbraucht 270 W, läuft 7 h täglich an 300 Tagen. Berechnen Sie die Energie.",
          "options": [
            "567 kWh",
            "5670 kWh",
            "56,7 kWh"
          ],
          "answer": 0,
          "explain": "270/1000 kW × 7 h × 300 = 567 kWh.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 600 € und jährlich 110 € Betrieb. Berechnen Sie die TCO für 2 Jahre ohne Restwert.",
          "options": [
            "820 €",
            "710 €",
            "1200 €"
          ],
          "answer": 0,
          "explain": "600 + 2 × 110 = 820 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 725 € und jährlich 135 € Betrieb. Berechnen Sie die TCO für 3 Jahre ohne Restwert.",
          "options": [
            "1130 €",
            "860 €",
            "2175 €"
          ],
          "answer": 0,
          "explain": "725 + 3 × 135 = 1130 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 850 € und jährlich 160 € Betrieb. Berechnen Sie die TCO für 4 Jahre ohne Restwert.",
          "options": [
            "1490 €",
            "1010 €",
            "3400 €"
          ],
          "answer": 0,
          "explain": "850 + 4 × 160 = 1490 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 975 € und jährlich 185 € Betrieb. Berechnen Sie die TCO für 5 Jahre ohne Restwert.",
          "options": [
            "1900 €",
            "1160 €",
            "4875 €"
          ],
          "answer": 0,
          "explain": "975 + 5 × 185 = 1900 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 1100 € und jährlich 210 € Betrieb. Berechnen Sie die TCO für 2 Jahre ohne Restwert.",
          "options": [
            "1520 €",
            "1310 €",
            "2200 €"
          ],
          "answer": 0,
          "explain": "1100 + 2 × 210 = 1520 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 1225 € und jährlich 235 € Betrieb. Berechnen Sie die TCO für 3 Jahre ohne Restwert.",
          "options": [
            "1930 €",
            "1460 €",
            "3675 €"
          ],
          "answer": 0,
          "explain": "1225 + 3 × 235 = 1930 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 1350 € und jährlich 260 € Betrieb. Berechnen Sie die TCO für 4 Jahre ohne Restwert.",
          "options": [
            "2390 €",
            "1610 €",
            "5400 €"
          ],
          "answer": 0,
          "explain": "1350 + 4 × 260 = 2390 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 1475 € und jährlich 285 € Betrieb. Berechnen Sie die TCO für 5 Jahre ohne Restwert.",
          "options": [
            "2900 €",
            "1760 €",
            "7375 €"
          ],
          "answer": 0,
          "explain": "1475 + 5 × 285 = 2900 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 1600 € und jährlich 310 € Betrieb. Berechnen Sie die TCO für 2 Jahre ohne Restwert.",
          "options": [
            "2220 €",
            "1910 €",
            "3200 €"
          ],
          "answer": 0,
          "explain": "1600 + 2 × 310 = 2220 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 1725 € und jährlich 335 € Betrieb. Berechnen Sie die TCO für 3 Jahre ohne Restwert.",
          "options": [
            "2730 €",
            "2060 €",
            "5175 €"
          ],
          "answer": 0,
          "explain": "1725 + 3 × 335 = 2730 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 1850 € und jährlich 360 € Betrieb. Berechnen Sie die TCO für 4 Jahre ohne Restwert.",
          "options": [
            "3290 €",
            "2210 €",
            "7400 €"
          ],
          "answer": 0,
          "explain": "1850 + 4 × 360 = 3290 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein System kostet 1975 € und jährlich 385 € Betrieb. Berechnen Sie die TCO für 5 Jahre ohne Restwert.",
          "options": [
            "3900 €",
            "2360 €",
            "9875 €"
          ],
          "answer": 0,
          "explain": "1975 + 5 × 385 = 3900 €.",
          "operator": "Berechnen"
        }
      ]
    },
    "packId": "wiso",
    "subgroupId": "wiso-wirtschaft",
    "subgroup": "Wirtschaft und Kalkulation"
  },
  {
    "id": "arbeitsrecht",
    "name": "WiSo: Arbeitsrecht",
    "area": "WiSo",
    "questions": {
      "basic": [
        {
          "question": "Wozu dient die Probezeit im Arbeitsverhältnis hauptsächlich?",
          "options": [
            "Beiderseitiges Kennenlernen und Prüfen der Zusammenarbeit",
            "Ausschluss aller Arbeitnehmerrechte",
            "Automatische Befristung jedes Vertrags"
          ],
          "answer": 0,
          "explain": "In der Probezeit können besondere Kündigungsbedingungen gelten, Arbeitnehmerrechte entfallen nicht.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein Arbeitsvertrag?",
          "options": [
            "Vereinbarung über Arbeitsleistung und Vergütung",
            "Ein Softwarelizenzschlüssel",
            "Eine DNS-Zonenübertragung"
          ],
          "answer": 0,
          "explain": "Der Arbeitsvertrag begründet Pflichten von Arbeitnehmer und Arbeitgeber.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist die gesetzliche Höchstarbeitszeit nach ArbZG grundsätzlich pro Werktag?",
          "options": [
            "8 Stunden, unter gesetzlichen Ausgleichsbedingungen bis 10 Stunden",
            "12 Stunden ohne Bedingungen",
            "Immer 4 Stunden"
          ],
          "answer": 0,
          "explain": "§ 3 ArbZG regelt Grundsatz und Ausgleichsmöglichkeiten.",
          "operator": "Nennen"
        },
        {
          "question": "Welches Gesetz schützt unter anderem vor unzulässigen Kündigungen bei entsprechenden Voraussetzungen?",
          "options": [
            "Kündigungsschutzgesetz",
            "Telekommunikationsgesetz als alleinige Grundlage",
            "Straßenverkehrsordnung"
          ],
          "answer": 0,
          "explain": "Das KSchG regelt allgemeine soziale Rechtfertigung unter seinen Voraussetzungen.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Wie lange beträgt der gesetzliche Mindesturlaubsanspruch bei einer 5-Tage-Woche?",
          "options": [
            "20 Arbeitstage",
            "24 Arbeitstage",
            "30 Arbeitstage"
          ],
          "answer": 0,
          "explain": "Das Bundesurlaubsgesetz legt 24 Werktage bei sechs Tagen fest; auf fünf Arbeitstage umgerechnet sind es 20.",
          "operator": "Nennen"
        },
        {
          "question": "Ab wann ist nach ArbZG bei mehr als 6 bis 9 Stunden Arbeit mindestens Pause nötig?",
          "options": [
            "30 Minuten",
            "15 Minuten",
            "Keine Pause"
          ],
          "answer": 0,
          "explain": "§ 4 ArbZG verlangt bei mehr als sechs bis zu neun Stunden mindestens 30 Minuten.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Form benötigt die Kündigung eines Arbeitsverhältnisses?",
          "options": [
            "Schriftform mit eigenhändiger Unterschrift",
            "Beliebige SMS",
            "Mündlich vor zwei Kollegen"
          ],
          "answer": 0,
          "explain": "§ 623 BGB schließt die elektronische Form aus.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet die Entgeltfortzahlung im Krankheitsfall grundsätzlich?",
          "options": [
            "Unter gesetzlichen Voraussetzungen wird Lohn zeitlich begrenzt weitergezahlt",
            "Der Arbeitnehmer verliert sofort alle Ansprüche",
            "Der Arbeitgeber zahlt immer unbegrenzt"
          ],
          "answer": 0,
          "explain": "Das Entgeltfortzahlungsgesetz legt Voraussetzungen und Zeiträume fest.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Welcher Schritt ist für eine wirksame ordentliche Kündigung eines Arbeitsverhältnisses grundsätzlich erforderlich?",
          "options": [
            "Schriftform mit eigenhändiger Unterschrift",
            "Nur eine Messenger-Nachricht",
            "Ein mündlicher Hinweis genügt"
          ],
          "answer": 0,
          "explain": "Nach § 623 BGB muss die Kündigung schriftlich erfolgen; elektronische Form ist ausgeschlossen.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Beschäftigter arbeitet 10 Stunden an einem Tag. Welche Aussage trifft nach ArbZG zu?",
          "options": [
            "Eine Verlängerung ist unter Voraussetzungen mit Ausgleich im Bezugszeitraum möglich",
            "10 Stunden sind grundsätzlich immer ohne Ausgleich erlaubt",
            "Die Pausenpflicht entfällt automatisch"
          ],
          "answer": 0,
          "explain": "§ 3 ArbZG erlaubt bis 10 Stunden nur mit entsprechendem Ausgleich.",
          "operator": "Erläutern"
        },
        {
          "question": "Eine Kündigung wird ausschließlich per E-Mail versandt. Welche Aussage ist grundsätzlich richtig?",
          "options": [
            "Die gesetzliche Schriftform ist damit nicht erfüllt",
            "Eine E-Mail ist automatisch gleichwertig",
            "Bei digitaler Signatur gilt immer ein Arbeitsvertrag als gekündigt"
          ],
          "answer": 0,
          "explain": "§ 623 BGB verlangt schriftliche Kündigung mit eigenhändiger Unterschrift.",
          "operator": "Erläutern"
        },
        {
          "question": "Was ist bei einer ordentlichen Kündigung neben Form und Frist gegebenenfalls zu prüfen?",
          "options": [
            "Anwendbarkeit und Anforderungen des Kündigungsschutzgesetzes",
            "Nur die IP-Adresse des Arbeitsplatzes",
            "Nur die Höhe der Lohnsteuer"
          ],
          "answer": 0,
          "explain": "Bei Geltung des KSchG gelten zusätzliche Anforderungen an die Kündigung.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "wiso",
    "subgroupId": "wiso-grundlagen",
    "subgroup": "Arbeitswelt und Unternehmen"
  },
  {
    "id": "sozial",
    "name": "WiSo: Sozialversicherung",
    "area": "WiSo",
    "questions": {
      "basic": [
        {
          "question": "Welche Versicherung gehört zur gesetzlichen Sozialversicherung in Deutschland?",
          "options": [
            "Rentenversicherung",
            "Hausratversicherung",
            "Kfz-Kaskoversicherung"
          ],
          "answer": 0,
          "explain": "Die gesetzliche Rentenversicherung ist Teil der Sozialversicherung.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Versicherung deckt Arbeitsunfälle und Berufskrankheiten?",
          "options": [
            "Gesetzliche Unfallversicherung",
            "Hausratversicherung",
            "Kfz-Haftpflicht"
          ],
          "answer": 0,
          "explain": "Träger der gesetzlichen Unfallversicherung sind beispielsweise Berufsgenossenschaften.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Sozialversicherung ist für Leistungen bei Pflegebedürftigkeit zuständig?",
          "options": [
            "Pflegeversicherung",
            "Arbeitslosenversicherung",
            "Rechtsschutzversicherung"
          ],
          "answer": 0,
          "explain": "Pflegeversicherung ist eine Säule der Sozialversicherung.",
          "operator": "Nennen"
        },
        {
          "question": "Welche gesetzliche Versicherung deckt wesentliche Krankheitskosten?",
          "options": [
            "Krankenversicherung",
            "Rentenversicherung",
            "Gewerbesteuer"
          ],
          "answer": 0,
          "explain": "Krankenversicherung schützt gegen Krankheitskosten.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Wer trägt die Beiträge zur gesetzlichen Unfallversicherung für Beschäftigte?",
          "options": [
            "Grundsätzlich der Arbeitgeber",
            "Grundsätzlich ausschließlich der Arbeitnehmer",
            "Immer die Gemeinde"
          ],
          "answer": 0,
          "explain": "Die gesetzliche Unfallversicherung wird grundsätzlich durch die Unternehmen finanziert.",
          "operator": "Nennen"
        },
        {
          "question": "Wer trägt bei abhängig Beschäftigten gesetzliche Sozialversicherungsbeiträge typischerweise?",
          "options": [
            "Arbeitnehmer und Arbeitgeber nach gesetzlichen Regeln",
            "Immer nur Arbeitnehmer",
            "Immer ausschließlich die Berufsgenossenschaft"
          ],
          "answer": 0,
          "explain": "Beitragstragung ist je Versicherungszweig geregelt; Unfallversicherung zahlt Arbeitgeber allein.",
          "operator": "Nennen"
        },
        {
          "question": "Wer finanziert die gesetzliche Unfallversicherung für Beschäftigte grundsätzlich?",
          "options": [
            "Arbeitgeber",
            "Beschäftigte allein durch Lohnabzug",
            "Private Autofahrer"
          ],
          "answer": 0,
          "explain": "Die Beiträge werden grundsätzlich durch Arbeitgeber aufgebracht.",
          "operator": "Nennen"
        },
        {
          "question": "Welchem Zweck dient die Rentenversicherung unter anderem?",
          "options": [
            "Altersrenten und bestimmte Leistungen bei Erwerbsminderung",
            "Vollständige Finanzierung jedes Kaufs",
            "Vergabe von Netzadressen"
          ],
          "answer": 0,
          "explain": "Gesetzliche Rentenversicherung erbringt Versicherungsleistungen unter Voraussetzungen.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Welche gesetzliche Versicherung unterstützt bei Arbeitslosigkeit nach erfüllten Voraussetzungen?",
          "options": [
            "Arbeitslosenversicherung",
            "Pflegeversicherung",
            "Unfallversicherung"
          ],
          "answer": 0,
          "explain": "Arbeitslosengeld kann bei Erfüllung der Anspruchsvoraussetzungen aus der Arbeitslosenversicherung gezahlt werden.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Aussage zur Versicherung bei Arbeitsunfällen ist korrekt?",
          "options": [
            "Die gesetzliche Unfallversicherung ist regelmäßig auch für betriebliche Arbeitsunfälle zuständig",
            "Immer ausschließlich die Krankenkasse trägt alle Folgen",
            "Unfallversicherung gilt nie für Auszubildende"
          ],
          "answer": 0,
          "explain": "Die gesetzliche Unfallversicherung erfasst versicherte Tätigkeiten einschließlich betrieblicher Ausbildung.",
          "operator": "Erläutern"
        },
        {
          "question": "Warum ist das Bruttoentgelt nicht identisch mit dem Nettoentgelt?",
          "options": [
            "Steuern und gesetzliche Abzüge können das Auszahlungsentgelt mindern",
            "Netto enthält zwingend 19 % Umsatzsteuer",
            "Brutto ist nach Abzügen immer niedriger"
          ],
          "answer": 0,
          "explain": "Netto ist das nach relevanten Abzügen verbleibende Entgelt.",
          "operator": "Begründen"
        },
        {
          "question": "Bei welchem Ereignis ist die gesetzliche Pflegeversicherung primär relevant?",
          "options": [
            "Festgestellte Pflegebedürftigkeit nach gesetzlichen Kriterien",
            "Ein kaputter Monitor",
            "Kündigung eines Domainnamens"
          ],
          "answer": 0,
          "explain": "Pflegeleistungen setzen entsprechende gesetzliche Voraussetzungen voraus.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "wiso",
    "subgroupId": "wiso-grundlagen",
    "subgroup": "Arbeitswelt und Unternehmen"
  },
  {
    "id": "wiso",
    "name": "WiSo: Unternehmen und Verträge",
    "area": "WiSo",
    "questions": {
      "basic": [
        {
          "question": "Was bedeutet Angebot und Annahme beim Vertragsschluss?",
          "options": [
            "Übereinstimmende Willenserklärungen",
            "Ein DNS-Handshake",
            "Nur die Ausstellung einer Rechnung"
          ],
          "answer": 0,
          "explain": "Ein Vertrag kommt grundsätzlich durch korrespondierende Willenserklärungen zustande.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein Angebot im Vertragsrecht?",
          "options": [
            "Eine auf Vertragsschluss gerichtete, hinreichend bestimmte Willenserklärung",
            "Immer nur eine unverbindliche Werbung",
            "Eine automatisch gültige Rechnung"
          ],
          "answer": 0,
          "explain": "Ein Angebot enthält die wesentlichen Vertragspunkte und Bindungswillen.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Umsatz?",
          "options": [
            "Erlös aus verkauften Waren oder Leistungen",
            "Gewinn nach allen Kosten",
            "Nur der Kontostand"
          ],
          "answer": 0,
          "explain": "Umsatz ist nicht gleich Gewinn.",
          "operator": "Nennen"
        },
        {
          "question": "Wer sind Sozialpartner im arbeitsrechtlichen Sinn?",
          "options": [
            "Gewerkschaften und Arbeitgeber(-verbände)",
            "DNS-Server und Router",
            "Kunden und Lieferanten allein"
          ],
          "answer": 0,
          "explain": "Tarifautonomie wird von den Tarifvertragsparteien ausgeübt.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Welche Rechtsform hat grundsätzlich eine eigene Rechtspersönlichkeit?",
          "options": [
            "GmbH",
            "Einzelunternehmen",
            "Nicht eingetragene einfache Arbeitsgruppe"
          ],
          "answer": 0,
          "explain": "Die GmbH ist eine juristische Person mit eigener Rechtspersönlichkeit.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist eine Bestellung nicht zwangsläufig bereits ein Vertrag?",
          "options": [
            "Ob Angebot und Annahme vorliegen, hängt von den Willenserklärungen ab",
            "Jede Bestellung ist ohne Prüfung rechtskräftig",
            "Eine Bestellung kann niemals angenommen werden"
          ],
          "answer": 0,
          "explain": "Verträge entstehen durch passende Willenserklärungen.",
          "operator": "Begründen"
        },
        {
          "question": "Was beschreibt die Gewinn- und Verlustrechnung?",
          "options": [
            "Erträge und Aufwendungen einer Periode",
            "Nur die IP-Tabelle",
            "Ausschließlich offene Bestellungen"
          ],
          "answer": 0,
          "explain": "GuV ermittelt den Periodenerfolg.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Aufgabe hat der Betriebsrat im gesetzlichen Rahmen?",
          "options": [
            "Interessenvertretung und Mitbestimmung im Betrieb",
            "Zwingend Geschäftsführung übernehmen",
            "Alle Arbeitsverträge allein kündigen"
          ],
          "answer": 0,
          "explain": "Betriebsräte besitzen gesetzlich festgelegte Rechte.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Was beschreibt eine Betriebsvereinbarung?",
          "options": [
            "Eine Vereinbarung zwischen Arbeitgeber und Betriebsrat",
            "Einen Vertrag zwischen zwei Lieferanten",
            "Eine Vereinbarung über IP-Adressbereiche"
          ],
          "answer": 0,
          "explain": "Betriebsvereinbarungen regeln betriebliche Angelegenheiten zwischen Arbeitgeber und Betriebsrat im rechtlichen Rahmen.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist eine allgemeine Werbeanzeige häufig nur eine „invitatio ad offerendum“?",
          "options": [
            "Sie soll Kunden zur Abgabe von Angeboten auffordern, ohne zwingend alle Verträge sofort zu schließen",
            "Sie ist immer ein verbindlicher Individualvertrag",
            "Sie ersetzt jede Vertragsannahme"
          ],
          "answer": 0,
          "explain": "Werbung ist häufig unverbindliche Aufforderung zur Abgabe eines Angebots.",
          "operator": "Begründen"
        },
        {
          "question": "Welche betriebswirtschaftliche Folge hat ein gestiegener Bezugspreis bei konstantem Verkaufspreis?",
          "options": [
            "Der mögliche Deckungsbeitrag sinkt bei sonst gleichen Bedingungen",
            "Der Gewinn steigt zwingend",
            "Die Kosten bleiben immer gleich"
          ],
          "answer": 0,
          "explain": "Steigende variable Beschaffungskosten mindern die Marge.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist bei einer Betriebsvereinbarung im Vergleich zu einem Tarifvertrag zu unterscheiden?",
          "options": [
            "Andere Vertragsparteien und unterschiedliche gesetzliche Regelungsebenen",
            "Beide werden immer nur zwischen zwei Kunden geschlossen",
            "Eine Betriebsvereinbarung ist ein DNS-Datensatz"
          ],
          "answer": 0,
          "explain": "Betriebsvereinbarung: Arbeitgeber und Betriebsrat; Tarifvertrag: Tarifparteien.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "wiso",
    "subgroupId": "wiso-wirtschaft",
    "subgroup": "Wirtschaft und Kalkulation"
  },
  {
    "id": "osi",
    "name": "OSI-Modell, TCP und UDP",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Auf welcher OSI-Schicht arbeitet ein klassischer Ethernet-Switch?",
          "options": [
            "Schicht 2 – Sicherung",
            "Schicht 4 – Transport",
            "Schicht 7 – Anwendung"
          ],
          "answer": 0,
          "explain": "Switches leiten Ethernet-Frames primär anhand von MAC-Adressen weiter.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Transportprotokolle werden in IP-Netzen häufig genutzt?",
          "options": [
            "TCP und UDP",
            "ARP und DNS",
            "HTTP und HTML"
          ],
          "answer": 0,
          "explain": "TCP und UDP gehören zur Transportschicht.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür steht die Abkürzung MTU?",
          "options": [
            "Maximum Transmission Unit",
            "Minimum Transfer Utility",
            "Main Transport User"
          ],
          "answer": 0,
          "explain": "Die MTU begrenzt die Paket- beziehungsweise Nutzdatengröße einer Verbindungsschicht.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was ist ein wesentlicher Unterschied zwischen TCP und UDP?",
          "options": [
            "TCP bietet geordnete zuverlässige Übertragung, UDP nicht automatisch",
            "UDP hat immer einen Verbindungsaufbau mit Quittung",
            "TCP nutzt grundsätzlich keine Ports"
          ],
          "answer": 0,
          "explain": "TCP verwendet Sequenzierung, Bestätigung und Wiederholung von Segmenten.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Mechanismus steuert bei TCP die Menge unbestätigter Daten?",
          "options": [
            "Fluss- und Überlastungssteuerung",
            "STP-Baumwahl",
            "DHCP-Lease"
          ],
          "answer": 0,
          "explain": "TCP nutzt Fenstergrößen und Überlastungssteuerung.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Ping funktioniert, aber HTTPS nicht. Welche Schlussfolgerung ist zulässig?",
          "options": [
            "IP-Erreichbarkeit allein beweist keinen funktionierenden TCP-443-Dienst",
            "Die Website muss erreichbar sein",
            "Die Netzwerkkarte ist defekt"
          ],
          "answer": 0,
          "explain": "ICMP-Erreichbarkeit und TCP-Anwendungszugriff sind getrennt zu prüfen.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Ein Ethernet-Pfad hat eine MTU von 1500 Byte, IPv4 ohne Optionen und TCP ohne Optionen. Wie viel TCP-Nutzlast passt in ein Segment?",
          "options": [
            "1460 Byte",
            "1480 Byte",
            "1500 Byte"
          ],
          "answer": 0,
          "explain": "1500 − 20 Byte IPv4-Header − 20 Byte TCP-Header = 1460 Byte.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist die TCP-Dreiwege-Aushandlung noch keine Bestätigung einer gültigen TLS-Verbindung?",
          "options": [
            "Sie bestätigt zunächst nur den Transportverbindungsaufbau",
            "Sie validiert automatisch jedes Serverzertifikat",
            "Sie enthält grundsätzlich den gesamten HTTP-Inhalt"
          ],
          "answer": 0,
          "explain": "TLS erfolgt logisch nach Aufbau der TCP-Verbindung und prüft eigene Parameter.",
          "operator": "Begründen"
        },
        {
          "question": "Ein Netzwerk hat große Paketverluste. Warum kann TCP-Durchsatz sinken, obwohl nominell 1 Gbit/s bereitstehen?",
          "options": [
            "Wiederholungen und Überlastungssteuerung begrenzen die effektive Datenrate",
            "TCP ignoriert verlorene Segmente",
            "Die Bandbreite steigt bei Verlusten"
          ],
          "answer": 0,
          "explain": "TCP reagiert auf Verluste mit Neuübertragungen und meist verringerter Senderate.",
          "operator": "Begründen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "analyse",
    "subgroup": "Diagnose und Leistung"
  },
  {
    "id": "media",
    "name": "Kupfer, Glasfaser und PoE",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Welches Medium ist gegenüber elektromagnetischen Störungen besonders unempfindlich?",
          "options": [
            "Glasfaser",
            "Ungeschirmtes Kupferkabel",
            "Koaxialkabel ohne Schirm"
          ],
          "answer": 0,
          "explain": "Glasfaser überträgt Licht statt elektrischer Signale.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet PoE?",
          "options": [
            "Power over Ethernet",
            "Packet over Encryption",
            "Port on Endpoint"
          ],
          "answer": 0,
          "explain": "PoE versorgt passende Endgeräte über das Netzwerkkabel mit Energie.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Steckertyp ist bei Twisted-Pair-Ethernet häufig?",
          "options": [
            "RJ45-Steckverbinder (8P8C)",
            "SC-Duplex",
            "HDMI"
          ],
          "answer": 0,
          "explain": "Für Kupfer-Ethernet werden meist 8P8C-Modularstecker genutzt.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was unterscheidet Singlemode- von Multimode-Glasfaser?",
          "options": [
            "Singlemode hat einen kleineren Kern und eignet sich häufig für größere Reichweiten",
            "Multimode ist immer schneller und länger",
            "Singlemode transportiert elektrische Spannungen"
          ],
          "answer": 0,
          "explain": "Singlemode überträgt im Wesentlichen einen Lichtmodus.",
          "operator": "Erläutern"
        },
        {
          "question": "Welche typische Grenze gilt für einen Ethernet-Kupferkanal nach gängigen strukturierten Verkabelungsstandards?",
          "options": [
            "100 m einschließlich Anschlusskabel",
            "1.000 m ohne aktive Komponenten",
            "10 km"
          ],
          "answer": 0,
          "explain": "Für viele Twisted-Pair-Ethernet-Strecken gilt ein Kanal bis 100 m, abhängig von Norm und Übertragungsart.",
          "operator": "Nennen"
        },
        {
          "question": "Warum muss bei SFP-Modulen auf Wellenlänge und Faserart geachtet werden?",
          "options": [
            "Sender und Empfänger müssen optisch zusammenpassen",
            "Nur die LED-Farbe am Switch ist entscheidend",
            "Jedes SFP passt zu jeder Faser ohne Einschränkung"
          ],
          "answer": 0,
          "explain": "Optische Module unterstützen definierte Medien, Wellenlängen und Reichweiten.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein 802.3at-PoE+-Port versorgt ein Endgerät. Welche Aussage trifft zu?",
          "options": [
            "Die am Endgerät verfügbare Leistung liegt unter der maximal eingespeisten Portleistung",
            "Am Endgerät sind immer exakt 30 W nutzbar",
            "PoE+ braucht zwingend Glasfaser"
          ],
          "answer": 0,
          "explain": "Leitungsverluste reduzieren die am Endgerät verfügbare Leistung.",
          "operator": "Erläutern"
        },
        {
          "question": "Ein 105 m langer Kupferkanal verursacht Link-Probleme. Welche Maßnahme ist fachlich sinnvoll?",
          "options": [
            "Strecke normgerecht verkürzen oder geeignete aktive Zwischenstation einsetzen",
            "Schirmung entfernen und unverändert weiterbetreiben",
            "IP-Adresse auf /8 ändern"
          ],
          "answer": 0,
          "explain": "Die physische Übertragungsstrecke und deren Längenbudget sind zu prüfen.",
          "operator": "Erläutern"
        },
        {
          "question": "Warum ist bei Glasfaserverbindungen die Dämpfungsbilanz relevant?",
          "options": [
            "Senderleistung abzüglich Streckenverlusten muss im Empfängerbereich liegen",
            "Sie bestimmt nur die IP-Adresse",
            "Sie ist unabhängig von Steckverbindern"
          ],
          "answer": 0,
          "explain": "Faser, Spleiße, Steckverbinder und Distanz erzeugen optische Dämpfung.",
          "operator": "Begründen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "medien",
    "subgroup": "Medien und WLAN"
  },
  {
    "id": "vpn",
    "name": "VPN, WAN und Tunnel",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Was ist der Hauptzweck eines VPN-Tunnels?",
          "options": [
            "Geschützte Kommunikation über ein anderes Netzwerk",
            "Ein RAID-Verbund aufbauen",
            "Benutzerkonten löschen"
          ],
          "answer": 0,
          "explain": "VPNs koppeln Endpunkte oder Netze logisch über eine Transportinfrastruktur.",
          "operator": "Nennen"
        },
        {
          "question": "Was beschreibt ein Site-to-Site-VPN?",
          "options": [
            "Verbindung zwischen zwei Netzstandorten",
            "Ein WLAN-Gastzugang ohne Schlüssel",
            "Ausschließlich lokale Festplattenkopie"
          ],
          "answer": 0,
          "explain": "Site-to-Site verbindet typischerweise ganze IP-Netze.",
          "operator": "Nennen"
        },
        {
          "question": "Welches Protokoll wird häufig für verschlüsselte IP-Tunnel eingesetzt?",
          "options": [
            "IPsec",
            "STP",
            "SMB1"
          ],
          "answer": 0,
          "explain": "IPsec ist eine Protokollfamilie zum Schutz von IP-Verkehr.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Warum reicht ein VPN-Tunnel allein nicht als vollständiger Netzwerkschutz?",
          "options": [
            "Zugriffsrechte, Endgerätesicherheit und Segmentierung bleiben nötig",
            "VPN verhindert jede Schadsoftware",
            "Ein VPN ersetzt alle Patches"
          ],
          "answer": 0,
          "explain": "Verschlüsselter Transport ersetzt keine Autorisierung.",
          "operator": "Begründen"
        },
        {
          "question": "Was ist Split Tunneling?",
          "options": [
            "Nur ausgewählter Datenverkehr wird durch den VPN-Tunnel geleitet",
            "Jedes Paket wird doppelt verschlüsselt",
            "Alle Daten müssen zwingend durch einen Tunnel"
          ],
          "answer": 0,
          "explain": "Split Tunneling erlaubt getrennte Wege für bestimmte Ziele.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist beim Aufbau eines Site-to-Site-VPN zusätzlich zur Verschlüsselung wichtig?",
          "options": [
            "Passende Routen und Firewall-Freigaben für die Zielnetze",
            "Identische Hostnamen aller Clients",
            "Deaktivierung aller DNS-Server"
          ],
          "answer": 0,
          "explain": "Ohne erreichbare Routen und passende Regeln bleibt der Datenverkehr blockiert.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Zwei Standorte verwenden beide 192.168.1.0/24. Welches Problem entsteht bei einer einfachen VPN-Kopplung?",
          "options": [
            "Überlappende Netze erschweren die eindeutige Zielroutenwahl",
            "IPsec erzeugt automatisch eindeutige Subnetze",
            "Die Masken sind deshalb ungültig"
          ],
          "answer": 0,
          "explain": "Überlappende Adressräume benötigen Neuadressierung oder spezielle NAT-Konzepte.",
          "operator": "Nennen"
        },
        {
          "question": "Warum kann ein VPN-Tunnel mit zusätzlicher Kapselung MTU-Probleme verursachen?",
          "options": [
            "Tunnelheader reduzieren den verfügbaren Platz für Nutzpakete",
            "Der Tunnel vergrößert die physische MTU immer",
            "IPsec verhindert alle Fragmentierung"
          ],
          "answer": 0,
          "explain": "Zusätzliche Header können Fragmentierung oder PMTUD-Anpassungen erforderlich machen.",
          "operator": "Begründen"
        },
        {
          "question": "Ein VPN ist verbunden, aber ein Server ist nicht erreichbar. Was ist die richtige Prüf-Reihenfolge?",
          "options": [
            "Routing, Firewallregeln, Ziel-IP und Dienst getrennt prüfen",
            "Tunnelaufbau beweist vollständige Anwendungsfunktion",
            "Zuerst den RAID-Verbund löschen"
          ],
          "answer": 0,
          "explain": "VPN-Status garantiert nicht automatisch Ende-zu-Ende-Erreichbarkeit.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "routing-wan",
    "subgroup": "Routing und WAN"
  },
  {
    "id": "proxy",
    "name": "Proxy, Reverse Proxy und Lastverteilung",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Welches Bauteil verteilt eingehende Anfragen auf mehrere Server?",
          "options": [
            "Load Balancer",
            "Access-Port",
            "RAID-Controller"
          ],
          "answer": 0,
          "explain": "Ein Load Balancer kann Verbindungen oder Anfragen auf Backends aufteilen.",
          "operator": "Nennen"
        },
        {
          "question": "Wovor steht ein Reverse Proxy typischerweise?",
          "options": [
            "Vor internen Anwendungsservern",
            "Nur vor lokalen Druckerwarteschlangen",
            "Direkt vor jeder Festplatte"
          ],
          "answer": 0,
          "explain": "Ein Reverse Proxy nimmt Clientanfragen entgegen und leitet sie an Backends.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür dient ein Forward Proxy?",
          "options": [
            "Als vermittelnde Instanz für ausgehende Clientanfragen",
            "Zur Spiegelung von Datenplatten",
            "Für STP-Root-Bridge-Wahl"
          ],
          "answer": 0,
          "explain": "Forward Proxies stehen logisch auf der Clientseite.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Wozu dienen Health Checks bei einem Load Balancer?",
          "options": [
            "Nicht verfügbare Backends vom Verteilen auszunehmen",
            "DNS-Namen in MAC-Adressen umzuwandeln",
            "TLS-Schlüssel öffentlich zu senden"
          ],
          "answer": 0,
          "explain": "Health Checks liefern Informationen über die Funktionsfähigkeit der Backends.",
          "operator": "Nennen"
        },
        {
          "question": "Welches Risiko besteht, wenn ein einzelner Load Balancer ohne Redundanz eingesetzt wird?",
          "options": [
            "Single Point of Failure",
            "Doppelte IP-Versionen",
            "Unbegrenzte Bandbreite"
          ],
          "answer": 0,
          "explain": "Der Ausfall des einzigen Verteilers kann alle Backends unerreichbar machen.",
          "operator": "Nennen"
        },
        {
          "question": "Weshalb verwenden Reverse Proxies häufig TLS-Terminierung?",
          "options": [
            "Sie entschlüsseln Client-TLS kontrolliert am Eintrittspunkt und können HTTP weiterleiten",
            "Sie erzwingen automatisch Ende-zu-Ende-Verschlüsselung zum Backend",
            "Sie ersetzen jede Authentifizierung"
          ],
          "answer": 0,
          "explain": "Bei TLS-Terminierung muss der Schutz der Backend-Verbindung gesondert betrachtet werden.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Drei gleich belastbare Backends stehen bereit, eins fällt aus. Was muss ein korrekt konfigurierter Load Balancer leisten?",
          "options": [
            "Nur noch die zwei gesunden Backends verwenden",
            "Anfragen weiter auf den ausgefallenen Host verteilen",
            "Alle DNS-Records löschen"
          ],
          "answer": 0,
          "explain": "Health Checks müssen fehlerhafte Backends aus dem aktiven Pool nehmen.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Reverse Proxy setzt X-Forwarded-For. Warum dürfen Anwendungen diesen Header nicht von beliebigen Clients vertrauen?",
          "options": [
            "Ein Client könnte ihn fälschen; nur vertrauenswürdige Proxies dürfen ihn setzen",
            "Der Header enthält immer ein Zertifikat",
            "Der Header ersetzt TCP-Quelladressen auf Netzwerkebene"
          ],
          "answer": 0,
          "explain": "Client-IP-Header sind nur innerhalb einer korrekt definierten Vertrauenskette zuverlässig.",
          "operator": "Begründen"
        },
        {
          "question": "Ein Backend über HTTP funktioniert hinter einem HTTPS-Reverse-Proxy. Welche Sicherheitsfrage bleibt?",
          "options": [
            "Ist die Verbindung zwischen Proxy und Backend angemessen geschützt?",
            "Ist der gesamte Pfad automatisch TLS-verschlüsselt?",
            "Ist das Proxy-Gerät ein RAID-Level?"
          ],
          "answer": 0,
          "explain": "TLS zum Client allein schützt nicht zwingend die interne Backend-Strecke.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "netzdienste",
    "subgroup": "Netzdienste"
  },
  {
    "id": "qos",
    "name": "Netzleistung, QoS und Kapazität",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Was beschreibt die Latenz einer Netzwerkverbindung?",
          "options": [
            "Zeitverzögerung der Übertragung",
            "Anzahl der Festplatten",
            "Länge des DNS-Namens"
          ],
          "answer": 0,
          "explain": "Latenz beschreibt die Verzögerung bei der Signal- beziehungsweise Paketübertragung.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Größe beschreibt Durchsatz?",
          "options": [
            "Tatsächlich übertragene Datenmenge je Zeit",
            "Maximale Kabellänge",
            "Anzahl der VLANs"
          ],
          "answer": 0,
          "explain": "Durchsatz wird beispielsweise in Mbit/s gemessen.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür steht QoS in Netzwerken?",
          "options": [
            "Quality of Service",
            "Quantity of Storage",
            "Queue of Switches"
          ],
          "answer": 0,
          "explain": "QoS umfasst Mechanismen zur Verkehrsbehandlung und Priorisierung.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Warum ist Jitter bei VoIP besonders relevant?",
          "options": [
            "Schwankende Paketlaufzeiten stören gleichmäßige Audiowiedergabe",
            "Jitter bedeutet ausschließlich Paketverlust",
            "Jitter verschlüsselt Sprachpakete"
          ],
          "answer": 0,
          "explain": "Jitter ist die Schwankung der Verzögerung.",
          "operator": "Begründen"
        },
        {
          "question": "Was bewirkt Priorisierung von Sprachpaketen in einem ausgelasteten Netzwerk?",
          "options": [
            "Sie kann Latenz und Jitter für Sprache senken",
            "Sie erhöht zwingend die physische Bandbreite",
            "Sie verhindert jeden Leitungsfehler"
          ],
          "answer": 0,
          "explain": "Priorisierung beeinflusst Reihenfolge und Warteschlangen, nicht die Linkrate.",
          "operator": "Nennen"
        },
        {
          "question": "Eine 100-Mbit/s-Strecke ist dauernd überlastet. Was ist eine sinnvolle Kapazitätsmaßnahme?",
          "options": [
            "Messwerte auswerten und Last reduzieren oder Bandbreite erhöhen",
            "Nur die IP-Adresse wechseln",
            "DNS-Cache auf 0 setzen"
          ],
          "answer": 0,
          "explain": "Kapazitätsplanung benötigt Messungen der Last und Anwendungsvorgaben.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Eine 200-MB-Datei wird über einen idealen 100-Mbit/s-Link übertragen. Welche Mindestdauer ergibt sich ohne Overhead?",
          "options": [
            "16 Sekunden",
            "2 Sekunden",
            "160 Sekunden"
          ],
          "answer": 0,
          "explain": "200 MB × 8 = 1600 Mbit, geteilt durch 100 Mbit/s ergibt 16 s.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist eine hohe nominale Bandbreite kein Beweis für niedrige Antwortzeiten?",
          "options": [
            "Latenz, Warteschlangen und Serververarbeitung beeinflussen die Reaktionszeit",
            "Bandbreite und Latenz sind identisch",
            "Jeder Hop hat null Verzögerung"
          ],
          "answer": 0,
          "explain": "Durchsatz und Reaktionszeit sind unterschiedliche Qualitätsmerkmale.",
          "operator": "Begründen"
        },
        {
          "question": "Welcher Grund kann Paketverluste trotz geringem durchschnittlichem Traffic erklären?",
          "options": [
            "Kurzzeitige Lastspitzen überfüllen Warteschlangen",
            "Gemittelte Auslastung beweist verlustfreien Betrieb",
            "IPv4-Adressen sind immer zu lang"
          ],
          "answer": 0,
          "explain": "Mikrobursts können Puffer belasten, auch wenn die Durchschnittslast moderat ist.",
          "operator": "Nennen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 50 MB über 100 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "4 Sekunden",
            "0,5 Sekunden",
            "8 Sekunden"
          ],
          "answer": 0,
          "explain": "50 MB × 8 = 400 Mbit; geteilt durch 100 Mbit/s = 4 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 100 MB über 50 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "16 Sekunden",
            "2 Sekunden",
            "32 Sekunden"
          ],
          "answer": 0,
          "explain": "100 MB × 8 = 800 Mbit; geteilt durch 50 Mbit/s = 16 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 125 MB über 500 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "2 Sekunden",
            "0,25 Sekunden",
            "4 Sekunden"
          ],
          "answer": 0,
          "explain": "125 MB × 8 = 1000 Mbit; geteilt durch 500 Mbit/s = 2 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 200 MB über 200 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "8 Sekunden",
            "1 Sekunden",
            "16 Sekunden"
          ],
          "answer": 0,
          "explain": "200 MB × 8 = 1600 Mbit; geteilt durch 200 Mbit/s = 8 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 250 MB über 100 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "20 Sekunden",
            "2,5 Sekunden",
            "40 Sekunden"
          ],
          "answer": 0,
          "explain": "250 MB × 8 = 2000 Mbit; geteilt durch 100 Mbit/s = 20 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 400 MB über 50 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "64 Sekunden",
            "8 Sekunden",
            "128 Sekunden"
          ],
          "answer": 0,
          "explain": "400 MB × 8 = 3200 Mbit; geteilt durch 50 Mbit/s = 64 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 50 MB über 500 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "0,8 Sekunden",
            "0,1 Sekunden",
            "1,6 Sekunden"
          ],
          "answer": 0,
          "explain": "50 MB × 8 = 400 Mbit; geteilt durch 500 Mbit/s = 0.8 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 100 MB über 200 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "4 Sekunden",
            "0,5 Sekunden",
            "8 Sekunden"
          ],
          "answer": 0,
          "explain": "100 MB × 8 = 800 Mbit; geteilt durch 200 Mbit/s = 4 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 125 MB über 100 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "10 Sekunden",
            "1,25 Sekunden",
            "20 Sekunden"
          ],
          "answer": 0,
          "explain": "125 MB × 8 = 1000 Mbit; geteilt durch 100 Mbit/s = 10 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 200 MB über 50 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "32 Sekunden",
            "4 Sekunden",
            "64 Sekunden"
          ],
          "answer": 0,
          "explain": "200 MB × 8 = 1600 Mbit; geteilt durch 50 Mbit/s = 32 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 250 MB über 500 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "4 Sekunden",
            "0,5 Sekunden",
            "8 Sekunden"
          ],
          "answer": 0,
          "explain": "250 MB × 8 = 2000 Mbit; geteilt durch 500 Mbit/s = 4 s.",
          "operator": "Berechnen"
        },
        {
          "question": "Wie lange dauert eine ideale Übertragung von 400 MB über 200 Mbit/s ohne Protokoll-Overhead?",
          "options": [
            "16 Sekunden",
            "2 Sekunden",
            "32 Sekunden"
          ],
          "answer": 0,
          "explain": "400 MB × 8 = 3200 Mbit; geteilt durch 200 Mbit/s = 16 s.",
          "operator": "Berechnen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "analyse",
    "subgroup": "Diagnose und Leistung"
  },
  {
    "id": "filesystems",
    "name": "Dateisysteme, Quotas und Rechte",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Was beschreibt ein Dateisystem?",
          "options": [
            "Organisation von Dateien und Verzeichnissen auf einem Datenträger",
            "Nur eine Firewallregel",
            "Einen DNS-Namensraum"
          ],
          "answer": 0,
          "explain": "Ein Dateisystem verwaltet die Zuordnung und Metadaten von Dateien.",
          "operator": "Nennen"
        },
        {
          "question": "Welches Dateisystem verwendet Windows häufig für Systempartitionen?",
          "options": [
            "NTFS",
            "ext4",
            "ISO 9660 als dauerhaftes Schreibsystem"
          ],
          "answer": 0,
          "explain": "NTFS unterstützt unter anderem Dateiberechtigungen und Journalfunktionen.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür dient eine Quota?",
          "options": [
            "Begrenzung der belegbaren Speichermenge",
            "Erhöhung der Netzwerklatenz",
            "Freischaltung von IP-Adressen"
          ],
          "answer": 0,
          "explain": "Quotas begrenzen Speicherverbrauch pro Benutzer, Gruppe oder Bereich.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was bewirkt ein Journal bei einem Dateisystem?",
          "options": [
            "Es hilft, Metadatenänderungen nach Abstürzen konsistent nachzuvollziehen",
            "Es ersetzt ein externes Backup",
            "Es verschlüsselt jede Datei automatisch"
          ],
          "answer": 0,
          "explain": "Journaling reduziert bestimmte Konsistenzrisiken, ersetzt aber keine Datensicherung.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Linux-Berechtigung erlaubt das Betreten eines Verzeichnisses?",
          "options": [
            "x – Ausführen/Suchen",
            "r – nur Lesen",
            "w – nur Schreiben"
          ],
          "answer": 0,
          "explain": "Bei Verzeichnissen erlaubt x den Pfadzugriff beziehungsweise die Suche.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist RAID 1 kein Ersatz für eine Datei-Versionshistorie?",
          "options": [
            "Versehentliches Löschen wird auf beide Spiegel übertragen",
            "RAID 1 erstellt immer unveränderliche Versionen",
            "Ein Spiegel schützt vor jeder Verschlüsselung"
          ],
          "answer": 0,
          "explain": "Spiegelung repliziert Änderungen einschließlich unerwünschter Änderungen.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein Verzeichnis hat Linux-Rechte 750. Was darf ein Mitglied der Gruppe?",
          "options": [
            "Lesen und betreten, aber nicht schreiben",
            "Lesen, schreiben und betreten",
            "Keinerlei Zugriff"
          ],
          "answer": 0,
          "explain": "750 bedeutet Eigentümer rwx, Gruppe r-x, Andere ---.",
          "operator": "Nennen"
        },
        {
          "question": "Warum sind NTFS-Berechtigungen und SMB-Freigaberechte zusammen zu prüfen?",
          "options": [
            "Beide Zugriffsebenen können die effektiven Rechte einschränken",
            "Es gilt immer nur die Freigabeberechtigung",
            "Freigaberechte gelten ausschließlich bei ext4"
          ],
          "answer": 0,
          "explain": "Die Gesamtberechtigung wird durch beide Ebenen begrenzt.",
          "operator": "Begründen"
        },
        {
          "question": "Was ist bei einer Datenträgerprüfung nach einem ungeplanten Ausfall sinnvoll?",
          "options": [
            "Dateisystemkonsistenz und Datenträgergesundheit getrennt beurteilen",
            "Nur den DNS-Dienst neu starten",
            "Ein Journal beweist ein intaktes Laufwerk"
          ],
          "answer": 0,
          "explain": "Ein fehlerfreies Journal schließt physische Datenträgerfehler nicht aus.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "admin",
    "subgroupId": "rechte",
    "subgroup": "Dateisysteme und Rechte"
  },
  {
    "id": "storageperf",
    "name": "Storage-Performance und Controller",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Was bedeutet IOPS?",
          "options": [
            "Ein-/Ausgabeoperationen pro Sekunde",
            "Internet over Packet Switching",
            "IP Operations Service"
          ],
          "answer": 0,
          "explain": "IOPS misst die Anzahl von I/O-Operationen pro Sekunde.",
          "operator": "Nennen"
        },
        {
          "question": "Welches Speichermedium arbeitet normalerweise ohne mechanische Suchbewegung?",
          "options": [
            "SSD",
            "Festplatte mit Magnetscheiben",
            "Bandlaufwerk"
          ],
          "answer": 0,
          "explain": "SSDs nutzen Halbleiterspeicher statt drehender Magnetscheiben.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Angabe beschreibt eher Bandbreite statt IOPS?",
          "options": [
            "MB/s",
            "Operationen/s",
            "Anzahl der RAID-Disks"
          ],
          "answer": 0,
          "explain": "MB/s beschreibt übertragene Datenmenge pro Sekunde.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Warum können kleine zufällige I/Os eine HDD stärker belasten als sequentielle Zugriffe?",
          "options": [
            "Mechanische Such- und Rotationszeiten wirken sich aus",
            "HDDs besitzen keine beweglichen Teile",
            "Zufallszugriffe verwenden immer weniger CPU"
          ],
          "answer": 0,
          "explain": "Bei HDDs dominieren bei kleinen Random-I/Os oft die mechanischen Positionierungszeiten.",
          "operator": "Begründen"
        },
        {
          "question": "Was ist ein mögliches Risiko von Write-Back-Cache ohne Stromausfallschutz?",
          "options": [
            "Noch nicht dauerhaft geschriebene Daten können verloren gehen",
            "Jede SSD erhöht automatisch die Sicherheit",
            "Caching verhindert ausnahmslos Ausfälle"
          ],
          "answer": 0,
          "explain": "Write-Back meldet Schreibvorgänge teils vor dauerhafter Persistierung als abgeschlossen.",
          "operator": "Nennen"
        },
        {
          "question": "Warum misst man bei Storage sowohl Latenz als auch IOPS?",
          "options": [
            "Viele Operationen sind wenig wert, wenn einzelne Antworten zu lange dauern",
            "Es handelt sich um dieselbe Kennzahl",
            "Die beiden Metriken sind nur für DNS relevant"
          ],
          "answer": 0,
          "explain": "Leistung umfasst Durchsatz, Operationsrate und Antwortzeiten.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein Datenträger liefert 20.000 IOPS bei 4 KiB je Operation. Wie hoch ist der theoretische Durchsatz?",
          "options": [
            "Etwa 78 MiB/s",
            "Etwa 20 MiB/s",
            "Etwa 800 MiB/s"
          ],
          "answer": 0,
          "explain": "20.000 × 4 KiB = 80.000 KiB/s ≈ 78,125 MiB/s.",
          "operator": "Nennen"
        },
        {
          "question": "Warum kann ein RAID 5 bei kleinen zufälligen Schreibzugriffen schlechter abschneiden als bei großen sequentiellen Schreibvorgängen?",
          "options": [
            "Paritätsberechnungen sowie zusätzliche Lese-/Schreibzugriffe erhöhen den Aufwand",
            "RAID 5 hat nie einen Schreibnachteil",
            "Sequentielle Zugriffe brauchen zwingend mehr Paritätsscheiben"
          ],
          "answer": 0,
          "explain": "Kleine Teil-Stripe-Schreibvorgänge können Read-Modify-Write verursachen.",
          "operator": "Begründen"
        },
        {
          "question": "Ein SSD-Verbund hat geringe IOPS trotz schneller Schnittstelle. Was solltest du zuerst untersuchen?",
          "options": [
            "Queue-Tiefe, Latenz, I/O-Größe und Workload",
            "Nur die Gerätefarbe",
            "Ausschließlich die IPv4-Subnetzmaske"
          ],
          "answer": 0,
          "explain": "Benchmarkwerte hängen von Zugriffsmuster, Parallelität und Latenz ab.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "server",
    "subgroupId": "storage",
    "subgroup": "Storage und Datensicherung"
  },
  {
    "id": "identity",
    "name": "Identität, Kerberos und MFA",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Was bedeutet MFA?",
          "options": [
            "Mehrfaktor-Authentifizierung",
            "Mehrfach-Festplatten-Architektur",
            "Managed File Access"
          ],
          "answer": 0,
          "explain": "MFA kombiniert mindestens zwei unabhängige Arten von Authentifizierungsfaktoren.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher Faktor ist ein Besitzmerkmal?",
          "options": [
            "Hardware-Token",
            "Passwort",
            "Fingerabdruck"
          ],
          "answer": 0,
          "explain": "Ein Token ist Besitz, ein Passwort Wissen, ein Fingerabdruck Biometrie.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist Authentifizierung?",
          "options": [
            "Prüfung einer behaupteten Identität",
            "Zuweisung einer IP-Route",
            "Sicherung eines RAID-Verbunds"
          ],
          "answer": 0,
          "explain": "Authentifizierung bestätigt, wer sich anmeldet.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was unterscheidet Autorisierung von Authentifizierung?",
          "options": [
            "Autorisierung legt zulässige Aktionen nach der Identitätsprüfung fest",
            "Beide sind stets dasselbe",
            "Autorisierung verschlüsselt nur Festplatten"
          ],
          "answer": 0,
          "explain": "Berechtigungen regeln Zugriffe, Identitätsprüfung bestätigt den Benutzer.",
          "operator": "Erläutern"
        },
        {
          "question": "Wofür wird Kerberos in AD-Umgebungen häufig eingesetzt?",
          "options": [
            "Ticketbasierte Authentifizierung",
            "DNS-Zonenübertragung",
            "RAID-Paritätsberechnung"
          ],
          "answer": 0,
          "explain": "Kerberos verwendet unter anderem Tickets für Authentifizierungsabläufe.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist eine zentrale Zeitquelle für Kerberos relevant?",
          "options": [
            "Zu große Zeitabweichungen können die Authentifizierung verhindern",
            "Kerberos benötigt immer exakt dieselbe Millisekunde",
            "NTP ist für Kerberos verboten"
          ],
          "answer": 0,
          "explain": "Ticketprüfungen berücksichtigen zulässige Zeitabweichungen.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein Benutzer kennt sein Kennwort, erhält aber keinen Dateizugriff. Welche Ebene muss zusätzlich geprüft werden?",
          "options": [
            "Autorisierung über Gruppen, ACLs und effektive Rechte",
            "Die Identität ist damit grundsätzlich unbekannt",
            "Ein neuer DNS-Server beweist den Zugriff"
          ],
          "answer": 0,
          "explain": "Eine erfolgreiche Anmeldung garantiert keine Ressourcenberechtigung.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist ein hardwaregebundener FIDO2-Schlüssel häufig phishingresistenter als ein SMS-Code?",
          "options": [
            "Die Anmeldung kann kryptografisch an die legitime Origin gebunden sein",
            "Der Schlüssel benötigt nie eine Verifikation",
            "SMS-Nachrichten sind grundsätzlich Ende-zu-Ende verschlüsselt"
          ],
          "answer": 0,
          "explain": "Origin-Bindung erschwert das Weiterleiten von Anmeldeinformationen an Fakesites.",
          "operator": "Begründen"
        },
        {
          "question": "Ein Benutzer ist gleichzeitig in einer erlaubenden und einer explizit verweigernden NTFS-Gruppe. Welche Aussage gilt im üblichen Windows-Rechtemodell?",
          "options": [
            "Explizite Verweigerung kann die Erlaubnis übersteuern",
            "Erlauben gewinnt immer",
            "Gruppen haben keine Wirkung auf ACLs"
          ],
          "answer": 0,
          "explain": "Deny-Einträge können wirksame Berechtigungen einschränken; genaue Auswertung hängt von ACEs ab.",
          "operator": "Erläutern"
        }
      ]
    },
    "packId": "security",
    "subgroupId": "schutz",
    "subgroup": "Sicherheit und Identität"
  },
  {
    "id": "automation",
    "name": "Skripting und geplante Aufgaben",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Wofür wird die Windows-Aufgabenplanung verwendet?",
          "options": [
            "Befehle oder Programme zeit- beziehungsweise ereignisgesteuert starten",
            "Switch-Ports automatisch taggen",
            "Festplatten mechanisch reparieren"
          ],
          "answer": 0,
          "explain": "Geplante Aufgaben lassen sich an Trigger und Aktionen binden.",
          "operator": "Nennen"
        },
        {
          "question": "Was beschreibt ein Skript?",
          "options": [
            "Eine gespeicherte Folge von Anweisungen",
            "Einen physischen Netzwerkport",
            "Eine RAID-Kontrollerkarte"
          ],
          "answer": 0,
          "explain": "Skripte automatisieren Befehlsfolgen.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Windows-Shell unterstützt Cmdlets wie Get-Service?",
          "options": [
            "PowerShell",
            "BIOS Setup",
            "GRUB"
          ],
          "answer": 0,
          "explain": "PowerShell verwendet Cmdlets und eine objektorientierte Pipeline.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Ein Backup-Skript liefert Exitcode 1. Was muss der Folgeprozess tun?",
          "options": [
            "Fehlschlag erkennen und entsprechend reagieren",
            "Immer Erfolg protokollieren",
            "Exitcodes grundsätzlich ignorieren"
          ],
          "answer": 0,
          "explain": "Exitcodes sollten ausgewertet und Fehlerpfade vorgesehen werden.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist bei wiederkehrenden Administrationsskripten wichtig?",
          "options": [
            "Protokollierung und idempotentes Verhalten, wenn möglich",
            "Jeden Lauf mit Zufallsdaten überschreiben",
            "Alle Fehler unterdrücken"
          ],
          "answer": 0,
          "explain": "Sichere Automatisierung berücksichtigt Wiederholung, Diagnose und Wiederanlauf.",
          "operator": "Nennen"
        },
        {
          "question": "Was unterscheidet PowerShell-Pipeline von einer einfachen Textpipeline?",
          "options": [
            "PowerShell übergibt typischerweise Objekte mit Eigenschaften",
            "PowerShell überträgt immer unverschlüsselte TCP-Pakete",
            "PowerShell kann keine Befehle verketten"
          ],
          "answer": 0,
          "explain": "PowerShell erlaubt eine Verarbeitung strukturierter Objekte.",
          "operator": "Erläutern"
        }
      ],
      "hard": [
        {
          "question": "Ein Scheduled Task ist erfolgreich gestartet, aber keine Ausgabedatei entsteht. Was prüfst du zuerst?",
          "options": [
            "Ausführungskonto, Arbeitsverzeichnis und Berechtigungen",
            "Nur die Hintergrundfarbe der GUI",
            "Zwingend das RAID-Level ändern"
          ],
          "answer": 0,
          "explain": "Geplante Aufgaben laufen gegebenenfalls mit anderem Konto und anderem Arbeitsverzeichnis.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist `rm -rf \"$DIR\"` ohne vorherige Prüfung der Variablen gefährlich?",
          "options": [
            "Eine leere oder unerwartete Pfadangabe kann falsche Daten löschen",
            "Das Kommando liest nur Daten",
            "Anführungszeichen verhindern jeden Fehler"
          ],
          "answer": 0,
          "explain": "Bei destruktiven Skripten müssen Eingaben und Pfade kontrolliert werden.",
          "operator": "Begründen"
        },
        {
          "question": "Wofür eignet sich Idempotenz bei Konfigurationsautomatisierung?",
          "options": [
            "Mehrfache Ausführung soll denselben Zielzustand herstellen",
            "Jeder Lauf muss zusätzliche Duplikate erzeugen",
            "Sie macht Berechtigungsprüfungen überflüssig"
          ],
          "answer": 0,
          "explain": "Idempotente Konfigurationen erleichtern wiederholbare und sichere Ausführung.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "admin",
    "subgroupId": "automation",
    "subgroup": "Automatisierung"
  },
  {
    "id": "formats",
    "name": "JSON, XML, REST und Schnittstellen",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Welches Format verwendet Schlüssel-Wert-Paare in geschweiften Klammern?",
          "options": [
            "JSON",
            "CSV ohne Struktur",
            "Binäres RAID-Layout"
          ],
          "answer": 0,
          "explain": "JSON-Objekte bestehen aus benannten Eigenschaften.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür steht API?",
          "options": [
            "Application Programming Interface",
            "Automatic Port Inspection",
            "Advanced Physical Internet"
          ],
          "answer": 0,
          "explain": "Eine API definiert programmierbare Schnittstellen.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher HTTP-Statuscode bedeutet in der Regel „Nicht gefunden“?",
          "options": [
            "404",
            "200",
            "301"
          ],
          "answer": 0,
          "explain": "HTTP 404 signalisiert, dass die angeforderte Ressource nicht gefunden wurde.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Welche HTTP-Methode wird typischerweise zur lesenden Abfrage einer Ressource verwendet?",
          "options": [
            "GET",
            "DELETE",
            "PATCH"
          ],
          "answer": 0,
          "explain": "GET fordert eine Repräsentation einer Ressource an.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet HTTP 401 gegenüber HTTP 403 typischerweise?",
          "options": [
            "401: Authentifizierung fehlt/ist ungültig; 403: Zugriff verweigert",
            "401 und 403 bedeuten immer Serverausfall",
            "403 signalisiert erfolgreiche Anmeldung"
          ],
          "answer": 0,
          "explain": "401 fordert gültige Authentifizierung, 403 verweigert die Aktion.",
          "operator": "Nennen"
        },
        {
          "question": "Welcher JSON-Ausdruck beschreibt eine Liste mit zwei Zahlen korrekt?",
          "options": [
            "[1, 2]",
            "{1, 2}",
            "<1, 2>"
          ],
          "answer": 0,
          "explain": "JSON-Arrays verwenden eckige Klammern.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Warum muss eine API Benutzereingaben serverseitig validieren, selbst wenn das Frontend sie bereits prüft?",
          "options": [
            "Clientprüfungen können umgangen werden",
            "Ein Browser kann keine HTTP-Anfrage verändern",
            "TLS ersetzt Eingabevalidierung"
          ],
          "answer": 0,
          "explain": "Server dürfen sich nicht auf manipulierbare Clientprüfungen verlassen.",
          "operator": "Begründen"
        },
        {
          "question": "Eine Anwendung sendet dieselbe PUT-Anfrage zweimal. Welche Eigenschaft wird für PUT üblicherweise erwartet?",
          "options": [
            "Idempotenz der angeforderten Ressourcenänderung",
            "Zwingend doppelte neue Ressourcen",
            "Erzwungener TCP-Port 25"
          ],
          "answer": 0,
          "explain": "Wiederholte identische PUT-Anforderungen sollen denselben Zielzustand bewirken.",
          "operator": "Nennen"
        },
        {
          "question": "Warum gehört ein API-Schlüssel nicht fest in ausgelieferten JavaScript-Frontendcode?",
          "options": [
            "Er kann von Nutzern ausgelesen und missbraucht werden",
            "Minifizierung macht ihn kryptografisch sicher",
            "Browser übertragen niemals Schlüssel"
          ],
          "answer": 0,
          "explain": "Geheime Zugangsdaten gehören in geschützte Backend-Komponenten.",
          "operator": "Begründen"
        }
      ]
    },
    "packId": "daten",
    "subgroupId": "datenbanken",
    "subgroup": "Daten und Schnittstellen"
  },
  {
    "id": "ha",
    "name": "Hochverfügbarkeit und Cluster",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Was bedeutet Hochverfügbarkeit?",
          "options": [
            "Verringerung der Dienstunterbrechungen durch geeignete Architektur",
            "Eine einzelne große Festplatte",
            "Verzicht auf Monitoring"
          ],
          "answer": 0,
          "explain": "HA soll die Verfügbarkeit von Diensten erhöhen.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein Single Point of Failure?",
          "options": [
            "Eine Komponente, deren Ausfall den ganzen Dienst beeinträchtigt",
            "Ein redundanter Stromkreis",
            "Eine geprüfte Sicherung"
          ],
          "answer": 0,
          "explain": "SPOFs sind fehlende Redundanzen an kritischen Stellen.",
          "operator": "Nennen"
        },
        {
          "question": "Wozu dienen redundante Netzteile?",
          "options": [
            "Versorgung bei Ausfall eines Netzteils unterstützen",
            "Dateien automatisch versionieren",
            "IPv6-Adressen reservieren"
          ],
          "answer": 0,
          "explain": "Redundanz hilft nur, wenn Stromversorgung und übrige Komponenten passend ausgelegt sind.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Warum benötigt ein Cluster häufig Quorum- oder Fencing-Mechanismen?",
          "options": [
            "Um konkurrierende aktive Knoten und Datenkonflikte zu vermeiden",
            "Um DNS komplett abzuschaffen",
            "Damit beide Knoten denselben Datenträger gleichzeitig ungeprüft beschreiben"
          ],
          "answer": 0,
          "explain": "Quorum/Fencing begrenzen Split-Brain-Risiken.",
          "operator": "Begründen"
        },
        {
          "question": "Was ist der Unterschied zwischen aktiver Redundanz und Backup?",
          "options": [
            "Redundanz dient laufender Verfügbarkeit, Backup einer wiederherstellbaren Datenkopie",
            "Beide ersetzen sich vollständig",
            "Backup erhöht unmittelbar die CPU-Taktfrequenz"
          ],
          "answer": 0,
          "explain": "Hochverfügbarkeit und Datensicherung verfolgen unterschiedliche Ziele.",
          "operator": "Erläutern"
        },
        {
          "question": "Weshalb müssen Failover-Szenarien getestet werden?",
          "options": [
            "Nur Tests zeigen, ob Umschaltung innerhalb der Anforderungen funktioniert",
            "Monitoring garantiert erfolgreiche Umschaltung",
            "Ein zweiter Server beweist automatisch HA"
          ],
          "answer": 0,
          "explain": "Konfigurations- und Abhängigkeitsfehler werden häufig erst im Ausfalltest sichtbar.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein Dienst läuft auf zwei Knoten, aber beiden nutzen dieselbe ungeschützte Stromzufuhr. Was bleibt?",
          "options": [
            "Gemeinsamer Ausfallpunkt bei Stromversorgungsstörung",
            "Vollständig unabhängige Verfügbarkeit",
            "Ein 3-2-1-Backup ist damit automatisch umgesetzt"
          ],
          "answer": 0,
          "explain": "Redundanz muss auch gemeinsame Fehlerursachen berücksichtigen.",
          "operator": "Nennen"
        },
        {
          "question": "Ein System hat 99,9 % Verfügbarkeit. Wie viel Ausfallzeit ergibt sich rechnerisch pro 365-Tage-Jahr?",
          "options": [
            "8,76 Stunden",
            "0,876 Stunden",
            "87,6 Stunden"
          ],
          "answer": 0,
          "explain": "365 × 24 h × 0,001 = 8,76 h.",
          "operator": "Nennen"
        },
        {
          "question": "Was beschreibt RTO in einer Hochverfügbarkeitsplanung?",
          "options": [
            "Zulässige Zeit bis zur Wiederherstellung des Dienstes",
            "Maximale Anzahl DHCP-Leases",
            "Jährliche RAID-Kapazität"
          ],
          "answer": 0,
          "explain": "RTO ist die Zielzeit für Wiederaufnahme des Dienstes nach einem Ausfall.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "server",
    "subgroupId": "verfuegbarkeit",
    "subgroup": "Hochverfügbarkeit"
  },
  {
    "id": "risk",
    "name": "Risikoanalyse und Incident Response",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Was gehört zur klassischen Informationssicherheit?",
          "options": [
            "Vertraulichkeit, Integrität und Verfügbarkeit",
            "Bildrate, Farbe und Lautstärke",
            "Durchsatz, Latenz und CPU-Anzahl"
          ],
          "answer": 0,
          "explain": "Die Schutzziele werden häufig als CIA-Triade zusammengefasst.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet ein Sicherheitsvorfall?",
          "options": [
            "Ein Ereignis mit möglicher Beeinträchtigung der Informationssicherheit",
            "Jeder reguläre Login",
            "Jede routinemäßige Speicherprüfung"
          ],
          "answer": 0,
          "explain": "Vorfälle müssen hinsichtlich Risiko und Wirkung bewertet werden.",
          "operator": "Nennen"
        },
        {
          "question": "Warum werden Sicherheitsupdates eingespielt?",
          "options": [
            "Bekannte Schwachstellen und Fehler beheben",
            "Für jedes Update ist immer mehr RAM garantiert",
            "Weil Patches Backups ersetzen"
          ],
          "answer": 0,
          "explain": "Patchmanagement reduziert bekannte Risiken.",
          "operator": "Begründen"
        }
      ],
      "normal": [
        {
          "question": "Wie kann ein Risiko vereinfacht bewertet werden?",
          "options": [
            "Eintrittswahrscheinlichkeit und Schadensausmaß betrachten",
            "Nur den Kaufpreis der Hardware betrachten",
            "Nur die Schriftgröße der Warnmeldung messen"
          ],
          "answer": 0,
          "explain": "Eine Risikobewertung verbindet mögliche Eintrittshäufigkeit und Auswirkungen.",
          "operator": "Nennen"
        },
        {
          "question": "Warum sollten Logdateien bei einem Sicherheitsvorfall gesichert werden?",
          "options": [
            "Sie können Ablauf und Ursache nachvollziehbar machen",
            "Logs dürfen grundsätzlich immer sofort gelöscht werden",
            "Logs ersetzen die Netzsegmentierung"
          ],
          "answer": 0,
          "explain": "Beweissicherung und Integrität sind für die Analyse relevant.",
          "operator": "Begründen"
        },
        {
          "question": "Welche Maßnahme folgt bei einem bestätigten kompromittierten Client häufig zuerst?",
          "options": [
            "Ausbreitung begrenzen und betroffene Systeme isolieren",
            "Alle Backups sofort überschreiben",
            "Ungeprüft alle Produktionssysteme ausschalten"
          ],
          "answer": 0,
          "explain": "Containment begrenzt Folgeschäden; Maßnahmen werden am konkreten Vorfall ausgerichtet.",
          "operator": "Erläutern"
        }
      ],
      "hard": [
        {
          "question": "Ein Risiko hat geringe Eintrittswahrscheinlichkeit, aber sehr hohen möglichen Schaden. Was ist eine begründete Entscheidung?",
          "options": [
            "Risiko nachvollziehbar bewerten und geeignete Maßnahmen anhand des Schadens treffen",
            "Das Risiko wegen Seltenheit immer ignorieren",
            "Sofort alle Systeme abschalten unabhängig vom Kontext"
          ],
          "answer": 0,
          "explain": "Die Bewertung berücksichtigt beide Dimensionen und den Schutzbedarf.",
          "operator": "Begründen"
        },
        {
          "question": "Warum darf ein infiziertes System vor der Beweissicherung nicht unüberlegt neu installiert werden?",
          "options": [
            "Flüchtige Spuren und forensische Hinweise könnten verloren gehen",
            "Neuinstallation löscht immer alle Viren aus Backups",
            "Weil Router sonst keine IP vergeben"
          ],
          "answer": 0,
          "explain": "Forensische Erfassung, Betriebsnotwendigkeit und Eindämmung sind abzuwägen.",
          "operator": "Begründen"
        },
        {
          "question": "Welche Kombination reduziert Ransomware-Folgen am ehesten?",
          "options": [
            "Segmentierung, minimale Rechte und getrennte getestete Sicherungen",
            "Nur identische Passwörter auf allen Systemen",
            "Ausschließlich RAID 0"
          ],
          "answer": 0,
          "explain": "Mehrere unabhängige Schutzschichten erschweren Ausbreitung und ermöglichen Rückspiel.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "security",
    "subgroupId": "betrieb",
    "subgroup": "Monitoring, Störungen und Service"
  },
  {
    "id": "beschaffung",
    "name": "WiSo: Beschaffung und Kaufvertrag",
    "area": "WiSo",
    "questions": {
      "basic": [
        {
          "question": "Was ist ein Kaufvertrag?",
          "options": [
            "Gegenseitiger Vertrag über Ware gegen Kaufpreis",
            "Ein Netzwerkkabelstandard",
            "Eine RAID-Sicherung"
          ],
          "answer": 0,
          "explain": "Der Verkäufer schuldet die Sache, der Käufer die vereinbarte Zahlung.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist eine Rechnung?",
          "options": [
            "Abrechnung über eine Lieferung oder Leistung",
            "Vertraglich immer identisch mit einem Angebot",
            "Ein Serverzertifikat"
          ],
          "answer": 0,
          "explain": "Eine Rechnung dokumentiert eine Forderung und Angaben zur Leistung.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist eine Lieferfrist?",
          "options": [
            "Vereinbarter Zeitraum für die Lieferung",
            "Laufzeit einer DNS-Abfrage",
            "Lebensdauer einer IP-Adresse"
          ],
          "answer": 0,
          "explain": "Lieferfristen können vertragliche Bedeutung haben.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was wird bei einem Angebotsvergleich neben dem Preis berücksichtigt?",
          "options": [
            "Leistungsumfang, Lieferzeit, Service und Risiken",
            "Nur die Farbe des Firmenlogos",
            "Grundsätzlich nie die Lieferbedingungen"
          ],
          "answer": 0,
          "explain": "Wirtschaftliche Bewertung umfasst mehr als den reinen Angebotspreis.",
          "operator": "Nennen"
        },
        {
          "question": "Wann spricht man allgemein von Lieferverzug?",
          "options": [
            "Wenn fällige Leistung trotz Voraussetzungen des Verzugs nicht rechtzeitig erfolgt",
            "Immer vor Ablauf des Liefertermins",
            "Schon wenn eine E-Mail geschrieben wurde"
          ],
          "answer": 0,
          "explain": "Für Verzug sind insbesondere Fälligkeit und die gesetzlichen Voraussetzungen wichtig.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Skonto?",
          "options": [
            "Preisnachlass bei Zahlung innerhalb einer festgelegten Frist",
            "Aufpreis bei Nichtabholung",
            "Steuer auf den Gewinn"
          ],
          "answer": 0,
          "explain": "Skonto ist ein bedingter Zahlungsnachlass.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Ein Angebot kostet 1.000 € netto, 2 % Skonto sind zulässig. Wie viel zahlst du netto bei fristgerechter Skontozahlung?",
          "options": [
            "980 €",
            "998 €",
            "1.020 €"
          ],
          "answer": 0,
          "explain": "1.000 € × 0,98 = 980 €.",
          "operator": "Nennen"
        },
        {
          "question": "Zwei Serverangebote sind technisch gleichwertig. A kostet 1.000 € plus 250 € Betrieb pro Jahr, B 1.200 € plus 180 € pro Jahr. Welches ist über 4 Jahre günstiger?",
          "options": [
            "B mit 1.920 €",
            "A mit 1.500 €",
            "Beide mit 2.000 €"
          ],
          "answer": 0,
          "explain": "A: 2.000 €; B: 1.200 € + 4 × 180 € = 1.920 €.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist eine dokumentierte Wareneingangsprüfung sinnvoll?",
          "options": [
            "Abweichungen und Mängel werden nachvollziehbar erkannt",
            "Sie ersetzt immer eine Vertragsprüfung",
            "Sie macht jede Rechnung ungültig"
          ],
          "answer": 0,
          "explain": "Eine strukturierte Prüfung unterstützt Nachweis, Reklamation und Buchung.",
          "operator": "Begründen"
        }
      ]
    },
    "packId": "wiso",
    "subgroupId": "wiso-wirtschaft",
    "subgroup": "Wirtschaft und Kalkulation"
  },
  {
    "id": "unternehmen",
    "name": "WiSo: Rechtsformen und Mitbestimmung",
    "area": "WiSo",
    "questions": {
      "basic": [
        {
          "question": "Wofür steht GmbH?",
          "options": [
            "Gesellschaft mit beschränkter Haftung",
            "Gemeinschaft mit besonderem Handel",
            "Gesetzlicher Marktbereich Handel"
          ],
          "answer": 0,
          "explain": "Die GmbH ist eine Kapitalgesellschaft.",
          "operator": "Nennen"
        },
        {
          "question": "Wer vertritt Beschäftigte im Rahmen der betrieblichen Mitbestimmung?",
          "options": [
            "Betriebsrat",
            "DNS-Administrator",
            "Kundenbeirat"
          ],
          "answer": 0,
          "explain": "Der Betriebsrat vertritt die Arbeitnehmerinteressen nach BetrVG.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein Tarifvertrag?",
          "options": [
            "Vereinbarung zwischen Tarifvertragsparteien über Arbeitsbedingungen",
            "Ein Wartungsvertrag für Server",
            "Jede individuelle E-Mail eines Mitarbeiters"
          ],
          "answer": 0,
          "explain": "Tarifverträge werden zwischen Gewerkschaften und Arbeitgebern/Arbeitgeberverbänden geschlossen.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was unterscheidet eine GmbH typischerweise vom Einzelunternehmen?",
          "options": [
            "Die GmbH ist eine eigene juristische Person",
            "Beim Einzelunternehmen gibt es nie private Haftung",
            "Eine GmbH ist keine Kapitalgesellschaft"
          ],
          "answer": 0,
          "explain": "Die GmbH besitzt grundsätzlich eigenständige Rechte und Pflichten.",
          "operator": "Erläutern"
        },
        {
          "question": "Was ist eine Betriebsversammlung?",
          "options": [
            "Eine Versammlung der Arbeitnehmer im Rahmen des Betriebsverfassungsrechts",
            "Jede beliebige IT-Konferenz",
            "Ein verpflichtender Tarifabschluss"
          ],
          "answer": 0,
          "explain": "Betriebsversammlungen dienen unter anderem der Information und Aussprache.",
          "operator": "Nennen"
        },
        {
          "question": "Welche Aufgabe hat die Jugend- und Auszubildendenvertretung?",
          "options": [
            "Besondere Interessen jugendlicher Beschäftigter und Auszubildender vertreten",
            "Alle Gesellschaftsverträge unterschreiben",
            "Netzwerkzugang verwalten"
          ],
          "answer": 0,
          "explain": "Die JAV wirkt in Betrieben unter den gesetzlichen Voraussetzungen.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Warum darf ein Betriebsrat Betriebsvereinbarungen nicht beliebig außerhalb gesetzlicher Zuständigkeit abschließen?",
          "options": [
            "Mitbestimmung und Regelungsbefugnisse sind gesetzlich begrenzt",
            "Ein Betriebsrat ist immer ein eigenständiger Arbeitgeber",
            "Betriebsvereinbarungen ersetzen jedes Gesetz"
          ],
          "answer": 0,
          "explain": "Das Betriebsverfassungsgesetz begrenzt Gegenstand und Wirkung.",
          "operator": "Begründen"
        },
        {
          "question": "Was ist bei der Haftung der GmbH grundsätzlich richtig?",
          "options": [
            "Für Gesellschaftsverbindlichkeiten haftet im Grundsatz das Gesellschaftsvermögen",
            "Geschäftsführende haften in jedem Fall uneingeschränkt für alles",
            "Gesellschafter haften immer wie bei einer OHG"
          ],
          "answer": 0,
          "explain": "Die Haftungsbegrenzung gilt grundsätzlich, gesetzliche Ausnahmen können bestehen.",
          "operator": "Nennen"
        },
        {
          "question": "Wer ist in einem Unternehmen typischerweise Ansprechpartner für eine betriebliche Mitbestimmungsfrage?",
          "options": [
            "Der zuständige Betriebsrat",
            "Die Root-CA",
            "Der Routerhersteller"
          ],
          "answer": 0,
          "explain": "Der Betriebsrat hat gesetzliche Informations- und Mitbestimmungsrechte.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "wiso",
    "subgroupId": "wiso-grundlagen",
    "subgroup": "Arbeitswelt und Unternehmen"
  },
  {
    "id": "wiso_rechnen",
    "name": "WiSo: Kalkulation und Kennzahlen",
    "area": "WiSo",
    "questions": {
      "basic": [
        {
          "question": "Was bedeutet Netto-Preis?",
          "options": [
            "Preis ohne Umsatzsteuer",
            "Preis einschließlich Umsatzsteuer",
            "Preis nach allen Löhnen"
          ],
          "answer": 0,
          "explain": "Netto- und Bruttopreise unterscheiden sich bei Umsatzsteuerpflicht durch die Steuer.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Gewinn vereinfacht?",
          "options": [
            "Erträge abzüglich Aufwendungen",
            "Umsatz plus alle Kosten",
            "Anzahl verkaufter Stücke"
          ],
          "answer": 0,
          "explain": "Gewinn ergibt sich vereinfacht aus Erträgen minus Aufwendungen.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Fixkosten?",
          "options": [
            "Kosten, die innerhalb eines betrachteten Bereichs nicht mit der Ausbringungsmenge steigen",
            "Immer null Euro",
            "Nur Material pro Stück"
          ],
          "answer": 0,
          "explain": "Fixkosten fallen innerhalb des relevanten Beschäftigungsbereichs grundsätzlich mengenunabhängig an.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Ein Produkt kostet 100 € netto. Wie hoch ist der Bruttobetrag bei 19 % Umsatzsteuer?",
          "options": [
            "119 €",
            "119,19 €",
            "81 €"
          ],
          "answer": 0,
          "explain": "100 € × 1,19 = 119 €.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Unternehmen verkauft 40 Geräte für 200 € pro Stück. Wie hoch ist der Umsatz?",
          "options": [
            "8.000 €",
            "800 €",
            "5.000 €"
          ],
          "answer": 0,
          "explain": "40 × 200 € = 8.000 €.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist der Deckungsbeitrag pro Stück?",
          "options": [
            "Verkaufspreis minus variable Stückkosten",
            "Verkaufspreis minus alle Lagerbestände",
            "Bruttolohn minus Sozialversicherungsbeiträge"
          ],
          "answer": 0,
          "explain": "Der Stückdeckungsbeitrag dient unter anderem zur Deckung der Fixkosten.",
          "operator": "Nennen"
        },
        {
          "question": "Ein Artikel kostet 100 € netto und wird um 5 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "95 €",
            "105 €",
            "100 €"
          ],
          "answer": 0,
          "explain": "100 × (1 − 5/100) = 95 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 125 € netto und wird um 10 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "112,5 €",
            "137,5 €",
            "125 €"
          ],
          "answer": 0,
          "explain": "125 × (1 − 10/100) = 112.5 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 150 € netto und wird um 15 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "127,5 €",
            "172,5 €",
            "150 €"
          ],
          "answer": 0,
          "explain": "150 × (1 − 15/100) = 127.5 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 175 € netto und wird um 20 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "140 €",
            "210 €",
            "175 €"
          ],
          "answer": 0,
          "explain": "175 × (1 − 20/100) = 140 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 200 € netto und wird um 5 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "190 €",
            "210 €",
            "200 €"
          ],
          "answer": 0,
          "explain": "200 × (1 − 5/100) = 190 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 225 € netto und wird um 10 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "202,5 €",
            "247,5 €",
            "225 €"
          ],
          "answer": 0,
          "explain": "225 × (1 − 10/100) = 202.5 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 250 € netto und wird um 15 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "212,5 €",
            "287,5 €",
            "250 €"
          ],
          "answer": 0,
          "explain": "250 × (1 − 15/100) = 212.5 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 275 € netto und wird um 20 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "220 €",
            "330 €",
            "275 €"
          ],
          "answer": 0,
          "explain": "275 × (1 − 20/100) = 220 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 300 € netto und wird um 5 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "285 €",
            "315 €",
            "300 €"
          ],
          "answer": 0,
          "explain": "300 × (1 − 5/100) = 285 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 325 € netto und wird um 10 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "292,5 €",
            "357,5 €",
            "325 €"
          ],
          "answer": 0,
          "explain": "325 × (1 − 10/100) = 292.5 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 350 € netto und wird um 15 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "297,5 €",
            "402,5 €",
            "350 €"
          ],
          "answer": 0,
          "explain": "350 × (1 − 15/100) = 297.5 €.",
          "operator": "Berechnen"
        },
        {
          "question": "Ein Artikel kostet 375 € netto und wird um 20 % reduziert. Was ist der neue Nettopreis?",
          "options": [
            "300 €",
            "450 €",
            "375 €"
          ],
          "answer": 0,
          "explain": "375 × (1 − 20/100) = 300 €.",
          "operator": "Berechnen"
        }
      ],
      "hard": [
        {
          "question": "Fixkosten betragen 4.000 €, Stückpreis 50 €, variable Kosten 30 €. Wie viele Stück müssen mindestens verkauft werden, um die Fixkosten zu decken?",
          "options": [
            "200 Stück",
            "80 Stück",
            "400 Stück"
          ],
          "answer": 0,
          "explain": "Deckungsbeitrag = 20 € pro Stück; 4.000 / 20 = 200 Stück.",
          "operator": "Nennen"
        },
        {
          "question": "Netto-Angebot 2.500 €, Rabatt 10 %, danach 2 % Skonto. Wie lautet der Zahlbetrag netto?",
          "options": [
            "2.205 €",
            "2.250 €",
            "2.000 €"
          ],
          "answer": 0,
          "explain": "2.500 × 0,90 × 0,98 = 2.205 €.",
          "operator": "Nennen"
        },
        {
          "question": "Eine Investition spart jährlich 600 € und kostet einmalig 1.800 €. Wie hoch ist die einfache Amortisationsdauer ohne Zinsen?",
          "options": [
            "3 Jahre",
            "0,33 Jahre",
            "6 Jahre"
          ],
          "answer": 0,
          "explain": "1.800 € / 600 € pro Jahr = 3 Jahre.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "wiso",
    "subgroupId": "wiso-wirtschaft",
    "subgroup": "Wirtschaft und Kalkulation"
  },
  {
    "id": "wiso_umwelt",
    "name": "WiSo: Umwelt, Wirtschaft und Wettbewerb",
    "area": "WiSo",
    "questions": {
      "basic": [
        {
          "question": "Was versteht man unter Angebot und Nachfrage?",
          "options": [
            "Kräfte, die die Marktpreisbildung beeinflussen",
            "Zwei ISO-Netzwerkschichten",
            "Bestandteile eines RAID-Controllers"
          ],
          "answer": 0,
          "explain": "Preisbildung hängt unter anderem vom Zusammenspiel von Angebot und Nachfrage ab.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Wettbewerb im Markt?",
          "options": [
            "Mehrere Anbieter konkurrieren um Kunden",
            "Ein einziger Anbieter ohne Alternative",
            "Eine Pflicht zur Nutzung desselben Produkts"
          ],
          "answer": 0,
          "explain": "Wettbewerb kann Preis, Qualität und Innovation beeinflussen.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür steht Nachhaltigkeit in der IT-Beschaffung?",
          "options": [
            "Berücksichtigung ökologischer, wirtschaftlicher und sozialer Folgen",
            "Nur möglichst großer Stromverbrauch",
            "Ausschließlich die Farbe der Verpackung"
          ],
          "answer": 0,
          "explain": "Nachhaltigkeit umfasst mehrere Dimensionen.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was ist ein Monopol?",
          "options": [
            "Ein einzelner Anbieter beherrscht einen betrachteten Markt",
            "Genau zwei Nachfrager",
            "Immer ein staatlicher DNS-Dienst"
          ],
          "answer": 0,
          "explain": "Ein Monopol beschreibt die Angebotsseite mit nur einem Anbieter.",
          "operator": "Nennen"
        },
        {
          "question": "Warum sind Lebenszykluskosten für IT-Geräte relevant?",
          "options": [
            "Energie, Wartung und Entsorgung können Anschaffungskosten übersteigen",
            "Nur der Kaufpreis zählt",
            "Stromkosten sind grundsätzlich null"
          ],
          "answer": 0,
          "explain": "TCO betrachtet den gesamten Nutzungszeitraum.",
          "operator": "Begründen"
        },
        {
          "question": "Was bewirkt eine höhere Nachfrage bei unverändertem Angebot in einem einfachen Marktmodell tendenziell?",
          "options": [
            "Steigender Gleichgewichtspreis",
            "Zwingend sinkender Gleichgewichtspreis",
            "Keine Änderung jemals möglich"
          ],
          "answer": 0,
          "explain": "Verschiebung der Nachfragekurve erhöht bei sonst gleichen Bedingungen den Preis.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Ein Gerät A verbraucht 80 W und B 50 W, jeweils 8 h täglich an 220 Tagen. Wie groß ist die jährliche Energieeinsparung von B?",
          "options": [
            "52,8 kWh",
            "528 kWh",
            "5,28 kWh"
          ],
          "answer": 0,
          "explain": "(80 − 50) W × 8 h × 220 / 1.000 = 52,8 kWh.",
          "operator": "Nennen"
        },
        {
          "question": "Warum kann ein günstigeres Gerät über die Nutzungszeit teurer sein?",
          "options": [
            "Höhere Energie-, Service- oder Ausfallkosten erhöhen die TCO",
            "Anschaffungspreis ist gleich Gesamtkosten",
            "Energieverbrauch beeinflusst nie Betriebskosten"
          ],
          "answer": 0,
          "explain": "Wirtschaftlichkeit verlangt Lebenszyklusvergleich.",
          "operator": "Begründen"
        },
        {
          "question": "Welcher Effekt ist bei gestiegenen Beschaffungskosten und unverändertem Verkaufspreis zu erwarten?",
          "options": [
            "Niedrigerer Deckungsbeitrag, wenn sonst alles gleich bleibt",
            "Automatisch höherer Deckungsbeitrag",
            "Sicher unveränderter Gewinn"
          ],
          "answer": 0,
          "explain": "Höhere variable Kosten verringern den Deckungsbeitrag bei konstantem Preis.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "wiso",
    "subgroupId": "wiso-wirtschaft",
    "subgroup": "Wirtschaft und Kalkulation"
  },
  {
    "id": "itservice",
    "name": "IT-Service, SLA und Change Management",
    "area": "IT-Systeme",
    "questions": {
      "basic": [
        {
          "question": "Was bedeutet SLA?",
          "options": [
            "Service Level Agreement",
            "Storage Link Access",
            "Switch Layer Address"
          ],
          "answer": 0,
          "explain": "Ein SLA beschreibt vereinbarte Serviceleistungen und Qualitätsparameter.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist ein Incident im IT-Service?",
          "options": [
            "Eine ungeplante Störung oder Qualitätsminderung eines Dienstes",
            "Jeder genehmigte Normalbetrieb",
            "Nur eine Hardware-Bestellung"
          ],
          "answer": 0,
          "explain": "Incident Management zielt auf rasche Wiederherstellung des Diensts.",
          "operator": "Nennen"
        },
        {
          "question": "Was bedeutet Change Management?",
          "options": [
            "Kontrollierte Planung und Umsetzung von Änderungen",
            "Ungeprüftes Löschen aller Backups",
            "Nur Wechseln von Netzwerkkabeln"
          ],
          "answer": 0,
          "explain": "Änderungsmanagement bewertet Risiken und Freigaben.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Was unterscheidet Incident von Problem Management?",
          "options": [
            "Incident behebt den Dienst, Problem untersucht die zugrunde liegende Ursache",
            "Beide sind ausschließlich Beschaffungsprozesse",
            "Problem Management verbietet Ursachenanalyse"
          ],
          "answer": 0,
          "explain": "Problem Management sucht Ursachen wiederkehrender oder schwerer Störungen.",
          "operator": "Erläutern"
        },
        {
          "question": "Warum sind Wartungsfenster bei produktiven Systemen sinnvoll?",
          "options": [
            "Änderungen können mit geringerer Geschäftsauswirkung geplant werden",
            "Sie machen Rollbacks überflüssig",
            "Sie garantieren fehlerfreie Updates"
          ],
          "answer": 0,
          "explain": "Zeitplanung und Kommunikation reduzieren Betriebsrisiken.",
          "operator": "Begründen"
        },
        {
          "question": "Welche Angaben helfen bei der Priorisierung eines Tickets?",
          "options": [
            "Auswirkung und Dringlichkeit",
            "Nur die Schriftfarbe",
            "Ausschließlich der Vorname des Meldenden"
          ],
          "answer": 0,
          "explain": "Priorität lässt sich aus Impact und Urgency ableiten.",
          "operator": "Nennen"
        }
      ],
      "hard": [
        {
          "question": "Ein Dienst soll 99,5 % in einem 30-Tage-Monat verfügbar sein. Wie viel Ausfallzeit erlaubt dieses Ziel rechnerisch?",
          "options": [
            "3,6 Stunden",
            "0,36 Stunden",
            "36 Stunden"
          ],
          "answer": 0,
          "explain": "30 × 24 h × 0,005 = 3,6 h.",
          "operator": "Nennen"
        },
        {
          "question": "Warum ist ein dokumentierter Rollback-Plan bei riskanten Changes wichtig?",
          "options": [
            "Er ermöglicht kontrollierte Rückkehr bei fehlgeschlagener Änderung",
            "Er ersetzt jede Testumgebung",
            "Er garantiert fehlerfreie Datenmigration"
          ],
          "answer": 0,
          "explain": "Rollback muss die Abhängigkeiten und Datenzustände berücksichtigen.",
          "operator": "Begründen"
        },
        {
          "question": "Ein Ticket ist für viele Anwender kritisch, aber kurzfristig nicht behebbar. Was ist professionell?",
          "options": [
            "Priorisieren, Workaround prüfen und transparent über Status informieren",
            "Das Ticket ohne Dokumentation schließen",
            "Logdateien löschen, um Ruhe zu schaffen"
          ],
          "answer": 0,
          "explain": "Incident Management umfasst Kommunikation und Wiederherstellungsmaßnahmen.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "security",
    "subgroupId": "betrieb",
    "subgroup": "Monitoring, Störungen und Service"
  },
  {
    "id": "wirelesssecurity",
    "name": "WLAN-Sicherheit und Authentifizierung",
    "area": "Netzwerke",
    "questions": {
      "basic": [
        {
          "question": "Was ist WPA3?",
          "options": [
            "Ein Sicherheitsstandard für WLAN",
            "Ein RAID-Level",
            "Ein Routingprotokoll für Glasfaser"
          ],
          "answer": 0,
          "explain": "WPA3 definiert moderne WLAN-Sicherheitsmechanismen.",
          "operator": "Nennen"
        },
        {
          "question": "Was ist eine SSID?",
          "options": [
            "Der Name eines WLAN-Netzes",
            "Ein TCP-Port",
            "Eine IPv4-Netzmaske"
          ],
          "answer": 0,
          "explain": "SSID bezeichnet den Netzwerknamen eines WLANs.",
          "operator": "Nennen"
        },
        {
          "question": "Wofür ist ein Gast-WLAN sinnvoll?",
          "options": [
            "Gäste von internen Ressourcen logisch trennen",
            "Automatisch Administratorrechte vergeben",
            "Festplatten spiegeln"
          ],
          "answer": 0,
          "explain": "Gastnetze sollen häufig Internetzugang ohne internes Vertrauensniveau ermöglichen.",
          "operator": "Nennen"
        }
      ],
      "normal": [
        {
          "question": "Warum sind unterschiedliche SSIDs allein keine sichere Netzsegmentierung?",
          "options": [
            "Erst passende VLANs, ACLs und Routingregeln erzwingen Trennung",
            "SSID-Namen verschlüsseln Routerkonfigurationen",
            "Jede SSID ist automatisch ein eigenes IP-Netz"
          ],
          "answer": 0,
          "explain": "Ein Name ersetzt keine technischen Zugriffsregeln.",
          "operator": "Begründen"
        },
        {
          "question": "Wofür wird 802.1X in Unternehmensnetzen eingesetzt?",
          "options": [
            "Port- beziehungsweise netzbasierte Authentifizierung",
            "RAID-Paritätsverteilung",
            "SMTP-Versand"
          ],
          "answer": 0,
          "explain": "802.1X kann Endgeräte authentifizieren, häufig mit RADIUS.",
          "operator": "Nennen"
        },
        {
          "question": "Warum sind starke WLAN-Passwörter wichtig?",
          "options": [
            "Sie verringern das Risiko von unbefugtem Zugang",
            "Sie erhöhen die Funkreichweite zwingend",
            "Sie ändern automatisch alle IP-Adressen"
          ],
          "answer": 0,
          "explain": "Kennwortstärke betrifft Authentifizierung, nicht Funkphysik.",
          "operator": "Begründen"
        }
      ],
      "hard": [
        {
          "question": "Ein Gast-WLAN erreicht einen internen Dateiserver trotz eigener SSID. Welche Kontrolle ist zuerst relevant?",
          "options": [
            "VLAN-Zuweisung und Firewall-/Routingregeln zwischen den Netzen",
            "Nur den WLAN-Namen ändern",
            "Nur eine neue Antenne installieren"
          ],
          "answer": 0,
          "explain": "Die Segmentgrenze muss Datenverkehr tatsächlich beschränken.",
          "operator": "Nennen"
        },
        {
          "question": "Warum kann ein Rogue Access Point sicherheitskritisch sein?",
          "options": [
            "Er kann unkontrollierte Wege in das Unternehmensnetz eröffnen",
            "Er ist immer ein offizieller DNS-Server",
            "Er ersetzt automatisch den RADIUS-Server"
          ],
          "answer": 0,
          "explain": "Nicht autorisierte Access Points umgehen unter Umständen Sicherheitsvorgaben.",
          "operator": "Begründen"
        },
        {
          "question": "Was ist bei WPA3-Enterprise wichtiger als nur ein starkes SSID-Passwort?",
          "options": [
            "Individuelle Authentifizierung mit passender Infrastruktur und Zertifikatsprüfung",
            "Ein gemeinsames Kennwort für alle Admins",
            "Abschaltung sämtlicher Protokollierung"
          ],
          "answer": 0,
          "explain": "Enterprise-Authentifizierung bindet Identitäten und Zertifikatsvertrauen ein.",
          "operator": "Nennen"
        }
      ]
    },
    "packId": "netzwerk",
    "subgroupId": "netzschutz",
    "subgroup": "Netzsicherheit"
  }
];
