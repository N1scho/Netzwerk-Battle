package de.ap2tcg.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.RenderProcessGoneDetail;
import android.widget.Toast;
import android.util.Log;

/** Native Android host for the bundled, offline AP2 TCG engine. */
public class MainActivity extends Activity {
    private static final String HOME = "file:///android_asset/index.html";
    private WebView game;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11,21,38));
        getWindow().setNavigationBarColor(Color.rgb(11,21,38));
        getWindow().getDecorView().setSystemUiVisibility(0);
        // Portrait is default on phones; rotating to landscape is allowed.
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_USER);
        game = new WebView(this);
        game.setBackgroundColor(Color.rgb(9,14,25));
        game.setOverScrollMode(View.OVER_SCROLL_NEVER);
        game.setVerticalScrollBarEnabled(false);
        game.setHorizontalScrollBarEnabled(false);
        final WebSettings settings = game.getSettings();
        settings.setJavaScriptEnabled(true); // Required by the game rules engine.
        settings.setDomStorageEnabled(true); // Tutorial, deck and match save data.
        settings.setAllowFileAccess(true);   // Bundled assets only.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setDefaultTextEncodingName("utf-8");
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        game.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                if (game != null) {game.destroy(); game = null;}
                Toast.makeText(MainActivity.this,"Spielansicht wird neu gestartet; gespeicherte Fortschritte bleiben erhalten.",Toast.LENGTH_LONG).show();
                recreate();
                return true;
            }
        });
        game.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage msg) {
                if (BuildConfig.DEBUG) Log.d("AP2TCG", msg.message() + " (" + msg.sourceId() + ':' + msg.lineNumber() + ')');
                return true;
            }
        });
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        setContentView(game);
        game.loadUrl(HOME);
    }

    @Override public void onBackPressed() {
        if (game == null) { super.onBackPressed(); return; }
        // Close the in-game dialog or selected card before exiting the app.
        game.evaluateJavascript("window.AP2MobileBack ? window.AP2MobileBack() : false", response -> {
            if ("true".equals(response)) return;
            if (game != null && game.canGoBack()) game.goBack();
            else new android.app.AlertDialog.Builder(MainActivity.this)
                .setTitle("AP2 TCG beenden")
                .setMessage("Das laufende Match wird automatisch gespeichert.")
                .setNegativeButton("Weiterspielen", null)
                .setPositiveButton("Beenden", (d, w) -> finish())
                .show();
        });
    }

    @Override protected void onPause() { if (game != null) game.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (game != null) game.onResume(); }
    @Override protected void onDestroy() {
        if (game != null) { game.stopLoading(); game.destroy(); game = null; }
        super.onDestroy();
    }
}
