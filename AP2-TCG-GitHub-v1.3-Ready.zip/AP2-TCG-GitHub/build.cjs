'use strict';
/**
 * Einzige Quelle für Browser, Offline-HTML und Android-Assets.
 * Ausführen: node build.cjs
 * Benötigt nur Node.js 20+ und keine npm-Abhängigkeiten.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');

const root = __dirname;
const scripts = ['engine.js', 'trivia.js', 'topics.js', 'packs.js', 'app.js'];
const sourceFiles = ['index.html', 'styles.css', ...scripts];
const targets = ['web', 'android-studio/app/src/main/assets'];
const offlineFilename = 'AP2-TCG-v13-Offline.html';
const read = filename => fs.readFileSync(path.join(root, filename), 'utf8');
const sha = filename => crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex');

for (const name of sourceFiles) {
  assert(fs.existsSync(path.join(root, name)), `Quelldatei fehlt: ${name}`);
}

for (const dir of targets) {
  const targetDir = path.join(root, dir);
  fs.mkdirSync(targetDir, {recursive: true});
  for (const name of sourceFiles) {
    fs.copyFileSync(path.join(root, name), path.join(targetDir, name));
  }
}

let output = read('index.html');
const stylesheet = '<link rel="stylesheet" href="styles.css">';
assert(output.includes(stylesheet), 'Link auf styles.css fehlt');
output = output.replace(stylesheet, `<style>\n${read('styles.css')}\n</style>`);
for (const script of scripts) {
  const tag = `<script src="${script}"></script>`;
  assert(output.includes(tag), `Einbindung fehlt: ${script}`);
  const content = read(script);
  assert(!/<\/script/i.test(content), `Unsichere HTML-Einbettung: ${script}`);
  output = output.replace(tag, `<script>\n${content}\n</script>`);
}
// Offline-Version benötigt weder Manifest noch die PWA-Installationslogik.
output = output
  .replace(/<link rel="icon"[^>]*>\s*/g, '')
  .replace(/<link rel="apple-touch-icon"[^>]*>\s*/g, '')
  .replace(/<link rel="manifest"[^>]*>\s*/g, '')
  .replace(/<script>\s*window\.__ap2InstallPrompt=null;[\s\S]*?<\/script>/, '');
assert(!/<script\s+src=/i.test(output), 'Offline-Version lädt externe Skripte');
fs.writeFileSync(path.join(root, offlineFilename), output, 'utf8');

// Jede neue Quellversion erhält einen anderen PWA-Cache-Namen.
// Das vermeidet veraltete Dateien nach einem GitHub-Pages-Deployment.
const assetNames = [
  './', './index.html', './styles.css', ...scripts.map(x => `./${x}`),
  './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png'
];
const fp = crypto.createHash('sha256');
for (const name of sourceFiles) fp.update(read(name));
fp.update(fs.readFileSync(path.join(root, 'web/manifest.webmanifest')));
const version = fp.digest('hex').slice(0, 16);
const worker = `/* Automatisch aus build.cjs erzeugt. Nicht direkt bearbeiten. */\n` +
`const CACHE = 'ap2-tcg-${version}';\n` +
`const CACHE_PREFIX = 'ap2-tcg-';\n` +
`const APP_FILES = ${JSON.stringify(assetNames)};\n` +
`self.addEventListener('install', event => {\n` +
`  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(APP_FILES)).then(() => self.skipWaiting()));\n` +
`});\n` +
`self.addEventListener('activate', event => {\n` +
`  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith(CACHE_PREFIX) && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));\n` +
`});\n` +
`self.addEventListener('fetch', event => {\n` +
`  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;\n` +
`  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {\n` +
`    if (response.ok) { const copy = response.clone(); event.waitUntil(caches.open(CACHE).then(cache => cache.put(event.request, copy))); }\n` +
`    return response;\n` +
`  })));\n` +
`});\n`;
fs.writeFileSync(path.join(root, 'web/sw.js'), worker, 'utf8');
for (const dir of targets) {
  for (const name of sourceFiles) {
    assert.equal(sha(path.join(root, name)), sha(path.join(root, dir, name)), `Abweichende Datei: ${dir}/${name}`);
  }
}
console.log(`Build OK: ${offlineFilename} (${Buffer.byteLength(output)} Bytes); PWA-Cache ${version}`);
