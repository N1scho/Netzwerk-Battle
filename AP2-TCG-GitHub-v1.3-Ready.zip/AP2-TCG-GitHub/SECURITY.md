# Sicherheit

## Geltungsbereich

AP2 TCG v1.3 ist ein lokales Browser-/Android-WebView-Spiel. Es gibt aktuell keinen Multiplayer-Server und keine zentralen Benutzerkonten. Spielstände liegen lokal auf dem jeweiligen Gerät.

## Meldungen

Sicherheitsrelevante Fehler nicht zusammen mit Kennwörtern, privaten Logdateien oder persönlichen Daten in öffentlichen Issues posten. Für eine vertrauliche Meldung nach Einrichtung des GitHub-Repositories nach Möglichkeit **Settings → Security → Private vulnerability reporting** aktivieren.

## Hinweise zum Betrieb

- Die clientseitige Regelprüfung ist nicht für manipulationssicheres Online-PvP geeignet.
- Keine API-Schlüssel, Signing-Keys oder Benutzerkontodaten ins Repository aufnehmen.
- Android-Debug-APKs dienen der Entwicklung. Für eine reguläre Veröffentlichung sind Release-Signierung, Versionsverwaltung und Gerätetests erforderlich.
- Das Spiel bietet keine verbindliche Prüfungsvorbereitung oder Garantie der IHK-Konformität sämtlicher Fragen.
