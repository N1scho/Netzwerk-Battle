# Android-App bauen

## GitHub Actions

1. Repository auf GitHub hochladen.
2. **Actions → Android Debug-APK bauen** öffnen.
3. **Run workflow** auswählen.
4. Nach erfolgreichem Abschluss **Artifacts → AP2-TCG-Android-Debug-APK** herunterladen.
5. ZIP entpacken. Die Datei `app-debug.apk` auf das Smartphone übertragen und installieren.

Für die Installation einer selbst erstellten Debug-APK muss Android gegebenenfalls die Installation aus der verwendeten Quelle zulassen. Nur APKs aus selbst kontrollierten Build-Läufen installieren.

## Android Studio

Den Ordner `android-studio/` als Projekt öffnen. Nach der Gradle-Synchronisierung **Build → Build APK(s)** ausführen. Ein Gradle Wrapper wird mit dem aktuellen Projekt nicht ausgeliefert; Android Studio kann die benötigte Gradle-Version einrichten. Der GitHub-Workflow verwendet explizit Gradle 8.7.

Technische Eckdaten:

- Android Gradle Plugin 8.6.1
- Android SDK 35
- Java 17
- `minSdk 24`
- Native Java-WebView mit lokal eingebetteten Spielressourcen

## Einschränkungen

Es gibt aktuell keinen verifizierten APK-Build aus der GitHub-Cloud und keinen Test auf einem physischen Android-Gerät für diesen Paketstand. Das Build-Skript und die Projektstruktur werden lokal geprüft; die echte Android-Kompilierung wird erst vom GitHub-Runner durchgeführt.

Die Debug-APK ist nicht für eine Store-Veröffentlichung geeignet. Dafür werden eine Release-Konfiguration, Signing-Schlüssel, App-Store-Metadaten und zusätzliche Sicherheitsprüfungen benötigt.
