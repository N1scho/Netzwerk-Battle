# Entwicklungsstand und Roadmap

## Implementiert (v1.3)

- Fünf Zielsysteme je Spieler mit HP, Zielerreichbarkeit und Verteidigungsaktionen.
- Lokales 1v1 sowie Bot-Gegner mit einstellbarer Schwierigkeit.
- Zehn Tutorial-Missionen mit kartenspezifischen AP2-Fragen.
- Freies Duell mit modularem Fragenmix, standardmäßig 70/30.
- Deckeditor, Basisdecks und freischaltbare Karten.
- Lokale Speicherung und Offline-Web-App.
- Regeltests und Fragebank-Strukturprüfung.

## Nächste Entwicklungsschritte

1. Fachredaktion der 621 Fragen; Grenzfälle und offene Aufgaben ergänzen.
2. Mehr nachvollziehbare Karteninteraktionen sowie gezielte Balancetests mit echten Spielern.
3. UI-/Engine-Trennung und belastbare Speicherstandmigration.
4. Serverautoritatives Online-PvP, Authentifizierung und Matchzustandssynchronisierung.
5. Erweiterte Multiplayer-Regeln für 3 und 4 Spieler sowie 1vX-Modi.
6. Android-Release-Build mit Signierung und Gerätests.

Ein Mehrspieler- oder Online-Feature darf im README erst als spielbar markiert werden, wenn es vollständig implementiert und getestet ist.
