# Architektur

## Technische Grundlage

AP2 TCG v1.3 ist ein **clientseitiges TCG**. Es verwendet HTML, CSS und JavaScript sowie einen nativen Android-WebView als alternative Laufzeit. Es gibt keinen Netzwerkserver für Matches.

```text
                Quelle im Repository
              index.html + CSS + JS
                       │
                 node build.cjs
            ┌──────────┼────────────┐
            │          │            │
  Offline-HTML       web/        Android-Assets
  (eine Datei)      (PWA)       (WebView)
```

Die Quelldateien unter dem Projektstamm sind führend. Der Build kopiert diese Dateien nach `web/` und `android-studio/app/src/main/assets/` und bettet sie in die Offline-HTML ein. Der Service Worker erhält automatisch einen Quellcode-Fingerabdruck im Cache-Namen.

## Spielmodule

| Datei | Aufgabe |
|---|---|
| `engine.js` | Regeln, Kartenaktionen, Zustände und Spielablauf |
| `app.js` | Oberfläche, Eingaben, Dialoge und Spielansicht |
| `trivia.js` | Kartenspezifische Fragen und Prüfung |
| `topics.js` | Fragen aus den AP2-Themengebieten |
| `packs.js` | Zuordnung und Auswahl der Fragenpakete |
| `styles.css` | Visualisierung, Karten- und Spielfelddesign |
| `tests.cjs` | Regel-Regressionstests |
| `audit_questions.cjs` | Strukturprüfung der Fragebank |

## Daten

- 621 Fragen insgesamt, davon 564 Themenfragen und 57 Kartenfragen.
- JSON-/CSV-Exporte sind für Redaktion und spätere Erweiterung enthalten.
- Spielstände, Freischaltungen und Einstellungen liegen im lokalen Browserspeicher beziehungsweise Android-WebView-Speicher.
- Spielstände werden nicht automatisch zwischen Browser, Smartphone und Geräten synchronisiert.

## Vertrauensgrenzen

Da die Regelberechnung clientseitig stattfindet, können technisch versierte Spieler die Zustände lokal verändern. Für echtes Online-PvP muss eine **serverautoritativ arbeitende Engine** geschaffen werden. Der derzeitige lokale PvP-Modus ist nicht ausreichend für faires Online-Matchmaking.

## Weitere Entwicklungsarbeit

Die Codebasis wird derzeit noch als große JavaScript-Module verwaltet. Eine spätere Aufteilung in klar getrennte UI-, Regel-, Fragen- und Persistenzmodule ist sinnvoll, jedoch nicht Voraussetzung für diesen ersten GitHub-Import.
