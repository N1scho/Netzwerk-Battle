# Fragenpakete und Lernlogik

## Grundspiel

Netzwerktechnik ist das dauerhaft aktive Grundpaket. Die zusätzlichen AP2-Themen werden als separat aktivierbare Fragen-Add-ons angeboten.

| Paket | Fragen |
|---|---:|
| Netzwerktechnik | 216 |
| Betriebssysteme und Administration | 42 |
| Server, Cloud und Speicher | 90 |
| IT-Sicherheit und Betrieb | 51 |
| Daten, SQL und Modellierung | 45 |
| WiSo und Wirtschaftlichkeit | 120 |
| **Summe Themenfragen** | **564** |

Zusätzlich enthält der Quellcode 57 kartenspezifische Fragen.

## Ausspielfragen

- Im **Tutorial** wird beim Ausspielen eine auf die jeweilige Karte bezogene Frage gestellt.
- Im **freien Duell** greift der aktivierte Fragenmix mit frei einstellbarem Anteil.
- Standard: 70 % Netzwerktechnik und 30 % aktivierte Add-ons.
- Ohne aktive Add-ons: 100 % Netzwerktechnik.
- Die Fragen werden in unterschiedlichen Schwierigkeitsstufen bereitgestellt.

## Redaktion

Die Dateien `fragenkatalog.json`, `fragenkatalog.csv` und `fragenpakete/*.json` stellen Exporte der Fragebank bereit. Die laufende Anwendung verwendet die JavaScript-Quelldateien `topics.js`, `trivia.js` und `packs.js`.

**Ein reiner CSV-Edit aktualisiert das Spiel nicht automatisch.** Vor dem Ausbau des Fragenpools muss eine einheitliche Datenquelle oder ein Generator etabliert werden. Jede Änderung an einer Frage sollte insbesondere korrekte Lösung, Operator, Schwierigkeit, Fachbezug und Erklärung prüfen.

## Qualität

Der Test `node audit_questions.cjs` prüft die formale Struktur. Er bestätigt nicht, dass sämtliche Aussagen fachlich, rechtlich oder prüfungsdidaktisch richtig sind. Die vollständige fachliche Redaktion bleibt eine separate Aufgabe.
