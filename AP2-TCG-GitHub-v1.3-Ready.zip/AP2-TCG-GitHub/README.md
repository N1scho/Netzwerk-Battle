# AP2 TCG – Network Warfare

Browserbasiertes taktisches Netzwerk-Kartenspiel zur Vorbereitung auf die **schriftliche Abschlussprüfung Teil 2 (Fachinformatiker Systemintegration)**.

![Tutorialansicht von AP2 TCG](docs/screenshots/tutorial.png)

## Aktueller Stand: v1.3

- Zwei Basisdecks, fünf Zielsysteme pro Spieler und lokale 1v1-Duelle gegen Bot oder zweiten Spieler.
- Zehn Tutorial-Missionen mit **kartenspezifischen AP2-Fragen** beim Ausspielen.
- Netzwerkfragen als Grundpaket; weitere Themen als wählbare Fragen-Add-ons.
- Fragenverhältnis einstellbar, standardmäßig **70 % Netzwerk / 30 % Add-ons**.
- 564 Themenfragen und 57 Kartenfragen (insgesamt 621; fachliche Gesamtredaktion noch ausstehend).
- Kartenfreischaltung, Deckeditor, mehrere Schwierigkeitsstufen und lokale Speicherung.
- Offline-HTML, GitHub-Pages-Web-App und Android-Studio-Projekt.

**Noch nicht verfügbar:** Online-PvP, 1vX/Mehrspieler mit drei oder vier Personen, finale Kartenbalance und signierte Android-Release-APK.

## Schnellstart

**Ohne Installation:** `AP2-TCG-v13-Offline.html` im Browser öffnen.

**Entwicklung (Node.js 20 oder neuer):**

```bash
npm run check
npm run dev
```

Anschließend `http://127.0.0.1:8080` öffnen. Es werden keine npm-Pakete installiert.

## Ordnerstruktur

```text
AP2-TCG/
├── .github/workflows/    # Tests, GitHub Pages, Android-Debug-APK
├── android-studio/       # Native Android-Hülle und eingebettete Web-App
├── docs/                 # GitHub-Anleitung, Architektur, Projektstatus
├── fragenpakete/         # Exportierte Themenpakete (JSON)
├── scripts/              # Build-Prüfung und lokaler Testserver
├── web/                  # Deploybare Web-App / PWA
├── engine.js             # Spielregeln und Zugzustände
├── app.js                # Benutzeroberfläche
├── trivia.js             # Kartenspezifische Fragen
├── topics.js             # Fachfragen der Themengebiete
├── packs.js              # Fragenpakete und Themenrotation
├── styles.css            # UI
├── index.html            # HTML-Einstieg
├── build.cjs             # Erzeugt Offline-/Web-/Android-Version
├── tests.cjs             # Regeltests
├── audit_questions.cjs   # Formale Fragenprüfung
└── package.json          # Entwicklungsbefehle
```

**Einzige Quelle:** Änderungen erfolgen an den Quelldateien im Repository-Stamm. `npm run build` synchronisiert die Kopien in `web/` und `android-studio/app/src/main/assets/` und erzeugt die Offline-HTML.

## GitHub und Bereitstellung

1. [GitHub-Repository erstellen und hochladen](docs/GITHUB_START.md).
2. Unter **Settings → Pages → Build and deployment → Source: GitHub Actions** die Veröffentlichung aktivieren.
3. Nach einem Push auf `main` wird die Web-App durch `.github/workflows/pages.yml` gebaut und veröffentlicht.
4. Für eine Android-Debug-APK unter **Actions → Android Debug-APK bauen → Run workflow** starten.

Details zum Android-Build: [docs/ANDROID.md](docs/ANDROID.md).

## Testen

```bash
npm run test             # 39 Regeltests, einschließlich 200 simulierten Partien
npm run audit:questions  # Strukturprüfung der 621 Fragen
npm run build            # Offline/Web/Android synchronisieren
npm run verify           # Dateien und JavaScript-Syntax prüfen
npm run check            # Alles zusammen
```

Die Skripte prüfen keine vollständige fachredaktionelle Richtigkeit und ersetzen keine manuellen Browser-/Gerätetests.

## Dokumentation

- [Spielsystem und Architektur](docs/ARCHITEKTUR.md)
- [Fragenpakete](docs/FRAGENPAKETE.md)
- [Weiterentwicklung](docs/ROADMAP.md)
- [Technischer Audit v1.3](docs/AUDIT_v13.md)
- [Änderungen](CHANGELOG.md)

## Lizenz und Veröffentlichung

Für dieses Projekt wurde **noch keine Open-Source-Lizenz festgelegt**. Ein öffentliches GitHub-Repository stellt den Quellcode sichtbar bereit, erteilt aber nicht automatisch Nutzungs- oder Weiterverbreitungsrechte. Siehe [Lizenzhinweise](LICENSE-HINWEIS.md). Die enthaltenen Illustrationen, Fragen und Kartentexte müssen vor einer externen Veröffentlichung gegebenenfalls hinsichtlich ihrer Rechte geprüft werden.
