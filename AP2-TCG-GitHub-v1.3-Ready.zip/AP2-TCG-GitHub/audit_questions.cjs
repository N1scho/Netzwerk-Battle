'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const ctx={window:{}};vm.createContext(ctx);
for(const f of ['trivia.js','topics.js','packs.js'])vm.runInContext(fs.readFileSync(__dirname+'/'+f,'utf8'),ctx,{filename:f});
const {AP2TRIVIA:trivia,AP2TOPICS:topics,AP2PACKS:packs}=ctx.window;
const counts={total:0,card:0,topic:0,issues:[],duplicates:[]};
const seen=new Map();
function validate(q,where){counts.total++;assert(typeof q.question==='string'&&q.question.trim().length>=10,`question ${where}`);assert(Array.isArray(q.options)&&q.options.length>=2&&q.options.length<=5,`answers ${where}`);assert(Number.isInteger(q.answer)&&q.answer>=0&&q.answer<q.options.length,`correct idx ${where}`);assert(q.options.every(x=>typeof x==='string'&&x.trim().length>0),`text ${where}`);assert(new Set(q.options).size===q.options.length,`repeated option ${where}`);if(!q.explain||q.explain.trim().length<10)counts.issues.push('Missing explanation: '+where);const normalized=q.question.toLocaleLowerCase('de').replace(/[^a-z0-9äöüß]+/g,' ');if(seen.has(normalized))counts.duplicates.push([where,seen.get(normalized)]);else seen.set(normalized,where);}
for(const [id,items] of Object.entries(trivia)){assert(items.length===3,`card ${id}`);items.forEach((q,i)=>{counts.card++;validate(q,`card ${id} ${i}`);});}
const groupIds=[];
for(const t of topics){assert(packs.some(p=>p.id===t.packId),`unknown pack ${t.id}`);for(const level of ['basic','normal','hard']){assert(Array.isArray(t.questions[level])&&t.questions[level].length>=1,`missing level ${t.id} ${level}`);t.questions[level].forEach((q,i)=>{counts.topic++;validate(q,`topic ${t.id} ${level} ${i}`);});}}
for(const p of packs){for(const g of p.groups){for(const tid of g.topics){groupIds.push(tid);assert(topics.some(t=>t.id===tid&&t.packId===p.id),`group missing topic ${tid}`);}}}
assert(groupIds.length===topics.length&&new Set(groupIds).size===topics.length,'each topic in exactly one group');
console.log(JSON.stringify({totals:counts,topics:topics.length,packs:packs.length},null,2));
