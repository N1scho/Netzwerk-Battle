# Lizenzstatus

Für den Quellcode und die im Projekt enthaltenen Medien wurde bisher keine ausdrückliche Open-Source-Lizenz ausgewählt.

Daher enthält dieses Repository **keine Lizenz zur freien Weiterverbreitung oder Bearbeitung**. Auch bei einem öffentlichen GitHub-Repository bleiben die jeweiligen Rechte der Rechteinhaber bestehen.

Vor der öffentlichen Weitergabe oder einer Veröffentlichung im App-Store müssen die Rechte an Quellcode, Grafiken, Schriftarten und Fragen geprüft werden. Eine spätere Lizenzentscheidung ist durch den Rechteinhaber zu treffen. Diese Datei ist selbst keine Open-Source-Lizenz.
