'use strict';
const assert=require('node:assert/strict');
const E=require('./engine.js');
let total=0;
function test(name,fn){try{fn();total++;console.log('PASS',name);}catch(err){console.error('FAIL',name,err.stack);process.exitCode=1;}}
const tg=n=>E.createGame({mode:'tutorial',missionId:n,quizRequired:true});
const play=(s,id,t=null,owner=0)=>{const permit=E.grantQuizPermit(s,owner,id,t);assert.equal(permit.ok,true,permit.error);const r=E.playCard(s,owner,id,t);assert.equal(r.ok,true,r.error);return r;};
const target=(owner,system)=>({owner,system});
const sizes=[...Object.values(E.BASIC_PRESETS).map(x=>Object.values(x).reduce((a,n)=>a+n,0))];
test('Basisdecks have 40 cards and no invalid types',()=>{for(const d of Object.values(E.BASIC_PRESETS))assert(E.validateDeck(d));});
test('max four copies per card',()=>{const d={...E.BASIC_PRESETS.basic_angriff,scan:5,ddos:3};assert(!E.validateDeck(d));});
test('unavailable card rejected',()=>{const s=tg(2);assert(E.playCard(s,0,'filter').ok===false);});
test('all human plays require quiz permit',()=>{const s=tg(2);assert.match(E.playCard(s,0,'scan',target(1,'web')).error,/Frage/);});
test('quiz permit bound to exact player/card/target',()=>{const s=tg(2);E.grantQuizPermit(s,0,'scan',target(1,'web'));assert(!E.playCard(s,0,'scan',target(1,'gateway')).ok);});
test('mission 1 system inspection',()=>{const s=tg(1);for(const [o,id] of [[0,'gateway'],[0,'data'],[1,'web']]) E.selectSystem(s,o,id);assert(s.completed);});
test('mission 2 sequential scan attack & reaction resolution',()=>{const s=tg(2);play(s,'scan',target(1,'web'));assert(E.findSys(s,1,'web').scannedBy.includes(0));play(s,'ddos',target(1,'web'));assert(s.pending);E.resolvePending(s);assert(s.completed);assert.equal(E.findSys(s,1,'web').hp,2);});
test('mission 3 defense prevents damage',()=>{const s=tg(3);play(s,'filter');assert(s.completed);assert.equal(E.findSys(s,0,'web').hp,4);});
test('mission 4 access pathway',()=>{const s=tg(4);play(s,'phishing',target(1,'client'));assert(s.players[0].access.client);play(s,'pivot');assert(s.players[0].access.internal);play(s,'internal',target(1,'data'));E.resolvePending(s);assert(s.completed);});
test('mission 5 redundant storage and backup restoration',()=>{const s=tg(5);play(s,'raid',target(0,'data'));const before=E.findSys(s,0,'data').hp;E.simulateIncident(s);assert.equal(E.findSys(s,0,'data').hp,before);play(s,'backup',target(0,'data'));assert(s.completed);assert.equal(E.findSys(s,0,'data').hp,6);});
test('mission 6 ACL blocking',()=>{const s=tg(6);play(s,'segmentation',target(0,'gateway'));assert(E.simulateAclIncident(s).ok);});
test('mission 7 exploit requires scan and vulnerability',()=>{const s=tg(7);assert(!E.cardPlayability(s,0,'exploit').playable);play(s,'scan',target(1,'web'));play(s,'vuln',target(1,'web'));play(s,'exploit',target(1,'web'));E.resolvePending(s);assert(s.completed);});
test('mission 8 DNS diagnostic',()=>{const s=tg(8);play(s,'dnscheck',target(0,'dns'));assert(s.players[0].hand.includes('log'));});
test('mission 9 and 10 quiz',()=>{for(const id of [9,10]){const s=tg(id);let guard=0;while(E.currentStep(s)&&guard++<10){const step=E.currentStep(s);if(step.type==='select')E.selectSystem(s,step.owner,step.system);else if(step.type==='quiz')E.answerQuiz(s,step.answer);else throw Error('Unexpected step '+step.type);}assert(s.completed);}});
test('invalid tutorial mission rejected',()=>{assert.throws(()=>tg(999),/Unbekannte/);});
test('wrong target cannot consume quiz authorization',()=>{const s=tg(2);assert(!E.grantQuizPermit(s,0,'scan',target(1,'client')).ok);assert(s.players[0].hand.includes('scan'));});
test('another card cannot consume permit',()=>{const s=tg(2);E.grantQuizPermit(s,0,'scan',target(1,'web'));assert(!E.playCard(s,0,'ddos',target(1,'web')).ok);});
test('free game respects quiz before acting',()=>{const s=E.createGame({mode:'hotseat',seed:12,quizRequired:true,deck:E.BASIC_PRESETS.basic_angriff});const id=s.players[0].hand.find(x=>E.cardPlayability(s,0,x).playable);assert(id);const c=E.CARDS[id];const t=c.target==='none'?null:E.eligibleTargets(s,id,0)[0];assert(!E.playCard(s,0,id,t).ok);});
test('ai can play without quiz',()=>{const s=E.createGame({mode:'ai',seed:3,quizRequired:true});E.endTurn(s);const result=E.aiStep(s);assert(result.ok);});
test('turn limit grows on second personal turn',()=>{const s=E.createGame();assert.equal(s.players[0].maxKp,3);E.endTurn(s);assert.equal(s.players[1].maxKp,3);E.endTurn(s);assert.equal(s.players[0].maxKp,4);});
test('quiz permit erased on turn change',()=>{const s=E.createGame();s.quizPermit={owner:0,cardId:'scan'};E.endTurn(s);assert.equal(s.quizPermit,null);});
test('pivot requires client access',()=>{const s=E.createGame();s.players[0].hand.push('pivot');assert(!E.cardPlayability(s,0,'pivot').playable);});
test('pivot cannot be wasted after server access',()=>{const s=E.createGame();s.players[0].hand.push('pivot');s.players[0].access.client=true;s.players[0].access.internal=true;assert(!E.cardPlayability(s,0,'pivot').playable);});
test('network access does not follow scan',()=>{const s=tg(2);play(s,'scan',target(1,'web'));assert(!s.players[0].access.client);assert(!s.players[0].access.internal);});
test('RAID does not replace backup',()=>{const s=E.createGame();const data=E.findSys(s,0,'data');data.raidCharge=1;data.hp=2;assert(!E.eligibleTargets(s,'backup',0).some(x=>x.system==='data'));});
test('damage from DDoS targets only external systems',()=>{const s=E.createGame();const ids=E.eligibleTargets(s,'ddos',0).map(x=>x.system);assert.deepEqual(ids,['gateway','web']);});
test('hardening decreases damage once',()=>{const s=E.createGame({quizRequired:false});const sys=E.findSys(s,1,'web');sys.fortified=1;s.players[0].hand.push('ddos');E.playCard(s,0,'ddos',target(1,'web'));E.resolvePending(s);assert.equal(sys.hp,3);assert.equal(sys.fortified,0);});
test('match wins on data server down',()=>{const s=E.createGame({quizRequired:false});const sys=E.findSys(s,1,'data');sys.hp=2;s.players[0].access.internal=true;s.players[0].hand.push('internal');E.playCard(s,0,'internal',target(1,'data'));E.resolvePending(s);assert.equal(s.winner,0);});


test('deck-out on mandatory draw ends PvP match',()=>{const s=E.createGame({mode:'ai'});s.players[1].deck=[];E.endTurn(s);assert.equal(s.winner,0);assert.equal(s.phase,'ended');});
test('tutorial with empty deck is exempt from deck-out',()=>{const s=tg(8);play(s,'dnscheck',target(0,'dns'));assert.equal(s.winner,null);});

test('second phishing attempt rejected when client access already exists',()=>{const s=E.createGame();s.players[0].access.client=true;s.players[0].hand.push('phishing');assert.equal(E.eligibleTargets(s,'phishing',0).length,0);assert(!E.cardPlayability(s,0,'phishing').playable);});
test('playability requires card in hand',()=>{const s=tg(1);assert(!E.cardPlayability(s,0,'ddos').playable);});

test('backup restores a failed webserver from an existing backup',()=>{
  const s=E.createGame({quizRequired:false});const sys=E.findSys(s,0,'web');
  sys.hp=0;sys.backupCharge=1;s.players[0].hand.push('backup');
  assert(E.cardPlayability(s,0,'backup').playable);
  assert(E.targetAdvice(s,'backup',0,0,'web').legal);
  const r=E.playCard(s,0,'backup',target(0,'web'));
  assert(r.ok,r.error);assert.equal(sys.hp,3);assert.equal(sys.backupCharge,0);
});
test('failed server cannot be revived without a backup',()=>{
  const s=E.createGame({quizRequired:false});const sys=E.findSys(s,0,'web');
  sys.hp=0;sys.backupCharge=0;s.players[0].hand.push('backup');
  assert.equal(E.eligibleTargets(s,'backup',0).some(t=>t.system==='web'),false);
  assert.equal(E.targetAdvice(s,'backup',0,0,'web').legal,false);
});
test('non-backup cards cannot target a failed system',()=>{
  const s=E.createGame({quizRequired:false});E.findSys(s,0,'web').hp=0;
  for(const id of ['fortify','script','backupplan'])assert(!E.eligibleTargets(s,id,0).some(t=>t.system==='web'));
});
test('old save-friendly AI behavior uses a persistent seeded random sequence',()=>{
  const a=E.createGame({mode:'ai',seed:2201,quizRequired:false,aiDifficulty:'easy'});
  const b=E.createGame({mode:'ai',seed:2201,quizRequired:false,aiDifficulty:'easy'});
  E.endTurn(a);E.endTurn(b);
  for(let i=0;i<12;i++){
    if(a.winner!==null||b.winner!==null)break;
    if(a.phase==='response'&&a.pending.defender===0){E.resolvePending(a);E.resolvePending(b);}
    else if(a.active===1){E.aiStep(a);E.aiStep(b);}
    else break;
    assert.deepEqual(a,b);
  }
});
test('seed zero produces reproducible decks',()=>{
  const a=E.createGame({seed:0}),b=E.createGame({seed:0});
  assert.deepEqual(a.players[0].hand,b.players[0].hand);
  assert.deepEqual(a.players[0].deck,b.players[0].deck);
});
test('ordinary attacks on a failed target remain illegal',()=>{
  const s=E.createGame({quizRequired:false});E.findSys(s,1,'web').hp=0;s.players[0].hand.push('ddos');
  assert(!E.eligibleTargets(s,'ddos',0).some(t=>t.system==='web'));
});
// Sequence test: legal actions must never produce invalid HP or resource states.
test('200 randomized matches preserve resource and system invariants',()=>{
  for(let seed=1;seed<=200;seed++){
    const s=E.createGame({mode:'hotseat',seed,quizRequired:false});
    for(let n=0;n<180&&s.winner===null;n++){
      if(s.phase==='response'){
        const d=s.pending.defender;
        const card=s.players[d].hand.find(id=>E.cardPlayability(s,d,id).playable);
        if(card&&n%4!==0)assert(E.playCard(s,d,card).ok);else assert(E.resolvePending(s).ok);
      }else{
        const owner=s.active,opts=[];
        for(const id of new Set(s.players[owner].hand)){
          if(!E.cardPlayability(s,owner,id).playable)continue;
          const targets=E.CARDS[id].target==='none'?[null]:E.eligibleTargets(s,id,owner);
          for(const t of targets)opts.push([id,t]);
        }
        if(opts.length&&n%6!==5){const [id,t]=opts[(seed*17+n*7)%opts.length];assert(E.playCard(s,owner,id,t).ok);}
        else E.endTurn(s);
      }
      for(const p of s.players){
        assert(p.kp>=0&&p.kp<=p.maxKp,'KP bounds');
        for(const sys of p.systems)assert(sys.hp>=0&&sys.hp<=sys.maxHp,'HP bounds');
      }
    }
  }
});

console.log(`${total} tests passed, presets=${sizes.join(',')}`);if(process.exitCode)process.exit(process.exitCode);
