# Changelog

## 1.3 – 04.11.2026
### Korrigiert
- Rückspiel aus einem vorhandenen Sicherungsstand ist auch bei ausgefallenen, nicht spielentscheidenden Systemen zulässig.
- Nach falscher Quizantwort lässt sich der Bonus nicht mehr durch das Abbrechen und erneute Öffnen der Kartenfrage zurücksetzen.
- Ein beim Fortsetzen geladener älterer Spielstand erzwingt wieder die Fragenpflicht und verwirft etwaige alte Spielgenehmigungen.
- Der PWA-Service-Worker löscht keine Caches anderer Anwendungen derselben Herkunft mehr.
- Ziele mit 0 HP zeigen im Falle eines erlaubten Rückspiels die passende Zielmarkierung.
- Zusätzliche Prüfung beschädigter lokaler Speicherstände.
- Vier oder fünf Antwortoptionen erhalten korrekt beschriftete Schaltflächen.

### Optimiert
- Seed-basierte, im Spielstand gespeicherte Bot-Zufallswerte.
- Gemeinsamer Build für Offline-Datei, Web und Android-Assets.
- Neue Testfälle für Rückspiel, Zufallsgenerator, Zielvalidierung und Spielinvarianten.

### Geprüft
- 39 automatisierte Regeltests bestanden, einschließlich 200 simulierter Partien.
- Fragenbank: 621 Fragen strukturell geprüft; die fachliche Vollprüfung steht aus.
- In Chromium als Inline-HTML geprüft: Menü, Tutorial, erste Mission, Kartenfrage, Abbruch, mobile Startansicht, keine JavaScript-Fehler.
- Fragerücksetz-Exploit per Browsertest mit lokalem Speicher nachgestellt und die Korrektur bestätigt.

### Offen
- Echtes Online-PvP, 1vX, serverautoritatives Match, vollständige Balance, kompilierte APK und fachliche Einzelprüfung aller Fragen.
