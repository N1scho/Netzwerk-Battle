# Code-Audit AP2 TCG 1.3

Datum: 04.11.2026

| Schwere | Bereich | Nachgewiesener Befund | Maßnahme | Test |
|---|---|---|---|---|
| Hoch | Wiederherstellung | Backupkarte konnte keinen ausgefallenen Webserver mit vorhandener Sicherung auswählen | Zielregel und Zielfreigabe korrigiert | Rückspieltest |
| Hoch | Belohnung | Abbruch nach falscher Frage setzte `wrongEver` zurück und ermöglichte erneut den Bonus | Fehlerstatus pro Spieler/Kartentyp im Match speichern | Browser-Reproduktion |
| Mittel | Spielstände | Unzureichende Validierung bei beschädigten HP-, KP- und Systemzuständen | Eingehende Zustandsschema-Prüfung erweitert | Syntax- und Browser-Smoke-Tests |
| Mittel | Alte Spielstände | Vorherige Quiz-Einstellungen bzw. Genehmigungen konnten beim Laden weiterbestehen | Fragenpflicht erzwingen, Genehmigung verwerfen | Code-Prüfung |
| Mittel | Reproduzierbarkeit | KI-Aktionen nutzten nicht deterministisches `Math.random` | Spielstandsgebundenen PRNG implementiert | Seeded-AI-Test |
| Mittel | PWA | Alter Service Worker löschte alle fremden Caches auf derselben Herkunft | Cachepräfix-Filter | Quellcodeprüfung |
| Niedrig | UI | Ausgefallene, per Rückspiel wiederherstellbare Systeme wurden als nicht anwählbar bezeichnet | Statusmarkierung korrigiert | Regel- und Browserprüfung |
| Niedrig | Fragendialog | Antwortlabels auf A/B/C beschränkt | Bis zu fünf Antwortlabels | Quellcodeprüfung |
| Wartbarkeit | Build | Drei Plattformvarianten könnten unterschiedliche JS/CSS-Stände enthalten | Buildskript mit SHA-256-Abgleich | Build |

## Qualitätssicherung

- `node tests.cjs`: 39/39 Tests erfolgreich.
- 200 simulierte Partien im Invariantentest, bei denen HP/KP innerhalb gültiger Grenzen blieben; keine statistische Balancebewertung.
- `node audit_questions.cjs`: 564 Themenfragen, 57 Kartenfragen; Antwortindex, Optionen, Erklärungen, Doppelungen und Zuordnung geprüft.
- Browser: Chromium `set_content` mit gebündeltem HTML, Tutorial 1/2, Karte/Target/Frage/Abbruch, Mobilansicht. Keine JavaScript-Exceptions in diesen Abläufen.
- Browser-Navigation über `localhost` wurde von der Testumgebung administrativ blockiert. Deshalb sind HTTPS/PWA-Installation und tatsächlicher Offline-Dateistart nicht separat per Navigation bestätigt.

## Architektur-Risiken

1. **Online- und Manipulationssicherheit:** Browser-Engine, Fragerichtigeitswert und Kartenbestand liegen komplett clientseitig. Für Ranglisten-PvP muss die autoritative Engine auf dem Server ausgeführt werden.
2. **Zwei-Spieler-Annahme:** Spielerindex `1-owner` ist quer durch die Engine eingebaut. Für 3–4 Spieler muss zunächst die Match-Zielstruktur abstrahiert werden.
3. **Große Quellmodule:** `app.js` mischt UI, Speichern, Quiz und Spielfluss. Mittelfristig sollten UI-Controller, Persistenz und Quizzustand getrennt werden.
4. **Fragenqualität:** Technische Strukturtests ersetzen keine redaktionelle Prüfung aller Lösungen und IHK-Operatoren.
5. **Balance:** Der Bot und die Karten benötigen mehr vollständige Partien mit menschlichen Spielern und aussagekräftige Metriken.
6. **Android-Auslieferung:** Kein signierter APK-Build und keine Tests auf realen Geräten.
